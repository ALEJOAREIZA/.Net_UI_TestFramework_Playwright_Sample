public static class AdminPortalApiTestDataManager
{
    public static AdminPortalApiTestData TestData { get; } = new ConfigurationManager<AdminPortalApiTestData>()
        .WithConfigFiles(FileTransform("API/TestData/AdminPortalApi.TestDataEnvVariables.json", "API/TestData/AdminPortalApi.TestData.json"))
        .WithUserSecrets<AdminPortalApiTestData>()
        .Get();
    private static string FileTransform(string variablesFile, string targetFile)
    {
        var testEnvironment = TestContext.Parameters["testEnvironment"].ToUpper();
        var variablesJObject = JsonConvert.DeserializeObject(File.ReadAllText(variablesFile)) as JObject;
        var targetJObject = JsonConvert.DeserializeObject(File.ReadAllText(targetFile)) as JObject;

        foreach (var variableToken in variablesJObject.SelectToken($"{testEnvironment}") as JObject)
        {
            var targetTokens = targetJObject.SelectTokens($"..{variableToken.Key}").ToList();
            targetTokens.ForEach(targetToken => targetToken.Replace(variableToken.Value));
        }
        var updateJsonString = targetJObject.ToString();
        File.WriteAllText(targetFile, updateJsonString);
        return targetFile;
    }
}