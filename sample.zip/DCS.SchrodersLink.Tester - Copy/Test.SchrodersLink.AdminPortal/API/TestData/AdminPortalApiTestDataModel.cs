public class GetPortfolioReportsTestData
{
    public Credentials Credentials { get; set; }
    public PortfolioDate Date { get; set; }
    public string PortfolioCode { get; set; }
}
public class GetAuthenticatedUserInfoTestData
{
    public Credentials Credentials { get; set; }
}
public class GetListOfUsersByKeywordTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
}
public class GetAllDocumentTypesTestData
{
    public Credentials Credentials { get; set; }
}
public class GetUserRolesTestData
{
    public Credentials Credentials { get; set; }
}
public class GetDownloadListOfUsersTestData
{
    public Credentials Credentials { get; set; }
}
public class GetUserInfoByIdTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
}
public class GetUserRolesByIdTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
}
public class GetLinkedPortfoliosByUserIdTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
}
public class GetUnLinkedPortfoliosByUserIdTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
}
public class SendResetPasswordTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
}
public class UpdateUserRolesByIdTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
    public List<UserRole> NonClientViewRole { get; set; }
    public List<UserRole> NoRoles { get; set; }
}
public class AddRemoveAccountTestData
{
    public Credentials Credentials { get; set; }
    public UserAccount UserAccount { get; set; }
}
public class GetNPVAccountsTestData
{
    public Credentials Credentials { get; set; }
}
public class GetNextNPVAccountNumberTestData
{
    public Credentials Credentials { get; set; }
}
public class CreateNewNPVAccountTestData
{
    public Credentials Credentials { get; set; }
    public NpvAccount NpvAccount { get; set; }
}
public class UpdateNPVAccountTestData
{
    public Credentials Credentials { get; set; }
    public NpvAccount NpvAccount { get; set; }
}
public class GetReportTypesTestData
{
    public Credentials Credentials { get; set; }
}
public class CreateNewReportTypeTestData
{
    public Credentials Credentials { get; set; }
    public ReportType ReportType { get; set; }
}
public class UpdateReportTypeTestData
{
    public Credentials Credentials { get; set; }
    public ReportType ReportType { get; set; }
}
public class GetPortfoliosTestData
{
    public Credentials Credentials { get; set; }
}
public class DownloadPortfolioReportsTestData
{
    public Credentials Credentials { get; set; }
    public PortfolioDate Date { get; set; }
    public string PortfolioCode { get; set; }
}
public class SubmitReportTestData
{
    public Credentials Credentials { get; set; }
    public CheckReports CheckReports { get; set; }
}
public class GetRecipientsByKeywordsTestData
{
    public Credentials Credentials { get; set; }
    public string Keywords { get; set; }
}
public class SendNotificationTestData
{
    public Credentials Credentials { get; set; }
    public Notification Notification { get; set; }
}
public class GetMessageByIdTestData
{
    public Credentials Credentials { get; set; }
    public MessagingCenter Message { get; set; }
}
public class CreateMessageTestData
{
    public Credentials Credentials { get; set; }
    public MessagingCenter Message { get; set; }
}
public class UpdateMessageTestData
{
    public Credentials Credentials { get; set; }
    public MessagingCenter Message { get; set; }
}
public class GetListOfMessagesTestData
{
    public Credentials Credentials { get; set; }
}
public class GetUserMessagesTestData
{
    public Credentials Credentials { get; set; }
    public UserData User { get; set; }
}
public class GetRegionsTestData
{
    public Credentials Credentials { get; set; }
}
public class GetUserGroupsTestData
{
    public Credentials Credentials { get; set; }
}

public class AdminPortalApiTestData
{
    public List<GetPortfolioReportsTestData> GetPortfolioReportsTestData { get; set; }
    public List<GetAuthenticatedUserInfoTestData> GetAuthenticatedUserInfoTestData { get; set; }
    public List<GetListOfUsersByKeywordTestData> GetListOfUsersByKeywordTestData { get; set; }
    public List<GetAllDocumentTypesTestData> GetAllDocumentTypesTestData { get; set; }
    public List<GetUserRolesTestData> GetUserRolesTestData { get; set; }
    public List<GetDownloadListOfUsersTestData> GetDownloadListOfUsersTestData { get; set; }
    public List<GetUserInfoByIdTestData> GetUserInfoByIdTestData { get; set; }
    public List<GetUserRolesByIdTestData> GetUserRolesByIdTestData { get; set; }
    public List<GetLinkedPortfoliosByUserIdTestData> GetLinkedPortfoliosByUserIdTestData { get; set; }
    public List<GetUnLinkedPortfoliosByUserIdTestData> GetUnLinkedPortfoliosByUserIdTestData { get; set; }
    public List<SendResetPasswordTestData> SendResetPasswordTestData { get; set; }
    public List<UpdateUserRolesByIdTestData> UpdateUserRolesByIdTestData { get; set; }
    public List<AddRemoveAccountTestData> AddRemoveAccountTestData { get; set; }
    public List<GetNPVAccountsTestData> GetNPVAccountsTestData { get; set; }
    public List<GetNextNPVAccountNumberTestData> GetNextNPVAccountNumberTestData { get; set; }
    public List<CreateNewNPVAccountTestData> CreateNewNPVAccountTestData { get; set; }
    public List<UpdateNPVAccountTestData> UpdateNPVAccountTestData { get; set; }
    public List<GetReportTypesTestData> GetReportTypesTestData { get; set; }
    public List<CreateNewReportTypeTestData> CreateNewReportTypeTestData { get; set; }
    public List<UpdateReportTypeTestData> UpdateReportTypeTestData { get; set; }
    public List<GetPortfoliosTestData> GetPortfoliosTestData { get; set; }
    public List<DownloadPortfolioReportsTestData> DownloadPortfolioReportsTestData { get; set; }
    public List<SubmitReportTestData> SubmitReportTestData { get; set; }
    public List<GetRecipientsByKeywordsTestData> GetRecipientsByKeywordsTestData { get; set; }
    public List<SendNotificationTestData> SendNotificationTestData { get; set; }
    public List<GetUserMessagesTestData> GetUserMessagesTestData { get; set; }
    public List<GetListOfMessagesTestData> GetListOfMessagesTestData { get; set; }
    public List<GetUserGroupsTestData> GetUserGroupsTestData { get; set; }
    public List<GetRegionsTestData> GetRegionsTestData { get; set; }
    public List<GetMessageByIdTestData> GetMessageByIdTestData { get; set; }
    public List<CreateMessageTestData> CreateMessageTestData { get; set; }
    public List<UpdateMessageTestData> UpdateMessageTestData { get; set; }
}