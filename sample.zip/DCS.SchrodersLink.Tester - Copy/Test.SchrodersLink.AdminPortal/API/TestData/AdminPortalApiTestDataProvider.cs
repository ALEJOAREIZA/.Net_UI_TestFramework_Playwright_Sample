public class GetPortfolioReportsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetPortfolioReportsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetAuthenticatedUserInfoDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAuthenticatedUserInfoTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetListOfUsersByKeywordDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetListOfUsersByKeywordTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetAllDocumentTypesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAllDocumentTypesTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUserRolesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUserRolesTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetDownloadListOfUsersDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetDownloadListOfUsersTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUserInfoByIdDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUserInfoByIdTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUserRolesByIdDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUserRolesByIdTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetLinkedPortfoliosByUserIdDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetLinkedPortfoliosByUserIdTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUnLinkedPortfoliosByUserIdDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUnLinkedPortfoliosByUserIdTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendResetPasswordDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendResetPasswordTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class UpdateUserRolesByIdDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.UpdateUserRolesByIdTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class AddRemoveAccountDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.AddRemoveAccountTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetNPVAccountsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetNPVAccountsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetNextNPVAccountNumberDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetNextNPVAccountNumberTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class CreateNewNPVAccountDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.CreateNewNPVAccountTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class UpdateNPVAccountDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.UpdateNPVAccountTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetReportTypesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetReportTypesTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class CreateNewReportTypeDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.CreateNewReportTypeTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class UpdateReportTypeDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.UpdateReportTypeTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetPortfoliosDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetPortfoliosTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class DownloadPortfolioReportsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.DownloadPortfolioReportsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SubmitReportDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.SubmitReportTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetRecipientsByKeywordsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetRecipientsByKeywordsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendNotificationDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendNotificationTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUserMessagesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUserMessagesTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetListOfMessagesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetListOfMessagesTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUserGroupsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUserGroupsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetRegionsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetRegionsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetMessageByIdDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetMessageByIdTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class CreateMessageDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.CreateMessageTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class UpdateMessageDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalApiTestDataManager.TestData;
        foreach (var data in testData.UpdateMessageTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}