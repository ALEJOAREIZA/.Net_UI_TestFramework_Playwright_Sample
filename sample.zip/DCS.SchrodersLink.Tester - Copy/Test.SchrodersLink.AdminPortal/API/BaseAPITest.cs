public class BaseAPITest
{
    private readonly APITracingManager trace = APITracingManager.GetInstance();
    private string testName;
    private APIEnvConfig adminPortalApiEnvConfig;
    private APIEnvConfig messaginCenterApiEnvConfig;

    [SetUp]
    public void SetUp()
    {
        testName = TestContext.CurrentContext.Test.MethodName;
        var testEnvironment = TestContext.Parameters["testEnvironment"].ToUpper();
        trace.TracingDirPath = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "API", "TraceData", $"{DateTime.Now:yyMMdd-HHmmss}_{TestContext.CurrentContext.Test.MethodName}");
        adminPortalApiEnvConfig = testEnvironment switch
        {
            nameof(TestEnvironment.DIT) => AdminPortalApiConfigManager.GetSettings().DIT,
            nameof(TestEnvironment.UAT) => AdminPortalApiConfigManager.GetSettings().UAT,
            _ => throw new InvalidOperationException($"Test Environment does not meet Environment criteria"),
        };
        messaginCenterApiEnvConfig = testEnvironment switch
        {
            nameof(TestEnvironment.DIT) => AdminPortalApiConfigManager.GetMessagingCenterSettings().DIT,
            nameof(TestEnvironment.UAT) => AdminPortalApiConfigManager.GetMessagingCenterSettings().UAT,
            _ => throw new InvalidOperationException($"Test Environment does not meet Environment criteria"),
        };
        trace.Write($"===== {testName} has started =====");
    }
    public AdminPortalAPI AdminPortal => new AdminPortalAPI(adminPortalApiEnvConfig);
    public MessagingCenterlAPI MessagingCenter => new MessagingCenterlAPI(messaginCenterApiEnvConfig);

    [TearDown]
    public void TearDown()
    {
        var testResult = TestContext.CurrentContext.Result.Outcome.Status;
        trace.Write($"===== {testName} has finished =====");
        trace.Write($"Test {testResult} {TestContext.CurrentContext.Result.Message}");
        TestContext.AddTestAttachment(trace.TracingFilePath);
        // ADOTestCaseService.AddTestSteps(QETestContext.CurrentContext.TestCaseId, QETestContext.CurrentContext.TestCaseSteps).Wait();
    }
}