public class SubmitReport : BaseAPITest
{
    [Test, TestCaseId("1246702")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SubmitReportDataProvider))]
    public async Task SubmitReportTest(SubmitReportTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).SubmitReport(data.CheckReports);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}