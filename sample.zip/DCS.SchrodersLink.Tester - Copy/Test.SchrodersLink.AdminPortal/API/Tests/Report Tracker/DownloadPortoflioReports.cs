public class DownloadPortfolioReports : BaseAPITest
{
    [Test, TestCaseId("1246505")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(DownloadPortfolioReportsDataProvider))]
    public async Task DownloadPortfolioReportsTest(DownloadPortfolioReportsTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).DownloadPortfolioReports(data.PortfolioCode, data.Date.StartDate, data.Date.EndDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.ContentHeaders.ContentLength.Should().BePositive();
            response.ContentHeaders.ContentDisposition.FileNameStar.Should().Be("SchrodersLink Client Reportlogs.xlsx");
        }
    }
}