public class GetPortfolioReports : BaseAPITest
{
    [Test, TestCaseId("1243564")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetPortfolioReportsDataProvider))]
    public async Task GetPortfolioReportsTest(GetPortfolioReportsTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetPortfolioReports(data.PortfolioCode, data.Date.StartDate, data.Date.EndDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(report => report.Should().NotBeNull());
            response.Content.ForEach(report => report.Should().BeOfType<PortfolioLog>());
        }
    }
}