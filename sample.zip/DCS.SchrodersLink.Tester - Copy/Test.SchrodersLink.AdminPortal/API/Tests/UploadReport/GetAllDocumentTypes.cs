public class GetAllDocumentTypes : BaseAPITest
{
    [Test, TestCaseId("1243492")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetAllDocumentTypesDataProvider))]
    public async Task GetAllDocumentTypesTest(GetAllDocumentTypesTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetAllDocumentTypes();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().BeOfType<DocumentType>();
            response.Content.GeneralDocumentTypes.Count.Should().BePositive();
        }
    }
}