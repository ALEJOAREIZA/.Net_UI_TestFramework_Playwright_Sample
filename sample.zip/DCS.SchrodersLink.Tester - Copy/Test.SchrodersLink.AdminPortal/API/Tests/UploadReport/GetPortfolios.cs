public class GetPortfolios : BaseAPITest
{
    [Test, TestCaseId("1246243")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetPortfoliosDataProvider))]
    public async Task GetPortfoliosTest(GetPortfoliosTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetPortfolios();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().BeOfType<PortfolioUser>();
            response.Content.Portfolios.ForEach(portfolio => portfolio.Should().BeOfType<PortfolioUserData>());
            response.Content.TotalCount.Should().BePositive();
        }
    }
}