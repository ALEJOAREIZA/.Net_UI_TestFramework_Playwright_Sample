public class UpdateReportType : BaseAPITest
{
    [Test, TestCaseId("1200850")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(UpdateReportTypeDataProvider))]
    public async Task UpdateReportTypeTest(UpdateReportTypeTestData data)
    {
        data.ReportType.DocumentTypeName = $"{data.ReportType.DocumentTypeName} {DateTime.Now:ddMMHHmm}";
        var response = await AdminPortal.Authenticate(data.Credentials).UpsertNewReportType(data.ReportType);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().BeEquivalentTo(data.ReportType);
        }
    }
}