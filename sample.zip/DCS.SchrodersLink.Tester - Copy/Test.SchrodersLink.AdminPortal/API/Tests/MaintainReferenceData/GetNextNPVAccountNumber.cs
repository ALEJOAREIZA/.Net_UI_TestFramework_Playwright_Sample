public class GetNextNPVAccountNumber : BaseAPITest
{
    [Test, TestCaseId("1198825")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetNextNPVAccountNumberDataProvider))]
    public async Task GetNextNPVAccountNumberTest(GetNextNPVAccountNumberTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetNextNPVAccountNumber();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
        }
    }
}