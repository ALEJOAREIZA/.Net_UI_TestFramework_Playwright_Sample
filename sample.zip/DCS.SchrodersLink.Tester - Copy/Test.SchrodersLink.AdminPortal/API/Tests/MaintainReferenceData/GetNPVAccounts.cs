public class GetNPVAccounts : BaseAPITest
{
    [Test, TestCaseId("1194998")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetNPVAccountsDataProvider))]
    public async Task GetNPVAccountsTest(GetNPVAccountsTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetNPVAccounts();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.NpvAccountList.ForEach(npvAccount => npvAccount.Should().BeOfType<NpvAccount>());
            response.Content.NpvAccountList.ForEach(npvAccount => npvAccount.AccountName.Should().NotBeNullOrEmpty());
        }
    }
}