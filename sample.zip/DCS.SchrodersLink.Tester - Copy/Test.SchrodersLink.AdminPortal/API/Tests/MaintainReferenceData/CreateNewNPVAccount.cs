public class CreateNewNPVAccount : BaseAPITest
{
    [Test, TestCaseId("1198987")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(CreateNewNPVAccountDataProvider))]
    [Ignore("Waiting for delete procedure to be created")]
    public async Task CreateNewNPVAccountTest(CreateNewNPVAccountTestData data)
    {
        data.NpvAccount.AccountName = $"{data.NpvAccount.AccountName} {DateTime.Now:ddMMHHmm}";
        var response = await AdminPortal.Authenticate(data.Credentials).UpsertNewNPVAccount(data.NpvAccount);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.AccountCode.Should().NotBeNull();
            response.Content.AccountName.Should().Be(data.NpvAccount.AccountName);
            response.Content.Region.Should().Be(data.NpvAccount.Region);
            response.Content.ReportingCurrency.Should().Be(data.NpvAccount.ReportingCurrency);
            response.Content.IsActive.Should().Be(data.NpvAccount.IsActive);
        }
    }
}