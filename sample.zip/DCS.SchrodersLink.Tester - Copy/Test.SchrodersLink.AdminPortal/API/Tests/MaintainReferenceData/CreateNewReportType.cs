public class CreateNewReportType : BaseAPITest
{
    [Test, TestCaseId("1200849")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(CreateNewReportTypeDataProvider))]
    [Ignore("Waiting for delete procedure to be created")]
    public async Task CreateNewReportTypeTest(CreateNewReportTypeTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).UpsertNewReportType(data.ReportType);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.DocumentType.Should().Be(data.ReportType.DocumentType);
            response.Content.DocumentTypeName.Should().Be(data.ReportType.DocumentTypeName);
            response.Content.Visible.Should().Be(data.ReportType.Visible);
            response.Content.Audience.Should().Be(data.ReportType.Audience);
            response.Content.MifidDocTypeOrder.Should().Be(data.ReportType.MifidDocTypeOrder);
            response.Content.IsAdminVisible.Should().Be(data.ReportType.IsAdminVisible);
            response.Content.Category.Should().Be(data.ReportType.Category);
        }
    }
}