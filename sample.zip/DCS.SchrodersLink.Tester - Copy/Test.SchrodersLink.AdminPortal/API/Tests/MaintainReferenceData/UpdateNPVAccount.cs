public class UpdateNPVAccount : BaseAPITest
{
    [Test, TestCaseId("1198988")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(UpdateNPVAccountDataProvider))]
    public async Task UpdateNPVAccountTest(UpdateNPVAccountTestData data)
    {
        data.NpvAccount.AccountName = $"{data.NpvAccount.AccountName} {DateTime.Now:ddMMHHmm}";
        var response = await AdminPortal.Authenticate(data.Credentials).UpsertNewNPVAccount(data.NpvAccount);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().BeEquivalentTo(data.NpvAccount);
        }
    }
}