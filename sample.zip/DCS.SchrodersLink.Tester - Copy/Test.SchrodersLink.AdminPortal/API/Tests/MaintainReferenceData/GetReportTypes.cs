public class GetReportTypes : BaseAPITest
{
    [Test, TestCaseId("1199552")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetReportTypesDataProvider))]
    public async Task GetReportTypesTest(GetReportTypesTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetReportTypes();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ReportTypeList.ForEach(reportType => reportType.Should().BeOfType<ReportType>());
        }
    }
}