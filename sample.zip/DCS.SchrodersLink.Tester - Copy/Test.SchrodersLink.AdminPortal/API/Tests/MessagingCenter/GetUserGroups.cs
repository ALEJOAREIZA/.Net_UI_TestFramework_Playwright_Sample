﻿public class GetUserGroups : BaseAPITest
{
    [Test, TestCaseId("1229338")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API), Microservice(Microservice.MessagingCenter)]
    [TestCaseSource(typeof(GetUserGroupsDataProvider))]
    public async Task GetUserGroupsTest(GetUserGroupsTestData data)
    {
        var response = await MessagingCenter.Authenticate(data.Credentials).GetUserGroups();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(group => group.Should().BeOfType<MessageUserGroup>());
            response.Content.ForEach(group => group.Id.Should().NotBe(null));
            response.Content.ForEach(group => group.Name.Should().NotBeNull());
        }
    }
}