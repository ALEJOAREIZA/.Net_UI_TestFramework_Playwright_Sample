public class UpdateMessage : BaseAPITest
{
    [Test, TestCaseId("1254864")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API), Microservice(Microservice.MessagingCenter)]
    [TestCaseSource(typeof(UpdateMessageDataProvider))]
    public async Task UpdateMessageTest(UpdateMessageTestData data)
    {
        data.Message.Title = $"{data.Message.Title}{DateTime.Now:ddMMHHmm}";
        data.Message.Message = $"{data.Message.Message} {DateTime.Now:ddMMHHmm}";
        data.Message.ExpirationDate = $"{DateTime.Now.AddDays(1):yyyy-MM-dd}";
        var response = await MessagingCenter.Authenticate(data.Credentials).CreateUpdateMessage(data.Message);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().BeOfType<MessagingCenter>();
            response.Content.Title.Should().BeEquivalentTo(data.Message.Title);
            response.Content.Message.Should().BeEquivalentTo(data.Message.Message);
        }
    }
}