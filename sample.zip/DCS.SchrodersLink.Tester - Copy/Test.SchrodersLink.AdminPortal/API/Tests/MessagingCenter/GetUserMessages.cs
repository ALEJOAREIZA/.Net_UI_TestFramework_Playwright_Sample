﻿public class GetUserMessages : BaseAPITest
{
    [Test, TestCaseId("1209890")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API), Microservice(Microservice.MessagingCenter)]
    [TestCaseSource(typeof(GetUserMessagesDataProvider))]
    public async Task GetUserMessagesTest(GetUserMessagesTestData data)
    {
        var response = await MessagingCenter.Authenticate(data.Credentials).GetUserMessages(data.User.UserId);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(message => message.Should().BeOfType<UserMessagingCenter>());
            response.Content.ForEach(message => message.Message.Should().NotBeNull());
        }
    }
}