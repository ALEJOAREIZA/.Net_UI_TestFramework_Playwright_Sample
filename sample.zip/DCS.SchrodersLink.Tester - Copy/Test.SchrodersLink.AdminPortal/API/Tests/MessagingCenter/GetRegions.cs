﻿public class GetRegions : BaseAPITest
{
    [Test, TestCaseId("1229339")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API), Microservice(Microservice.MessagingCenter)]
    [TestCaseSource(typeof(GetRegionsDataProvider))]
    public async Task GetRegionsTest(GetRegionsTestData data)
    {
        var response = await MessagingCenter.Authenticate(data.Credentials).GetRegions();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
        }
    }
}