﻿public class GetMessageById : BaseAPITest
{
    [Test, TestCaseId("1229337")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API), Microservice(Microservice.MessagingCenter)]
    [TestCaseSource(typeof(GetMessageByIdDataProvider))]
    public async Task GetMessageByIdTest(GetMessageByIdTestData data)
    {
        var response = await MessagingCenter.Authenticate(data.Credentials).GetMessageById(data.Message.Id);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().BeOfType<MessagingCenter>();
        }
    }
}