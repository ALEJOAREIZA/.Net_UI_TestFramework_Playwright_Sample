﻿public class GetListOfMessages : BaseAPITest
{
    [Test, TestCaseId("1229336")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API), Microservice(Microservice.MessagingCenter)]
    [TestCaseSource(typeof(GetListOfMessagesDataProvider))]
    public async Task GetListOfMessagesTest(GetListOfMessagesTestData data)
    {
        var response = await MessagingCenter.Authenticate(data.Credentials).GetListOfMessages();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(message => message.Should().BeOfType<MessagingCenter>());
            response.Content.ForEach(message => message.Title.Should().NotBeNull());
            response.Content.ForEach(message => message.Message.Should().NotBeNull());
        }
    }
}