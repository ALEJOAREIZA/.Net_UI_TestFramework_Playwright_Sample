public class GetAuthenticatedUserInfo : BaseAPITest
{
    [Test, TestCaseId("963411")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetAuthenticatedUserInfoDataProvider))]
    public async Task GetAuthenticatedUserInfoTest(GetAuthenticatedUserInfoTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetCurrentUserInfo();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().BeOfType<CurrentUser>();
            response.Content.Name.ToLower().Should().Be(data.Credentials.Username.ToLower());
        }
    }
}