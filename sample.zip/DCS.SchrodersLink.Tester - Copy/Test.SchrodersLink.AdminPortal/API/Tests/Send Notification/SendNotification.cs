public class SendNotification : BaseAPITest
{
    [Test, TestCaseId("1246739")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendNotificationDataProvider))]
    public async Task SendNotificationTest(SendNotificationTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).SendNotification(data.Notification);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}