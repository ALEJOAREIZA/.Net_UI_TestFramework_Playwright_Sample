public class GetRecipientsByKeywords : BaseAPITest
{
    [Test, TestCaseId("1246737")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetRecipientsByKeywordsDataProvider))]
    public async Task GetRecipientsByKeywordsTest(GetRecipientsByKeywordsTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetRecipientsByKeywords(data.Keywords);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().BeOfType<Recipient>();
            response.Content.Portfolios.ForEach(portfolio => portfolio.Recipients.ForEach(recipient => recipient.Email.Should().NotBeNullOrEmpty()));
        }
    }
}