public class GetUnLinkedPortfoliosByUserId : BaseAPITest
{
    [Test, TestCaseId("1243433")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetUnLinkedPortfoliosByUserIdDataProvider))]
    public async Task GetUnLinkedPortfoliosByUserIdTest(GetUnLinkedPortfoliosByUserIdTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetUnlinkedPortfoliosByUserId(data.User.UserId);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.TotalCount.Should().BePositive();
            response.Content.Portfolios.ForEach(portfolio => portfolio.Should().BeOfType<PortfolioData>());
            response.Content.Portfolios.ForEach(portfolio => portfolio.LinkId.Should().Be(-1));
        }
    }
}