public class GetUserRolesById : BaseAPITest
{
    [Test, TestCaseId("1127976")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetUserRolesByIdDataProvider))]
    public async Task GetUserRolesByIdTest(GetUserRolesByIdTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetUserRolesById(data.User.UserId);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
            response.Content.Count.Should().BePositive();
        }
    }
}