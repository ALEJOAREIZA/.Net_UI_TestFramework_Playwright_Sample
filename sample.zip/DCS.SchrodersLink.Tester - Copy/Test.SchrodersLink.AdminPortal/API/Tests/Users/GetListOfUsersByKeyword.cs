public class GetListOfUsersByKeyword : BaseAPITest
{
    [Test, TestCaseId("967566")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetListOfUsersByKeywordDataProvider))]
    public async Task GetListOfUsersByKeywordTest(GetListOfUsersByKeywordTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetListOfUsers(data.User.Email);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Users.ForEach(user => user.Should().BeOfType<UserData>());
            response.Content.Users.ForEach(user => user.FirstName.ToLowerInvariant().Should().Contain("Test".ToLowerInvariant()));
        }
    }
}