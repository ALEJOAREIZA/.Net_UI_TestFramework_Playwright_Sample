public class AddRemoveAccount : BaseAPITest
{
    [Test, TestCaseId("1243436")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(AddRemoveAccountDataProvider))]
    public async Task AddRemoveAccountTest(AddRemoveAccountTestData data)
    {
        var entityIdList = new List<int>();
        var createResponse = await AdminPortal.Authenticate(data.Credentials).AddAccount(data.UserAccount);
        using (new AssertionScope())
        {
            createResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            createResponse.Content.Should().NotBeNullOrEmpty();
            createResponse.Content.ForEach(portfolio => portfolio.Should().BeOfType<PortfolioData>());
            createResponse.Content.ForEach(portfolio => portfolio.IsAccount.Should().BeTrue());
        }
        entityIdList.Add(createResponse.Content.FirstOrDefault().LinkId);
        var deleteResponse = await AdminPortal.Authenticate(data.Credentials).RemoveAccount(entityIdList);
        using (new AssertionScope())
        {
            deleteResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            deleteResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            deleteResponse.Content.Should().BeTrue();
        }
    }
}