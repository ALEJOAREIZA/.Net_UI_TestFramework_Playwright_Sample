public class GetUserInfoById : BaseAPITest
{
    [Test, TestCaseId("1241777")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetUserInfoByIdDataProvider))]
    public async Task GetUserInfoByIdTest(GetUserInfoByIdTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetUserInfoById(data.User.UserId);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().BeOfType<UserData>();
            response.Content.Email.ToLower().Should().Be(data.User.Email.ToLower());
        }
    }
}