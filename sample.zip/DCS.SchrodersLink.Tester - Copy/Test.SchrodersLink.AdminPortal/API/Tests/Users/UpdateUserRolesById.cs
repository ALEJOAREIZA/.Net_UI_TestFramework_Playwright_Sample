public class UpdateUserRolesById : BaseAPITest
{
    [Test, TestCaseId("967573")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(UpdateUserRolesByIdDataProvider))]
    public async Task UpdateUserRolesByIdTest(UpdateUserRolesByIdTestData data)
    {
        var responseNPVGroup = await AdminPortal.Authenticate(data.Credentials).UpdateUserRolesById(data.NonClientViewRole, data.User.UserId);
        responseNPVGroup.StatusCode.Should().Be(HttpStatusCode.OK);
        var responseNoGroup = await AdminPortal.Authenticate(data.Credentials).UpdateUserRolesById(data.NoRoles, data.User.UserId);
        responseNoGroup.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}