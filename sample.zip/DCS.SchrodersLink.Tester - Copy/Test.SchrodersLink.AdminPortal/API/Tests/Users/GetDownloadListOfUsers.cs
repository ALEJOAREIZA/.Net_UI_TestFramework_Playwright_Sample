public class GetDownloadListOfUsers : BaseAPITest
{
    [Test, TestCaseId("963541")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetDownloadListOfUsersDataProvider))]
    public async Task GetDownloadListOfUsersTest(GetDownloadListOfUsersTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetDownloadListOfUsers();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.ContentHeaders.ContentDisposition.FileName.Should().Be("\"SchrodersLink Users.xlsx\"");
            response.ContentHeaders.ContentLength.Should().BePositive();
        }
    }
}