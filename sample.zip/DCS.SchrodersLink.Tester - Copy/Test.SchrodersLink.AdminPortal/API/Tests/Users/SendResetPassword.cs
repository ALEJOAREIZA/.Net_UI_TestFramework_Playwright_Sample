public class SendResetPassword : BaseAPITest
{
    [Test, TestCaseId("954875")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendResetPasswordDataProvider))]
    public async Task SendResetPasswordTest(SendResetPasswordTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).SendResetPassword(data.User.UserId);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}