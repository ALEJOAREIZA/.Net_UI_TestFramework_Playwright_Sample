public class GetLinkedPortfoliosByUserId : BaseAPITest
{
    [Test, TestCaseId("1242374")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetLinkedPortfoliosByUserIdDataProvider))]
    public async Task GetLinkedPortfoliosByUserIdTest(GetLinkedPortfoliosByUserIdTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetLinkedPortfoliosByUserId(data.User.UserId);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.TotalCount.Should().BeInRange(0, 50);
            response.Content.Portfolios.ForEach(portfolio => portfolio.LinkId.Should().NotBe(0));
            response.Content.Portfolios.ForEach(portfolio => portfolio.Should().BeOfType<PortfolioData>());
        }
    }
}