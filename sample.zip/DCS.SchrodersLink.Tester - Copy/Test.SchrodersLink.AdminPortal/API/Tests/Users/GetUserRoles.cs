public class GetUserRoles : BaseAPITest
{
    [Test, TestCaseId("963558")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetUserRolesDataProvider))]
    public async Task GetUserRolesTest(GetUserRolesTestData data)
    {
        var response = await AdminPortal.Authenticate(data.Credentials).GetUserRoles();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(userRole => userRole.Should().BeOfType<UserRoles>());
            response.Content.ForEach(userRole => userRole.Name.Should().NotBeNullOrEmpty());
            response.Content.ForEach(userRole => userRole.Description.Should().NotBeNullOrEmpty());
        }
    }
}