public class BaseUITest
{
    private IUIDriver uiDriver;
    private UIDriverConfigOptions uiDriverConfigOptions;

    [SetUp]
    public void SetUp()
    {
        var adminPortalUIEnvConfig = TestContext.Parameters["testEnvironment"].ToUpper() switch
        {
            nameof(TestEnvironment.DIT) => AdminPortalUIConfigManager.GetSettings().DIT,
            nameof(TestEnvironment.UAT) => AdminPortalUIConfigManager.GetSettings().UAT,
            _ => throw new InvalidOperationException($"Test Environment does not meets Schroderslink Environment criteria"),
        };
        uiDriverConfigOptions = AdminPortalUITestConfigManager.GetSettings();
        uiDriverConfigOptions.TracingSettings.TracingDirPath = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "UI", "TraceData", $"{DateTime.Now:yyMMdd-HHmmss}_{TestContext.CurrentContext.Test.MethodName}");
        uiDriver = new UIDriverFactory(uiDriverConfigOptions).CreateUIDriver();
        uiDriver.NavigateToPage(adminPortalUIEnvConfig.BaseAddress);
    }
    public AdminPortalUI AdminPortal => new AdminPortalUI(uiDriver);
    public static string GetExpectedImage(string imageName) => Path.Combine(
        Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory).Parent.Parent.Parent.FullName,
        "UI",
        "VisualData",
        imageName);

    [TearDown]
    public void TearDown()
    {
        uiDriver.Dispose();
        var tracingDirPath = uiDriverConfigOptions.TracingSettings.TracingDirPath;
        var tracingLogFiles = Directory.GetFiles(tracingDirPath, "*.log");
        var tracingDirPathFilesCount = Directory.GetFiles(tracingDirPath).Length;

        if (uiDriverConfigOptions.TracingSettings.Logging)
        {
            foreach (var logFile in tracingLogFiles)
            {
                TestContext.AddTestAttachment(logFile);
            }
        }
        if (uiDriverConfigOptions.TracingSettings.GetType().GetProperties()
            .Where(p => !"Logging".Equals(p.Name))
            .Select(pi => pi.GetValue(uiDriverConfigOptions.TracingSettings))
            .Any(value => value is true) || tracingDirPathFilesCount > 1)
        {
            var zipPath = tracingDirPath + ".zip";
            ZipFile.CreateFromDirectory(tracingDirPath, zipPath);
            TestContext.AddTestAttachment(zipPath);
        }
    }
}