public class UICredentials
{
    public string Username { get; set; }
    public string Password { get; set; }
}
public class LoginIntoAdminPortalTestData
{
    public UICredentials Credentials { get; set; }
    public string ProfileName { get; set; }
}
public class ValidateHomeTabsTestData
{
    public UICredentials Credentials { get; set; }
    public List<string> HomeTabs { get; set; }
}
public class DownloadAllUsersCSVfileTestData
{
    public UICredentials Credentials { get; set; }
}
public class ValidateUserControlInfoTestData
{
    public UICredentials Credentials { get; set; }
}
public class SendResetPasswordNotificationTestData
{
    public UICredentials Credentials { get; set; }
}
public class SearchForUserTestData
{
    public UICredentials Credentials { get; set; }
}
public class UpdateUserRolesTestData
{
    public UICredentials Credentials { get; set; }
    public AdminPortalUserRoles UserRoles { get; set; }
}
public class AddRemoveNPVAccountTestData
{
    public UICredentials Credentials { get; set; }
    public List<string> NPVAccountsCode { get; set; }
}
public class AddRemoveMultipleNPVAccountTestData
{
    public UICredentials Credentials { get; set; }
    public List<string> NPVAccountsCode { get; set; }
}
public class SearchForWrongUserTestData
{
    public UICredentials Credentials { get; set; }
}
public class SearchForAccountTestData
{
    public UICredentials Credentials { get; set; }
    public string NPVAccountCode { get; set; }
}
public class ValidateAccountTableInfoTestData
{
    public UICredentials Credentials { get; set; }
}
public class ValidateUserAccountTestData
{
    public UICredentials Credentials { get; set; }
    public string AccountId { get; set; }
}
public class SearchForPortfolioReportsTestData
{
    public UICredentials Credentials { get; set; }
    public ReportTracker ReportTracker { get; set; }
}
public class SendEmailNotificationTestData
{
    public UICredentials Credentials { get; set; }
    public EmailNotification EmailNotification { get; set; }
}
public class SearchForMultiplePortfolioReportsTestData
{
    public UICredentials Credentials { get; set; }
    public ReportTracker ReportTracker { get; set; }
}
public class DownloadReportTrackerResultsTestData
{
    public UICredentials Credentials { get; set; }
    public ReportTracker ReportTracker { get; set; }
}
public class ClearReportTrackerResultsTestData
{
    public UICredentials Credentials { get; set; }
    public ReportTracker ReportTracker { get; set; }
}
public class ValidateUploadReportPageTestData
{
    public UICredentials Credentials { get; set; }
}
public class ValidateReportsResultTableTestData
{
    public UICredentials Credentials { get; set; }
    public ReportTracker ReportTracker { get; set; }
}
public class AdminPortalUITestData
{
    public List<LoginIntoAdminPortalTestData> LoginIntoAdminPortalTestData { get; set; }
    public List<ValidateHomeTabsTestData> ValidateHomeTabsTestData { get; set; }
    public List<DownloadAllUsersCSVfileTestData> DownloadAllUsersCSVfileTestData { get; set; }
    public List<ValidateUserControlInfoTestData> ValidateUserControlInfoTestData { get; set; }
    public List<SendResetPasswordNotificationTestData> SendResetPasswordNotificationTestData { get; set; }
    public List<SearchForUserTestData> SearchForUserTestData { get; set; }
    public List<UpdateUserRolesTestData> UpdateUserRolesTestData { get; set; }
    public List<AddRemoveNPVAccountTestData> AddRemoveNPVAccountTestData { get; set; }
    public List<SearchForWrongUserTestData> SearchForWrongUserTestData { get; set; }
    public List<AddRemoveMultipleNPVAccountTestData> AddRemoveMultipleNPVAccountTestData { get; set; }
    public List<SearchForAccountTestData> SearchForAccountTestData { get; set; }
    public List<ValidateAccountTableInfoTestData> ValidateAccountTableInfoTestData { get; set; }
    public List<ValidateUserAccountTestData> ValidateUserAccountTestData { get; set; }
    public List<SearchForPortfolioReportsTestData> SearchForPortfolioReportsTestData { get; set; }
    public List<SendEmailNotificationTestData> SendCustomEmailNotificationTestData { get; set; }
    public List<SendEmailNotificationTestData> Send10LossEmailNotificationTestData { get; set; }
    public List<SearchForMultiplePortfolioReportsTestData> SearchForMultiplePortfolioReportsTestData { get; set; }
    public List<DownloadReportTrackerResultsTestData> DownloadReportTrackerResultsTestData { get; set; }
    public List<ClearReportTrackerResultsTestData> ClearReportTrackerResultsTestData { get; set; }
    public List<ValidateUploadReportPageTestData> ValidateUploadReportPageTestData { get; set; }
    public List<ValidateReportsResultTableTestData> ValidateReportsResultTableTestData { get; set; }
}