public static class AdminPortalUITestDataManager
{
    public static AdminPortalUITestData GetTestData { get; } = new ConfigurationManager<AdminPortalUITestData>()
    .WithConfigFiles(FileTransform("UI/TestData/AdminPortalUI.TestDataEnvVariables.json", "UI/TestData/AdminPortalUI.TestData.json"))
    .WithUserSecrets<AdminPortalUITestData>()
    .Get();
    private static string FileTransform(string variablesFile, string targetFile)
    {
        var testEnvironment = TestContext.Parameters["testEnvironment"].ToUpper();
        var variablesJObject = JsonConvert.DeserializeObject(File.ReadAllText(variablesFile)) as JObject;
        var targetJObject = JsonConvert.DeserializeObject(File.ReadAllText(targetFile)) as JObject;

        var envVariables = variablesJObject[testEnvironment] as JObject;
        var keysToReplace = envVariables.Descendants()
                                         .OfType<JProperty>()
                                         .Select(prop => new { prop.Name, prop.Value })
                                         .ToList();

        foreach (var keyValuePair in keysToReplace)
        {
            var targetTokens = targetJObject.SelectTokens($"..{keyValuePair.Name}")
                .Where(token => token.Type == JTokenType.String)
                .ToList();
            targetTokens.ForEach(targetToken => targetToken.Replace(keyValuePair.Value));
        }

        var updateJsonString = targetJObject.ToString();
        File.WriteAllText(targetFile, updateJsonString);
        return targetFile;
    }
}
