public class LoginIntoAdminPortalDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.LoginIntoAdminPortalTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ValidateHomeTabsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.ValidateHomeTabsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class DownloadAllUsersCSVfileDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.DownloadAllUsersCSVfileTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ValidateUserControlInfoDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.ValidateUserControlInfoTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendResetPasswordNotificationDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.SendResetPasswordNotificationTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SearchForUserDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.SearchForUserTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class UpdateUserRolesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.UpdateUserRolesTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class AddRemoveNPVAccountDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.AddRemoveNPVAccountTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class AddRemoveMultipleNPVAccountDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.AddRemoveMultipleNPVAccountTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SearchForWrongUserDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.SearchForWrongUserTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SearchForAccountDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.SearchForAccountTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ValidateAccountTableInfoDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.ValidateAccountTableInfoTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ValidateUserAccountTesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.ValidateUserAccountTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SearchForPortfolioReportsTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.SearchForPortfolioReportsTestData)
        {
            yield return new TestCaseData(data);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendCustomEmailNotificationTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.SendCustomEmailNotificationTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class Send10LossEmailNotificationTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.Send10LossEmailNotificationTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SearchForMultiplePortfolioReportsTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.SearchForMultiplePortfolioReportsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class DownloadReportTrackerResultsTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.DownloadReportTrackerResultsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ClearReportTrackerResultsTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.ClearReportTrackerResultsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ValidateUploadReportPageTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.ValidateUploadReportPageTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ValidateReportsResultTableTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = AdminPortalUITestDataManager.GetTestData;
        foreach (var data in testData.ValidateReportsResultTableTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}