public static class AdminPortalUITestConfigManager
{
    public static UIDriverConfigOptions GetSettings()
    {
        var fileName = $"UI/Config/AdminPortalUI.TestConfigData.json";
        return new ConfigurationManager<UIDriverConfigOptions>()
            .WithConfigFiles(fileName)
            .Get();
    }
}
