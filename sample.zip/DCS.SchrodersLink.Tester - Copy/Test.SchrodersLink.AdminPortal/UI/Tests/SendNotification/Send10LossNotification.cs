public class Send10LossNotification : BaseUITest
{
    [Test, TestCaseId("1039041")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(Send10LossEmailNotificationTestDataProvider))]
    public void Send10LossNotificationTest(SendEmailNotificationTestData data)
    {
        var notificationPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToNotificationPage();
        notificationPage.Fill10LossNotification(data.EmailNotification.PortfolioName, data.EmailNotification.Recipient);
        notificationPage.SendButton.Click();
        notificationPage.ModalRecipientlist.Text.Should().Contain(data.EmailNotification.Recipient);
        notificationPage.ModalNotificationTitle.Text.Should().Contain("MiFID II Notification of 10% Loss ");
        notificationPage.ModalNotificationMessage.Text.Should().Contain("Under MiFID II obligations");
        notificationPage.BackButton.Click();
        notificationPage.CommonElement.SuccessPopUp.Visibility.Should().BeFalse();
        notificationPage.SendButton.Click();
        notificationPage.ConfirmButton.Click();
        notificationPage.CommonElement.SuccessPopUp.Visibility.Should().BeTrue();
    }
}