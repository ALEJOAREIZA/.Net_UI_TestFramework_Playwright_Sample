public class SendCustomNotification : BaseUITest
{
    [Test, TestCaseId("1180870")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(SendCustomEmailNotificationTestDataProvider))]
    public void SendCustomNotificationTest(SendEmailNotificationTestData data)
    {
        var notificationPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToNotificationPage();
        notificationPage.FillCustomNotification(data.EmailNotification.PortfolioName, data.EmailNotification.Recipient, data.EmailNotification.Title, data.EmailNotification.Message);
        notificationPage.SendButton.Click();
        notificationPage.ModalRecipientlist.Text.Should().Contain(data.EmailNotification.Recipient);
        notificationPage.ModalNotificationTitle.Text.Should().Be(data.EmailNotification.Title);
        notificationPage.ModalNotificationMessage.Text.Should().Be(data.EmailNotification.Message);
        notificationPage.ConfirmButton.Click();
        notificationPage.CommonElement.SuccessPopUp.Visibility.Should().BeTrue();
    }
}