﻿public class ValidateReportsResultTable : BaseUITest
{
    [Test, TestCaseId("1229335")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(ValidateReportsResultTableTestDataProvider))]
    public void ValidateReportsResultTableTest(ValidateReportsResultTableTestData data)
    {
        #region TestCaseData
        var portfolioCodes = data.ReportTracker.Portfolios.Select(p => p.Code).ToList();
        data.ReportTracker.EndDate = DateTime.Now.ToString("dd/MM/yyyy");
        var expectedImage = GetExpectedImage("ReportTrackerTable.png");
        #endregion
        var reportTrackerPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToReportTrackerPage();
        reportTrackerPage.SearchForPortfolioReports(portfolioCodes, data.ReportTracker.StartDate, data.ReportTracker.EndDate);
        reportTrackerPage.CommonElement.LoadingSpinner.WaitUntilItDisappears();
        var currentImage = reportTrackerPage.ReportTrackerTable.TakeScreenshot();
        var isMatch = ImageComparator.CompareImages(expectedImage, currentImage);
        isMatch.Should().BeTrue();
    }
}