public class ClearReportTrackerResults : BaseUITest
{
    [Test, TestCaseId("985618")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(ClearReportTrackerResultsTestDataProvider))]
    public void ClearReportTrackerResultsTest(ClearReportTrackerResultsTestData data)
    {
        #region TestCaseData
        var portfolioCodes = data.ReportTracker.Portfolios.Select(p => p.Code).ToList();
        data.ReportTracker.EndDate = DateTime.Now.ToString("dd/MM/yyyy");
        #endregion
        var reportTrackerPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToReportTrackerPage();
        reportTrackerPage.SearchForPortfolioReports(portfolioCodes, data.ReportTracker.StartDate, data.ReportTracker.EndDate);
        reportTrackerPage.ReportTrackerTable.Visibility.Should().BeTrue();
        reportTrackerPage.ClearButton.Click();
        reportTrackerPage.ReportTrackerTable.Visibility.Should().BeFalse();
    }
}