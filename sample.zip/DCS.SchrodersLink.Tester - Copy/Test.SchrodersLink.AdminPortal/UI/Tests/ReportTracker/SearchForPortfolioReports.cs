public class SearchForPortfolioReports : BaseUITest
{
    [Test, TestCaseId("1180914")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(SearchForPortfolioReportsTestDataProvider))]
    public void SearchForPortfolioReportsTest(SearchForPortfolioReportsTestData data)
    {
        #region TestCaseData
        var portfolioCodes = data.ReportTracker.Portfolios.Select(p => p.Code).ToList();
        data.ReportTracker.EndDate = DateTime.Now.ToString("dd/MM/yyyy");
        #endregion
        var reportTrackerPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToReportTrackerPage();
        reportTrackerPage.SearchForPortfolioReports(portfolioCodes, data.ReportTracker.StartDate, data.ReportTracker.EndDate);
        reportTrackerPage.ReportTrackerTable.Body.Cell(1, 3).Text.Should().Contain(data.ReportTracker.Portfolios.First().Code[..^2]);
        reportTrackerPage.ReportTrackerTable.Body.Cell(1, 4).Text.Should().Contain(data.ReportTracker.Portfolios.First().Name);
    }
}