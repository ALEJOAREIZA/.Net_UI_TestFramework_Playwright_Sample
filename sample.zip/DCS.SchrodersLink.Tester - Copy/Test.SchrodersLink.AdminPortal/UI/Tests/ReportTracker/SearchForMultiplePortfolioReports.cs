public class SearchForMultiplePortfolioReports : BaseUITest
{
    [Test, TestCaseId("1317361")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(SearchForMultiplePortfolioReportsTestDataProvider))]
    public void SearchForMultiplePortfolioReportsTest(SearchForMultiplePortfolioReportsTestData data)
    {
        #region TestCaseData
        var portfolioCodes = data.ReportTracker.Portfolios.Select(x => x.Code).ToList();
        var portfolioNames = data.ReportTracker.Portfolios.Select(x => x.Name).ToList();
        var firstPortfolioName = portfolioNames.OrderBy(x => x).First();
        var lastPortfolioName = portfolioNames.OrderByDescending(x => x).First();
        data.ReportTracker.EndDate = DateTime.Now.ToString("dd/MM/yyyy");
        #endregion
        var reportTrackerPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToReportTrackerPage();
        reportTrackerPage.SearchForPortfolioReports(portfolioCodes, data.ReportTracker.StartDate, data.ReportTracker.EndDate);
        reportTrackerPage.ReportTrackerTable.Body.Cell(1, 4).Text.Should().Contain(firstPortfolioName);
        reportTrackerPage.ReportTrackerTable.Header.Column(4).Click().Click();
        reportTrackerPage.ReportTrackerTable.Body.Cell(1, 4).Text.Should().Contain(lastPortfolioName);
    }
}