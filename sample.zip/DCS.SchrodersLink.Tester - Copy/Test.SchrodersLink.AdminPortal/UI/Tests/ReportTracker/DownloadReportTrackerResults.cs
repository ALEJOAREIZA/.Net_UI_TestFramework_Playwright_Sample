public class DownloadReportTrackerResults : BaseUITest
{
    [Test, TestCaseId("1012724")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(DownloadReportTrackerResultsTestDataProvider))]
    public void DownloadReportTrackerResultsTest(DownloadReportTrackerResultsTestData data)
    {
        var portfolioCodes = data.ReportTracker.Portfolios.Select(p => p.Code).ToList();
        data.ReportTracker.EndDate = DateTime.Now.ToString("dd/MM/yyyy");

        var reportTrackerPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToReportTrackerPage();
        reportTrackerPage.SearchForPortfolioReports(portfolioCodes, data.ReportTracker.StartDate, data.ReportTracker.EndDate);
        reportTrackerPage.DownloadReportTrackerResults();
    }
}