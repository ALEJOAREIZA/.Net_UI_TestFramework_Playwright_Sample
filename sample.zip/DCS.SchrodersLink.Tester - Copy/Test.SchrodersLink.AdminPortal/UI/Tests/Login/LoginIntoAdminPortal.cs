public class LoginIntoAdminPortal : BaseUITest
{
    [Test, TestCaseId("934446")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(LoginIntoAdminPortalDataProvider))]
    public void LoginIntoAdminPortalTest(LoginIntoAdminPortalTestData data)
    {
        var homepage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        homepage.NavBar.ProfileContainer.Text.Should().Be(data.ProfileName);
    }
}