public class ValidateUploadReportPage : BaseUITest
{
    [Test, TestCaseId("988872")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(ValidateUploadReportPageTestDataProvider))]
    public void ValidateUploadReportPageTest(ValidateUploadReportPageTestData data)
    {
        var uploadReportPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToUploadReportPage();
        var portfolioTab = uploadReportPage.GotToPortfolioReportsTab();
        portfolioTab.PortfolioReportsTab.SelectedStatus.Should().BeTrue();
        portfolioTab.PortfolioSelector.Visibility.Should().BeTrue();
        portfolioTab.UploadFilesInput.Visibility.Should().BeTrue();
        portfolioTab.ReviewAndPublishButton.Visibility.Should().BeTrue();
        portfolioTab.ReviewAndPublishButton.EnabledStatus.Should().BeFalse();

        var generalTab = uploadReportPage.GotToGeneralReportsTab();
        generalTab.GeneralReportsTab.Click();
        generalTab.GeneralReportsTab.SelectedStatus.Should().BeTrue();
        generalTab.UploadFilesInput.Visibility.Should().BeTrue();
        generalTab.ReviewAndPublishButton.Visibility.Should().BeTrue();
        generalTab.ReviewAndPublishButton.EnabledStatus.Should().BeFalse();
    }
}