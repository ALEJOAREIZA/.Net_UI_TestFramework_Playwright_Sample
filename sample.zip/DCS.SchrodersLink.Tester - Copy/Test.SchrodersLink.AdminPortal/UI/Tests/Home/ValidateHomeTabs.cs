public class ValidateHomeTabs : BaseUITest
{
    [Test, TestCaseId("1248177")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(ValidateHomeTabsDataProvider))]
    public void ValidateHomeTabsTest(ValidateHomeTabsTestData data)
    {
        var homePage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        foreach (var tab in data.HomeTabs)
        {
            homePage.TabByName(tab).Click();
            homePage.NavBar.TabByName(tab).SelectedStatus.Should().BeTrue();
            homePage.NavBar.HomeTab.Click();
        }
    }
}