public class SendResetPasswordNotification : BaseUITest
{
    [Test, TestCaseId("1254609")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(SendResetPasswordNotificationDataProvider))]
    public void SendResetPasswordNotificationTest(SendResetPasswordNotificationTestData data)
    {
        var userPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToUsersPage();
        var userControl = userPage.SearchForUser(data.Credentials.Username).GoToUserControl();
        userControl.ResetPasswordBtn.Click();
        userPage.CommonElement.ConfirmBtn.Click();
        using (new AssertionScope())
        {
            userPage.CommonElement.SuccessPopUp.Visibility.Should().BeTrue();
            userPage.CommonElement.SuccessPopUp.Text.Should().Contain("An email has been sent to user to reset password.");
        }
    }
}