public class SearchForWrongUser : BaseUITest
{
    [Test, TestCaseId("1013062")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(SearchForWrongUserDataProvider))]
    public void SearchForWrongUserTest(SearchForWrongUserTestData data)
    {
        var wrongUser = "wrongUser@wrongemail.com";
        var homepage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        homepage.GoToUsersPage().SearchUserInput.TypeText(wrongUser);
        homepage.CommonElement.WarningPopUp.Text.Should().Contain($"Sorry, we couldn't find any results with \"{wrongUser}\"");
    }
}