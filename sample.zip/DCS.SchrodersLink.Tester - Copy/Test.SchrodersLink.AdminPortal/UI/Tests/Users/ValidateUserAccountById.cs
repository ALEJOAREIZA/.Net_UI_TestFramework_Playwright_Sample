
public class ValidateUserAccountById : BaseUITest
{
    [Test, TestCaseId("934454")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(ValidateUserAccountTesDataProvider))]
    public void ValidateUserAccountTest(ValidateUserAccountTestData data)
    {
        var homepage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        var userAccountTab = homepage.GoToUsersPage().SearchForUser(data.Credentials.Username).GoToUserAccount();
        userAccountTab.Account(data.AccountId).Visibility.Should().BeTrue();
    }
}