public class AddRemoveNPVAccount : BaseUITest
{
    [Test, TestCaseId("988938")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(AddRemoveNPVAccountDataProvider))]
    public void AddRemoveNPVAccountTest(AddRemoveNPVAccountTestData data)
    {
        var homePage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        var userAccount = homePage.GoToUsersPage().SearchForUser(data.Credentials.Username).GoToUserAccount();
        userAccount.AddNewAccount(data.NPVAccountsCode);
        userAccount.CommonElement.GetSuccessAlertMessage().Should().Contain("Accounts have been added");
        userAccount.Account(data.NPVAccountsCode.First()).Visibility.Should().BeTrue();
        userAccount.RemoveSingleAccount(data.NPVAccountsCode.First());
        userAccount.CommonElement.GetSuccessAlertMessage().Should().Contain("Accounts have been removed");
        userAccount.Account(data.NPVAccountsCode.First()).Visibility.Should().BeFalse();
    }
}