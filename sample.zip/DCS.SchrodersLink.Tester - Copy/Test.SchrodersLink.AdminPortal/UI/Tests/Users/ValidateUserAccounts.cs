public class ValidateUserAccounts : BaseUITest
{
    [Test, TestCaseId("976027")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(ValidateAccountTableInfoDataProvider))]
    public void ValidateAccountTableInfoTest(ValidateAccountTableInfoTestData data)
    {
        var userPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToUsersPage();
        var userAccount = userPage.SearchForUser(data.Credentials.Username).GoToUserAccount();
        userAccount.AccountTableList.Count().Should().Be(3);
    }
}