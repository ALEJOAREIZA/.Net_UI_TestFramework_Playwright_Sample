public class SearchForAccount : BaseUITest
{
    [Test, TestCaseId("976024")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(SearchForAccountDataProvider))]
    public void SearchForAccountTest(SearchForAccountTestData data)
    {
        var userPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToUsersPage();
        var userAccount = userPage.SearchForUser(data.Credentials.Username).GoToUserAccount();
        userAccount.SearchforAnAccount(data.NPVAccountCode);
        userAccount.AccountTableList.Count().Should().Be(1);
        userAccount.AccountTableList.Text.Should().Contain("Gyrus Retirement & Death Benefits Scheme SPML Portfolio");
    }
}