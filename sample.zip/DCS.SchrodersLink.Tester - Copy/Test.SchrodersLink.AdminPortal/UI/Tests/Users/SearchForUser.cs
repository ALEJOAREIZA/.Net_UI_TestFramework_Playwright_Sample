public class SearchForUser : BaseUITest
{
    [Test, TestCaseId("984540")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(SearchForUserDataProvider))]
    public void SearchForUserTest(SearchForUserTestData data)
    {
        var homepage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        homepage.GoToUsersPage().SearchForUser(data.Credentials.Username).SearchUserInputValue.Should().Contain(data.Credentials.Username);
    }
}