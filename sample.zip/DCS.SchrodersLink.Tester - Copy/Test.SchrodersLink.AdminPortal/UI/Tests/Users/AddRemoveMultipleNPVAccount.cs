public class AddRemoveMultipleNPVAccount : BaseUITest
{
    [Test, TestCaseId("875129")]
    [TestLevel(TestCaseLevel.UI), TestType(TestCaseType.Regression)]
    [TestCaseSource(typeof(AddRemoveMultipleNPVAccountDataProvider))]
    [Ignore("Bug found 1286260")]
    public void AddRemoveMultipleNPVAccountTest(AddRemoveMultipleNPVAccountTestData data)
    {
        var homePage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        var userAccount = homePage.GoToUsersPage().SearchForUser(data.Credentials.Username).GoToUserAccount();
        userAccount.AddNewAccount(data.NPVAccountsCode);
        userAccount.CommonElement.GetSuccessAlertMessage().Should().Contain("Accounts have been added");
        userAccount.Account(data.NPVAccountsCode[0]).Visibility.Should().BeTrue();
        userAccount.Account(data.NPVAccountsCode[1]).Visibility.Should().BeTrue();
        userAccount.RemoveMultipleAccounts(data.NPVAccountsCode);
        userAccount.CommonElement.GetSuccessAlertMessage().Should().Contain("Accounts have been removed");
        userAccount.Account(data.NPVAccountsCode[0]).Visibility.Should().BeFalse();
        userAccount.Account(data.NPVAccountsCode[1]).Visibility.Should().BeFalse();
    }
}