public class ValidateUserControlInfo : BaseUITest
{
    [Test, TestCaseId("1253808")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(ValidateUserControlInfoDataProvider))]
    public void ValidateUserControlInfoTest(ValidateUserControlInfoTestData data)
    {
        var homepage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        var userControl = homepage.GoToUsersPage().SearchForUser(data.Credentials.Username).GoToUserControl();
        var userInfoTxt = userControl.UserControlInfo.Text;
        using (new AssertionScope())
        {
            userInfoTxt.Should().NotBeNullOrEmpty().And.Contain(data.Credentials.Username);
        }
    }
}