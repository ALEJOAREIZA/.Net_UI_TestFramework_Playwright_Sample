public class UpdateUserRoles : BaseUITest
{
    [Test, TestCaseId("1283207")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(UpdateUserRolesDataProvider))]
    public void UpdateUserRolesTest(UpdateUserRolesTestData data)
    {
        var usersPage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password).GoToUsersPage();
        var userRole = usersPage.SearchForUser(data.Credentials.Username).GoToUserRole();
        userRole.RoleCheckBoxByName(data.UserRoles.Invoice).Check();
        userRole.RoleCheckBoxByName(data.UserRoles.Auditor).Check();
        userRole.RoleCheckBoxByName(data.UserRoles.NonClientView).EnabledStatus.Should().BeFalse();
        userRole.RoleCheckBoxByName(data.UserRoles.Invoice).Uncheck();
        userRole.RoleCheckBoxByName(data.UserRoles.Auditor).Uncheck();
        userRole.RoleCheckBoxByName(data.UserRoles.NonClientView).EnabledStatus.Should().BeTrue();
        userRole.RoleCheckBoxByName(data.UserRoles.NonClientView).Check();
        userRole.RoleCheckBoxByName(data.UserRoles.Invoice).EnabledStatus.Should().BeFalse();
        userRole.RoleCheckBoxByName(data.UserRoles.Auditor).EnabledStatus.Should().BeFalse();
        userRole.UpdateButton.Click();
        usersPage.CommonElement.ProceedButton.Click();
        usersPage.CommonElement.SuccessPopUp.Text.Should().Contain("User roles has been updated successfully");
        userRole.RoleCheckBoxByName(data.UserRoles.NonClientView).CheckedStatus.Should().BeTrue();
        userRole.RoleCheckBoxByName(data.UserRoles.NonClientView).Uncheck();
        userRole.UpdateButton.Click();
        usersPage.CommonElement.ProceedButton.Click();
        usersPage.CommonElement.SuccessPopUp.Text.Should().Contain("User roles has been updated successfully");
        userRole.RoleCheckBoxByName(data.UserRoles.NonClientView).CheckedStatus.Should().BeFalse();
    }
}