public class DownloadAllUsersCSVfile : BaseUITest
{
    [Test, TestCaseId("1253809")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(DownloadAllUsersCSVfileDataProvider))]
    public void DownloadAllUsersCSVfileTest(DownloadAllUsersCSVfileTestData data)
    {
        var homepage = AdminPortal.AuthPage.Login(data.Credentials.Username, data.Credentials.Password);
        homepage.GoToUsersPage().DownloadUserBtn.ClickToDownload();
    }
}