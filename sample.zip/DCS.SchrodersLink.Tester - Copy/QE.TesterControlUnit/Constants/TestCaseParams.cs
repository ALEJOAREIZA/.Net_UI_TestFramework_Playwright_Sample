public enum TestCaseType
{
    Regression,
    Smoke,
    Sanity
}
public enum TestCaseLevel
{
    API,
    UI
}
public enum TestEnvironment
{
    DIT,
    UAT
}
public enum Microservice
{
    MessagingCenter
}