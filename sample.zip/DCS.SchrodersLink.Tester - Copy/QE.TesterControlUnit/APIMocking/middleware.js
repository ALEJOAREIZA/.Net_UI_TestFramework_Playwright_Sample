module.exports = function (req, res, next) {
    if(req.url.includes('myClientService') && req.method === 'POST'){
        req.method = 'GET'
        req.query = req.body
    }
    next()
}