public sealed class QETestContext
{
    private QETestContext() { }
    private static QETestContext instance;
    public static QETestContext CurrentContext
    {
        get
        {
            instance ??= new QETestContext();
            return instance;
        }
    }
    private static MethodInfo CurrentTest { get; set; } = AppDomain.CurrentDomain.GetAssemblies()
        .SelectMany(x => x.GetTypes())
        .SelectMany(x => x.GetMethods())
        .FirstOrDefault(x => x.Name == TestContext.CurrentContext.Test.MethodName);
    public string TestCaseType { get; } = ((TestTypeAttribute)CurrentTest.GetCustomAttributes(typeof(TestTypeAttribute), false).FirstOrDefault()).Name;
    public string TestCaseLevel { get; } = ((TestLevelAttribute)CurrentTest.GetCustomAttributes(typeof(TestLevelAttribute), false).FirstOrDefault()).Name;
    public string TestCaseId { get; } = ((TestCaseIdAttribute)CurrentTest.GetCustomAttributes(typeof(TestCaseIdAttribute), false).FirstOrDefault()).TestCaseId;
    public List<TestStep> TestCaseSteps { get; private set; } = [];
}