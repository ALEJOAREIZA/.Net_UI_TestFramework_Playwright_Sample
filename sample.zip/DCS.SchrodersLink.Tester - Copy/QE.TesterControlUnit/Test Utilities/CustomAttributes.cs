[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Assembly, AllowMultiple = true)]
public class TestTypeAttribute : CategoryAttribute
{
    public TestTypeAttribute(TestCaseType name) => categoryName = name.ToString();
}

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Assembly, AllowMultiple = false)]
public class TestLevelAttribute : CategoryAttribute
{
    public TestLevelAttribute(TestCaseLevel name) => categoryName = name.ToString();
}

[AttributeUsage(AttributeTargets.Method | AttributeTargets.Assembly, AllowMultiple = false)]
public class MicroserviceAttribute : CategoryAttribute
{
    public MicroserviceAttribute(Microservice name) => categoryName = name.ToString();
}

[AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
public class TestCaseIdAttribute(string testCaseId) : Attribute()
{
    public string TestCaseId { get; } = testCaseId;
}