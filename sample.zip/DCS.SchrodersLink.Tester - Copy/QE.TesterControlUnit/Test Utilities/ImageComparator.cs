public class ImageComparator
{
    public static bool CompareImages(string expectedImage, string currentImage)
    {
        using var image1 = SixLabors.ImageSharp.Image.Load<Rgba32>(expectedImage);
        using var image2 = SixLabors.ImageSharp.Image.Load<Rgba32>(currentImage);

        if (image1.Width != image2.Width || image1.Height != image2.Height)
        {
            return false;
        }

        var outputFilePath = Path.Combine(Path.GetDirectoryName(currentImage), $"imageComparatorResult_{DateTime.Now:yyMMdd-HHmmss}.png");
        var isEqual = true;
        var borderColor = new Rgba32(255, 0, 0, 255);
        int minX = image1.Width, minY = image1.Height, maxX = -1, maxY = -1;
        var borderSize = 5;

        for (var x = 0; x < image1.Width; x++)
        {
            for (var y = 0; y < image1.Height; y++)
            {
                var pixel1 = image1[x, y];
                var pixel2 = image2[x, y];

                if (pixel1 != pixel2)
                {
                    minX = Math.Min(minX, x);
                    minY = Math.Min(minY, y);
                    maxX = Math.Max(maxX, x);
                    maxY = Math.Max(maxY, y);
                    isEqual = false;
                }
            }
        }
        if (!isEqual)
        {
            minX = Math.Max(0, minX - borderSize);
            minY = Math.Max(0, minY - borderSize);
            maxX = Math.Min(image2.Width - 1, maxX + borderSize);
            maxY = Math.Min(image2.Height - 1, maxY + borderSize);

            for (var x = minX; x <= maxX; x++)
            {
                image2[x, minY] = borderColor;
                image2[x, maxY] = borderColor;
            }

            for (var y = minY; y <= maxY; y++)
            {
                image2[minX, y] = borderColor;
                image2[maxX, y] = borderColor;
            }
            image2.Save(outputFilePath);
        }
        return isEqual;
    }
}

