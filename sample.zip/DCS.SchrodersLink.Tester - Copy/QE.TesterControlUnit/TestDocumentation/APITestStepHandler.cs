public class APITestStepHandler(HttpMessageHandler innerHandler = null) : DelegatingHandler(innerHandler ?? new HttpClientHandler())
{
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var host = $"{request.RequestUri.Scheme}://{request.RequestUri.Host}{request.RequestUri.AbsolutePath[..(request.RequestUri.AbsolutePath.IndexOf('v') + 2)]}";
        var resource = request.RequestUri.AbsolutePath[(request.RequestUri.AbsolutePath.IndexOf('v') + 2)..];
        var query = request.RequestUri.Query;
        var text = "With ";
        const string success = "Then the StatusCode should be: 200";

        var methodRequestTestStep = new TestStep() { Action = $"When a {request.Method} request is made to {host}{resource}" };
        var queryTestStep = new TestStep();
        var contentRequestTestStep = new TestStep();

        if (!string.IsNullOrEmpty(query))
        {
            queryTestStep.Action = $"{text}Query: {query}";
            text = "And ";
        }
        if (request.Content != null)
        {
            if (request.Content is StringContent || this.IsTextBasedContentType(request.Headers) || this.IsTextBasedContentType(request.Content.Headers))
            {
                var result = await request.Content.ReadAsStringAsync(cancellationToken);
                contentRequestTestStep.Action = $"{text}Content request: {result}";
            }
        }

        var response = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);

        if (queryTestStep.Action is not null)
        {
            QETestContext.CurrentContext.TestCaseSteps.Add(methodRequestTestStep);
            if (contentRequestTestStep.Action is not null)
            {
                contentRequestTestStep.ExpectedResult = success;
                QETestContext.CurrentContext.TestCaseSteps.Add(queryTestStep);
                QETestContext.CurrentContext.TestCaseSteps.Add(contentRequestTestStep);
            }
            else
            {
                queryTestStep.ExpectedResult = success;
                QETestContext.CurrentContext.TestCaseSteps.Add(queryTestStep);
            }
        }
        else
        {
            if (contentRequestTestStep.Action is not null)
            {
                contentRequestTestStep.ExpectedResult = success;
                QETestContext.CurrentContext.TestCaseSteps.Add(methodRequestTestStep);
                QETestContext.CurrentContext.TestCaseSteps.Add(contentRequestTestStep);
            }
            else
            {
                methodRequestTestStep.ExpectedResult = success;
                QETestContext.CurrentContext.TestCaseSteps.Add(methodRequestTestStep);
            }
        }

        if (response.Content != null)
        {
            if (response.Content is StringContent || this.IsTextBasedContentType(response.Headers) ||
                this.IsTextBasedContentType(response.Content.Headers))
            {
                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                QETestContext.CurrentContext.TestCaseSteps.Add(new TestStep() { Action = "", ExpectedResult = $"And the Content response should be: {result}" });
            }
        }
        return response;
    }
    private readonly string[] types = ["html", "text", "xml", "json", "txt", "x-www-form-urlencoded"];
    private bool IsTextBasedContentType(HttpHeaders headers)
    {
        if (!headers.TryGetValues("Content-Type", out var values))
        {
            return false;
        }
        var header = string.Join(" ", values).ToLowerInvariant();
        return types.Any(header.Contains);
    }
}