public class ADOTestCaseService
{
    public static IADOTestCase Client => new RefitClientBuilder<IADOTestCase>()
        .WithHttpClient(new HttpClientBuilder()
               .WithBaseAddress("https://dev.azure.com/schroders/Domain-Distribution/_apis/wit/")
               .WithRequestHandler(new TokenRequestHandler(
                    new ConfigurationManager<ADOToken>()
                    .WithConfigFiles($"TestDocumentation/Token.ConfigData.json")
                    .WithUserSecrets<ADOToken>()
                    .Get().AccessToken))
               .Build())
        .Build();
    public static async Task AddTestSteps(string testCaseId, List<TestStep> testCaseSteps)
    {
        var innerTestStepBody = JsonConvert.SerializeObject(new List<ADOTestStepBody>
        {
            new ADOTestStepBody
            {
                Op = "add",
                Value = new ADOTestStepBuilder(testCaseSteps).ToString()
            }
        }, Formatting.Indented);
        try
        {
            var response = await Client.AddTestSteps(testCaseId, new StringContent(innerTestStepBody, Encoding.UTF8, "application/json-patch+json"));
            if (!response.IsSuccessStatusCode)
            {
                Console.WriteLine($"Failed to add test steps to ADO test case with error {response.Error}");
            }
        }
        catch (Exception ex)
        {

            throw new ArgumentException($"Failed to add test steps to ADO test case with error {ex.Message}");

        }
    }
}