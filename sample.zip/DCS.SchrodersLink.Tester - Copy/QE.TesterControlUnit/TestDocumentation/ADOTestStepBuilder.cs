public class ADOTestStepBuilder
{
    private readonly InnerTestStep root = new InnerTestStep();
    private const int TestStepLimit = 750;
    private int testStepcounter = 1;
    public ADOTestStepBuilder(List<TestStep> testSteps)
    {
        root.Step = "steps id=\"0\"";
        foreach (var testStep in testSteps)
        {
            if (!string.IsNullOrEmpty(testStep.Action))
            {
                testStep.Action = testStep.Action.Contains('&') ? testStep.Action.Replace("&", "") : testStep.Action;
                testStep.Action = testStep.Action.Length > TestStepLimit ? $"{testStep.Action[..TestStepLimit]}..." : testStep.Action;
            }
            if (!string.IsNullOrEmpty(testStep.ExpectedResult))
            {
                testStep.ExpectedResult = testStep.ExpectedResult.Contains('&') ? testStep.ExpectedResult.Replace("&", "") : testStep.ExpectedResult;
                testStep.ExpectedResult = testStep.ExpectedResult.Length > TestStepLimit ? $"{testStep.ExpectedResult[..TestStepLimit]}..." : testStep.ExpectedResult;
            }
            AddTestStep(testStep.Action, testStep.ExpectedResult);
        }
    }
    private void AddTestStep(string testStepAction, string testStepExpectedResult)
    {
        var testStepId = $"step id=\"{testStepcounter}\" type=\"ValidateStep\"";
        var e = new InnerTestStep(testStepId, testStepAction, testStepExpectedResult);
        root.Elements.Add(e);
        testStepcounter++;
    }
    public override string ToString() => root.ToString();
    public class InnerTestStep
    {
        public string Step { get; set; }
        public string ExpectedResult { get; set; }
        public string Action { get; set; }
        public List<InnerTestStep> Elements { get; set; } = [];
        private const int IndentSize = 2;
        public InnerTestStep(string step, string action, string expectedResult)
        {
            Step = step;
            Action = action;
            ExpectedResult = expectedResult;
        }
        public InnerTestStep()
        {

        }
        private string ToStringImpl(int indent)
        {
            var sb = new StringBuilder();
            var i = new string(' ', IndentSize * indent);
            sb.AppendLine($"{i} <{Step}>");
            sb.Append(new string(' ', IndentSize * (indent + 1)));
            sb.AppendLine($"<parameterizedString isformatted=\"true\">{Action}</parameterizedString>");
            sb.AppendLine($"<parameterizedString isformatted=\"true\">{ExpectedResult}</parameterizedString>");

            foreach (var e in Elements)
            {
                sb.Append(e.ToStringImpl(indent + 1));
            }
            sb.AppendLine($"{i} </{Step.Split(' ')[0]}>");
            return sb.ToString();
        }
        public override string ToString() => ToStringImpl(0);
    }
}