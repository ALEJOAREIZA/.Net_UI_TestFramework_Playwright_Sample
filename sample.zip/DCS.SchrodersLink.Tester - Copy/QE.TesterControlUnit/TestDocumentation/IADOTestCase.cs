public interface IADOTestCase
{
    [Patch("/workitems/{testCaseID}?api-version=7.1-preview.3")]
    Task<IApiResponse> AddTestSteps(string testCaseID, [Body] StringContent adoTestStepBody);
}