public class TokenRequestHandler(string accessToken) : DelegatingHandler
{
    private readonly string authorizationInfo = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes("test" + ":" + accessToken));

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        request.Headers.Add("Authorization", authorizationInfo);
        return base.SendAsync(request, cancellationToken);
    }
}