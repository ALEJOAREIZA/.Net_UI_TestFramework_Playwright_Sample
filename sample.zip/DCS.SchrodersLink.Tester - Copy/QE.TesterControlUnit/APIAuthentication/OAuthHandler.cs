public class OAuthHandler : BaseAuthenticationHandler
{
    private readonly APITracingManager trace = APITracingManager.GetInstance();
    private readonly string bearerToken;
    public OAuthHandler(APIAuthSettings oAuthSettings)
    {
        if (oAuthSettings.Credentials.Username is null or "" || oAuthSettings.Credentials.Password is null or "")
        {
            throw new ArgumentException($"Credentials cant be null or empty");
        }
        trace.Write($"With Username {oAuthSettings.Credentials.Username}");
        foreach (var property in typeof(APIAuthSettings).GetProperties())
        {
            var propValue = property.GetValue(oAuthSettings, null).ToString();
            if (string.IsNullOrEmpty(propValue))
            {
                throw new ArgumentException($"OAuth params cant be null or empty");
            }
        }
        var payload = new FormUrlEncodedContent(new List<KeyValuePair<string, string>>
        {
            new KeyValuePair<string, string>("client_id", oAuthSettings.ClientId),
            new KeyValuePair<string, string>("scope", oAuthSettings.Scope),
            new KeyValuePair<string, string>("client_secret", oAuthSettings.ClientSecret),
            new KeyValuePair<string, string>("username", oAuthSettings.Credentials.Username),
            new KeyValuePair<string, string>("password", oAuthSettings.Credentials.Password),
            new KeyValuePair<string, string>("grant_type","password")
        });
        try
        {
            var request = new RefitClientBuilder<IAuthentication>()
            .WithHttpClient(new HttpClientBuilder()
                .WithBaseAddress(oAuthSettings.AuthAddress)
                .Build())
            .Build()
            .GetToken(oAuthSettings.AccessTokenResource, payload).Result;
            if (!request.IsSuccessStatusCode)
            {
                throw new ArgumentException($"{request.StatusCode}");
            }
            bearerToken = request.Content.AccessToken;
            QETestContext.CurrentContext.TestCaseSteps.Add(new TestStep() { Action = $"Given The user {oAuthSettings.Credentials.Username} is authenticated with OAuth" });
        }
        catch (Exception ex)
        {
            throw new ArgumentException($"Api Client failed connecting with message: {ex.Message}");
        }
    }
    protected override AuthenticationHeaderValue GetAuthHeader() => new("Bearer", bearerToken);
}