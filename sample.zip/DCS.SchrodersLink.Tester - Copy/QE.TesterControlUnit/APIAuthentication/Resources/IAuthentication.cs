internal interface IAuthentication
{
    [Post("/{accessTokenResource}")]
    Task<ApiResponse<AccessTokenData>> GetToken(string accessTokenResource, [Body(BodySerializationMethod.UrlEncoded)] FormUrlEncodedContent body);
}