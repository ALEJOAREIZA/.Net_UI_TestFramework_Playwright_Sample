public class BearerTokenAuthHandler : BaseAuthenticationHandler
{
    private readonly APITracingManager trace = APITracingManager.GetInstance();
    private readonly string accessToken;
    public BearerTokenAuthHandler(APIAuthSettings bearerTokenSettings)
    {
        if (bearerTokenSettings.Credentials.Username is null or "" || bearerTokenSettings.Credentials.Password is null or "")
        {
            throw new ArgumentException($"Credentials cant be null or empty");
        }
        trace.Write($"with Username {bearerTokenSettings.Credentials.Username}");
        var payload = new FormUrlEncodedContent(new List<KeyValuePair<string, string>>
        {
            new KeyValuePair<string, string>("username", bearerTokenSettings.Credentials.Username),
            new KeyValuePair<string, string>("password", bearerTokenSettings.Credentials.Password),
            new KeyValuePair<string, string>("grant_type","password")
        });
        try
        {
            accessToken = new RefitClientBuilder<IAuthentication>()
            .WithHttpClient(new HttpClientBuilder()
                .WithBaseAddress(bearerTokenSettings.AuthAddress)
                .Build())
            .Build()
            .GetToken(bearerTokenSettings.AccessTokenResource, payload).Result.Content.AccessToken;
            QETestContext.CurrentContext.TestCaseSteps.Add(new TestStep() { Action = $"Given The user {bearerTokenSettings.Credentials.Username} is authenticated with bearerToken" });

        }
        catch (Exception ex)
        {
            throw new ArgumentException($"Api Client Authentication failed with error {ex.Message}");
        }
    }
    protected override AuthenticationHeaderValue GetAuthHeader() => new("Bearer", accessToken);
}