public sealed class APITracingManager
{
    public bool Logging { get; set; } = true;
    public string TracingDirPath { get; set; } = $"{Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName}/TraceData";
    public string TracingFileName { get; set; } = $"{DateTime.Now:ddMMyy-HHmmss}_Trace";
    public string TracingFilePath { get; private set; }

    private APITracingManager()
    {

    }
    private static APITracingManager instance;
    public static APITracingManager GetInstance()
    {
        instance ??= new APITracingManager();
        return instance;
    }
    public void Write(string message)
    {
        Directory.CreateDirectory(TracingDirPath);
        if (Logging)
        {
            var dateHour = $"{DateTime.Now:yyyy-MM-dd h:mm:ss tt}";
            TracingFilePath = $"{TracingDirPath}/{TracingFileName}.log";
            using var writer = new StreamWriter(TracingFilePath, true);
            writer.WriteLine($"{dateHour}: {message}");
        }
    }
}