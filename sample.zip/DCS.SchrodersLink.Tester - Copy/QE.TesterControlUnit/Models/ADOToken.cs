public class ADOToken
{
    public string AccessToken { get; set; }
}