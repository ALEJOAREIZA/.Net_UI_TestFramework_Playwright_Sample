public class APIEnvConfig
{
    public APIAuthSettings APIAuthSettings { get; set; }
    public string BaseAddress { get; set; }
    public TestEnvironment TestEnvironment { get; set; }
}