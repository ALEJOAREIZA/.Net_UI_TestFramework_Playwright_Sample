public class UIEnvConfig
{
    public string BaseAddress { get; set; }
    public TestEnvironment TestEnvironment { get; set; }
}