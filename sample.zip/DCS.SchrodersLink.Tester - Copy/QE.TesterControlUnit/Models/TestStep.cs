public class TestSteps
{
    public List<TestStep> TestStep { get; set; }
}
public class TestStep
{
    public string Action { get; set; }
    public string ExpectedResult { get; set; }
}
public class ADOTestStepBody
{
    [JsonPropertyName("op")]
    public string Op { get; set; }

    [JsonPropertyName("path")]
    public string Path { get; set; } = "/fields/Microsoft.VSTS.TCM.Steps";

    [JsonPropertyName("value")]
    public string Value { get; set; }
}