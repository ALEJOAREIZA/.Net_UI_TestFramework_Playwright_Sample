public class APIAuthSettings
{
    public string AuthAddress { get; set; }
    public string AccessTokenResource { get; set; }
    public string ClientId { get; set; }
    public string Scope { get; set; }
    public string ClientSecret { get; set; }
    public Credentials Credentials { get; set; }
}