public class AdminPortalUI(IUIDriver uiDriver)
{
    private readonly IUIDriver uiDriver = uiDriver;

    public AuthPage AuthPage => new AuthPage(uiDriver);
    public HomePage HomePage => new HomePage(uiDriver);
    public void ChangeToTab(int pageNumber) => uiDriver.ChangeToTab(pageNumber);
    public void BackToMainTab() => uiDriver.ChangeToTab(1);
    public void CloseCurrentTab() => uiDriver.CloseCurrentTab();
    public void NavigateToPage(string url) => uiDriver.NavigateToPage(url);
    public string GetPageTitle() => uiDriver.GetPageTitle();
    public string TakeScreenshot() => uiDriver.TakeScreenshot();
}