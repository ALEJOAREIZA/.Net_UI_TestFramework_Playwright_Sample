﻿public class EmailNotification
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("body")]
    public string Message { get; set; }

    [JsonPropertyName("recipients")]
    public string Recipient { get; set; }
    public string PortfolioName { get; set; }
}
