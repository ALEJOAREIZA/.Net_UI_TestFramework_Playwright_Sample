public class AdminPortalUserRoles
{
    public string Invoice { get; set; }
    public string Auditor { get; set; }
    public string NonClientView { get; set; }
}