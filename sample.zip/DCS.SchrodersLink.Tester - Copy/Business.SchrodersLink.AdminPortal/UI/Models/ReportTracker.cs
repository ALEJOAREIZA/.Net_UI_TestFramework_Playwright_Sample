﻿public class ReportTracker
{
    public List<ReportTrackerPortfolio> Portfolios { get; set; }
    public string StartDate { get; set; }
    public string EndDate { get; set; }
}
public class ReportTrackerPortfolio
{
    public string Code { get; set; }
    public string Name { get; set; }
}