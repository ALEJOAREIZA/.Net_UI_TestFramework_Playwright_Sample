public class UsersPage : BasePage
{
    private readonly IUIDriver uidriver;
    public UsersPage(IUIDriver uiDriver) : base(uiDriver)
    {
        this.uidriver = uiDriver;
        if (!NavBar.UsersTab.SelectedStatus)
        {
            NavBar.UsersTab.Click();
        }
    }
    public UserControlTab GoToUserControl() => new UserControlTab(uidriver);
    public UserRoleTab GoToUserRole() => new UserRoleTab(uidriver);
    public UserAccountTab GoToUserAccount() => new UserAccountTab(uidriver);
    public Button DownloadUserBtn => UI.Button(new UIElementSpec("Download User button", FindBy.Css("[title='Download a csv of all users']")));
    public SearchInput SearchUserInput => UI.SearchInput(new UIElementSpec("Search User Input", FindBy.Css(".search-bar-wrapper input")));
    public string SearchUserInputValue => SearchUserInput.GetAttribute("value");
    public CustomElement SearchUserDropDownOptions(string keywords) => UI.CustomElement(new UIElementSpec($"{keywords} option", FindBy.Xpath($"//div[@class='ant-select-item-option-content'][contains(., '{keywords}')]")));
    public UsersPage SearchForUser(string keywords)
    {
        SearchUserInput.TypeText(keywords);
        SearchUserDropDownOptions(keywords).Click();
        return this;
    }
}
public class UserControlTab
{
    private readonly UIElement ui;
    public UserControlTab(IUIDriver uiDriver)
    {
        ui = new UIElement(uiDriver);
        if (!UsersControlTab.SelectedStatus)
        {
            UsersControlTab.Click();
        }
    }
    public Tab UsersControlTab => ui.Tab(new UIElementSpec($"User Control Tab", FindBy.Text("User Control")));
    public CustomElement UserControlInfo => ui.CustomElement(new UIElementSpec($"User Control Container", FindBy.Css(".user-control__info")));
    public Button ResetPasswordBtn => ui.Button(new UIElementSpec("Reset Password Button", FindBy.Css("[title='Send a regular password reset in case the user forgets the password']")));
}
public class UserRoleTab
{
    private readonly UIElement ui;
    public UserRoleTab(IUIDriver uiDriver)
    {
        ui = new UIElement(uiDriver);
        if (!UsersRoleTab.SelectedStatus)
        {
            UsersRoleTab.Click();
        }
    }
    public Tab UsersRoleTab => ui.Tab(new UIElementSpec($"User Role Tab", FindBy.Text("User Role")));
    public CheckBox RoleCheckBoxByName(string name) => ui.CheckBox(new UIElementSpec($"{name} User Role", FindBy.Xpath($"//*[@class='user-role']//span[contains(., '{name}')]/..")));
    public Button UpdateButton => ui.Button(new UIElementSpec("Update Button", FindBy.Text("Update")));
    public void UpdateUserRoles(List<string> userRoles)
    {
        foreach (var userRole in userRoles)
        {
            RoleCheckBoxByName(userRole).Check();
        }
    }
}
public class UserAccountTab
{
    private readonly UIElement ui;
    public CommonElement CommonElement { get; set; }
    public UserAccountTab(IUIDriver uiDriver)
    {
        ui = new UIElement(uiDriver);
        CommonElement = new CommonElement(uiDriver);
        if (!UsersAccountTab.SelectedStatus)
        {
            UsersAccountTab.Click();
        }
    }
    public Tab UsersAccountTab => ui.Tab(new UIElementSpec($"User Account Tab", FindBy.Text("User Account")));
    public Button AddNewAccountBtn => ui.Button(new UIElementSpec($"Add New Account Button", FindBy.Xpath("//button/*[text()='Add New Account']")));
    public SearchInput AddNewAccountInput => ui.SearchInput(new UIElementSpec("Add New Account Input", FindBy.Css("input[placeholder='Enter keywords to search']")));
    public CheckBox AddNewAccountCheckBox(string keywords) => ui.CheckBox(new UIElementSpec($"{keywords} option", FindBy.Css($".ant-modal-content [data-row-key='{keywords}'] .ant-checkbox")));
    public CheckBox NPVAccountCheckBox(string keywords) => ui.CheckBox(new UIElementSpec($"{keywords} Check Box", FindBy.Css($".ant-table-tbody [data-row-key='{keywords}'] .ant-checkbox")));
    public CustomElement AccountTableList => ui.CustomElement(new UIElementSpec("Table Row", FindBy.Css("table>tbody>tr[data-row-key]")));
    public CustomElement Account(string keywords) => ui.CustomElement(new UIElementSpec($"{keywords} Account", FindBy.Css($".user-account [data-row-key='{keywords}']")));
    public Button RemoveAccountIcon(string keywords) => ui.Button(new UIElementSpec($"Remove {keywords} Account Icon", FindBy.Css($"[data-row-key='{keywords}'] .remove-icon-container")));
    public Button RemoveAccountBtn => ui.Button(new UIElementSpec($"Remove Account Button", FindBy.Xpath($"//button//*[text()='Remove Account']")));
    public Input SearchAccountInput => ui.Input(new UIElementSpec($"Search Account Input", FindBy.Css(".search-field-input")));

    public UserAccountTab SearchforAnAccount(string keywords)
    {
        SearchAccountInput.TypeText(keywords);
        Thread.Sleep(1000);
        return this;
    }
    public UserAccountTab AddNewAccount(List<string> npvAccountsCode)
    {
        AddNewAccountBtn.Click();
        foreach (var code in npvAccountsCode)
        {
            AddNewAccountInput.TypeText(code);
            AddNewAccountCheckBox(code).Check();
        }
        CommonElement.SaveButton.Click();
        return this;
    }
    public UserAccountTab RemoveSingleAccount(string npvAccountCode)
    {
        RemoveAccountIcon(npvAccountCode).Click();
        CommonElement.RemoveButton.Click();
        return this;
    }
    public UserAccountTab RemoveMultipleAccounts(List<string> npvAccountsCode)
    {
        foreach (var code in npvAccountsCode)
        {
            NPVAccountCheckBox(code).Check();
        }
        RemoveAccountBtn.Click();
        CommonElement.RemoveButton.Click();
        return this;
    }
}