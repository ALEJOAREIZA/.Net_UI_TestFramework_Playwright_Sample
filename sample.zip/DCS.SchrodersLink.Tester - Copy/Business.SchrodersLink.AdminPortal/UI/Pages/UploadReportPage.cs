public class UploadReportPage : BasePage
{
    private readonly IUIDriver uiDriver;
    public UploadReportPage(IUIDriver uiDriver) : base(uiDriver)
    {
        this.uiDriver = uiDriver;
        if (!NavBar.UploadReportTab.SelectedStatus)
        {
            NavBar.UploadReportTab.Click();
        }
    }
    public PortfolioReportTab GotToPortfolioReportsTab() => new PortfolioReportTab(uiDriver);
    public GeneralReportTab GotToGeneralReportsTab() => new GeneralReportTab(uiDriver);
}
public class PortfolioReportTab
{
    private readonly UIElement ui;
    public PortfolioReportTab(IUIDriver uiDriver)
    {
        ui = new UIElement(uiDriver);
        if (!PortfolioReportsTab.SelectedStatus)
        {
            PortfolioReportsTab.Click();
        }
    }
    public Tab PortfolioReportsTab => ui.Tab(new UIElementSpec("Portfolio Reports Tab", FindBy.Css("[data-node-key='portfolio'] [role='tab']")));
    public SearchInput PortfolioSelector => ui.SearchInput(new UIElementSpec("Portfolio Selector", FindBy.Css(".search-selector-input")));
    public Input UploadFilesInput => ui.Input(new UIElementSpec("Upload Files Input", FindBy.Css("[id*='portfolio'] .input-drag-box")));
    public Button ReviewAndPublishButton => ui.Button(new UIElementSpec("Review And Publish Button", FindBy.Xpath("//*[contains(@id, 'portfolio')]//*[text()='Review & Publish']")));
}
public class GeneralReportTab
{
    private readonly UIElement ui;
    public GeneralReportTab(IUIDriver uiDriver)
    {
        ui = new UIElement(uiDriver);
        if (!GeneralReportsTab.SelectedStatus)
        {
            GeneralReportsTab.Click();
        }
    }
    public Tab GeneralReportsTab => ui.Tab(new UIElementSpec("General Reports Tab", FindBy.Css("[data-node-key='general'] [role='tab']")));

    public Input UploadFilesInput => ui.Input(new UIElementSpec("Upload Files Input", FindBy.Css("[id*='general'] .input-drag-box")));
    public Button ReviewAndPublishButton => ui.Button(new UIElementSpec("Review And Publish Button", FindBy.Xpath("//*[contains(@id, 'general')]//*[text()='Review & Publish']")));
}