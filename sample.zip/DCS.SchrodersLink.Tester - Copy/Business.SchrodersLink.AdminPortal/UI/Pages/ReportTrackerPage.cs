public class ReportTrackerPage : BasePage
{
    public ReportTrackerPage(IUIDriver uiDriver) : base(uiDriver)
    {
        if (!NavBar.ReportTrackerTab.SelectedStatus)
        {
            NavBar.ReportTrackerTab.Click();
        }
    }

    public Button PortfolioDropdownButton => UI.Button(new UIElementSpec("Portfolio Dropdown Button", FindBy.Css(".report-tracker__dropdown button")));
    public CheckBox PortfolioByCode(string keywords) => UI.CheckBox(new UIElementSpec($"{keywords} Check Box", FindBy.Css($".ant-table-tbody [data-row-key='{keywords}'] .ant-checkbox")));
    public Input ReportStartDateInput => UI.Input(new UIElementSpec($"Start Date", FindBy.Xpath($"//input[@placeholder='Start date']")));
    public Input ReportEndDateInput => UI.Input(new UIElementSpec($"End Date", FindBy.Xpath($"//input[@placeholder='End date']")));
    public Button GoButton => UI.Button(new UIElementSpec("Go Button", FindBy.Text("Go")));
    public Button ClearButton => UI.Button(new UIElementSpec("Clear Button", FindBy.Text("Clear")));
    public Table ReportTrackerTable => UI.Table(new UIElementSpec("Report Tracker Results", FindBy.Css(".report-tracker__result")));
    public Button DownloadButton => UI.Button(new UIElementSpec("Download Button", FindBy.Text("Download")));

    public void SearchForPortfolioReports(List<string> portfoliosCodes, string startDate, string endDate)
    {
        PortfolioDropdownButton.Click();
        foreach (var portfolioCode in portfoliosCodes)
        {
            PortfolioByCode(portfolioCode).Check();
        }
        ReportStartDateInput.Click().TypeText(startDate);
        ReportEndDateInput.Click().TypeText(endDate).PressEnter();
        GoButton.Click();
    }
    public void DownloadReportTrackerResults() => DownloadButton.ClickToDownload();
}