public class AuthPage(IUIDriver uiDriver)
{
    private readonly UIElement ui = new UIElement(uiDriver);
    private readonly IUIDriver uiDriver = uiDriver;

    public Input UsernameInput => ui.Input(new UIElementSpec("Username", FindBy.Name("loginfmt")));
    public Input PasswordInput => ui.Input(new UIElementSpec("Password", FindBy.Name("passwd")));
    public Button NextBtn => ui.Button(new UIElementSpec("Next Button", FindBy.Xpath("//*[@value='Next']")));
    public Button SignInBtn => ui.Button(new UIElementSpec("Sign In Button", FindBy.Xpath("//*[@value='Sign in']")));

    public HomePage Login(string username, string password)
    {
        UsernameInput.TypeText(username);
        NextBtn.Click();
        PasswordInput.TypeText(password, true);
        SignInBtn.Click();
        return new HomePage(uiDriver);
    }
}