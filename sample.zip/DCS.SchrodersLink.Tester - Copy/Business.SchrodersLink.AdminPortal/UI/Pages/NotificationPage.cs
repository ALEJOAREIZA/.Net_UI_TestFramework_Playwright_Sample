﻿
public class NotificationPage : BasePage
{
    public NotificationPage(IUIDriver uiDriver) : base(uiDriver)
    {
        if (!NavBar.NotificationTab.SelectedStatus)
        {
            NavBar.NotificationTab.Click();
        }
    }

    public SearchInput RecipientInput => UI.SearchInput(new UIElementSpec("Recipient Input", FindBy.Css(".search-selector-input")));
    public CheckBox RecipientCheckbox(string recipient) => UI.CheckBox(new UIElementSpec($"{recipient} Recipient CheckBox", FindBy.Text($"{recipient}")));
    public Button DoneButton => UI.Button(new UIElementSpec($"Done Button", FindBy.Text("Done")));
    public Button SendButton => UI.Button(new UIElementSpec($"Send Button", FindBy.Text("Send")));
    public Button BackButton => UI.Button(new UIElementSpec($"Back Button", FindBy.Text("Back")));
    public Button ConfirmButton => UI.Button(new UIElementSpec($"Confirm Button", FindBy.Text("Confirm")));
    public Input NotificationTitle => UI.Input(new UIElementSpec("Notification Title", FindBy.Css(".notification-title")));
    public Input NotificationMessage => UI.Input(new UIElementSpec("Notification Message", FindBy.Css(".ql-editor")));
    public Button NotificationType(string type) => UI.Button(new UIElementSpec($"{type} Notification Button", FindBy.Css($"#{type} + label")));
    public CustomElement ModalRecipientlist => UI.CustomElement(new UIElementSpec("Modal Recipient List", FindBy.Css(".notification-confirm-recipients-list")));
    public CustomElement ModalNotificationTitle => UI.CustomElement(new UIElementSpec("Modal Notification Title", FindBy.Css(".notification-confirm-message-title")));
    public CustomElement ModalNotificationMessage => UI.CustomElement(new UIElementSpec("Modal Notification Message", FindBy.Css(".notification-confirm-message-content")));

    public void FillCustomNotification(string portfolioName, string recipient, string title, string message)
    {
        RecipientInput.TypeText(portfolioName);
        RecipientCheckbox(recipient).Check();
        DoneButton.Click();
        NotificationType("custom").Click();
        NotificationTitle.TypeText(title);
        NotificationMessage.TypeText(message);
    }
    public void Fill10LossNotification(string portfolioName, string recipient)
    {
        RecipientInput.TypeText(portfolioName);
        RecipientCheckbox(recipient).Check();
        DoneButton.Click();
        NotificationType("default").Click();
    }
}
