public class HomePage(IUIDriver uiDriver) : BasePage(uiDriver)
{
    private readonly IUIDriver uiDriver = uiDriver;

    public Tab TabByName(string tabName) => UI.Tab(new UIElementSpec($"{tabName} Tab", FindBy.Css($".{tabName}")));
    public UsersPage GoToUsersPage()
    {
        TabByName("users").Click();
        return new UsersPage(uiDriver);
    }
    public ReportTrackerPage GoToReportTrackerPage()
    {
        TabByName("reporttracker").Click();
        return new ReportTrackerPage(uiDriver);
    }
    public NotificationPage GoToNotificationPage()
    {
        TabByName("notifications").Click();
        return new NotificationPage(uiDriver);
    }
    public UploadReportPage GoToUploadReportPage()
    {
        TabByName("uploadreport").Click();
        return new UploadReportPage(uiDriver);
    }
}