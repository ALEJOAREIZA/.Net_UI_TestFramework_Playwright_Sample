public class CommonElement(IUIDriver uiDriver)
{
    private readonly UIElement ui = new UIElement(uiDriver);

    public CustomElement SuccessPopUp => ui.CustomElement(new UIElementSpec("Success Alert PopUp", FindBy.Css(".alert-popup.success")));
    public CustomElement WarningPopUp => ui.CustomElement(new UIElementSpec("Success Alert PopUp", FindBy.Css(".alert-popup.notfound")));
    public Button ConfirmBtn => ui.Button(new UIElementSpec("Confirm Button", FindBy.Text("Confirm")));
    public Button ProceedButton => ui.Button(new UIElementSpec("Proceed Button", FindBy.Text("Proceed")));
    public Button SaveButton => ui.Button(new UIElementSpec("Save Button", FindBy.Text("Save")));
    public Button RemoveButton => ui.Button(new UIElementSpec("Remove Button", FindBy.Xpath("//button/*[text()='Remove']")));
    public CustomElement LoadingSpinner => ui.CustomElement(new UIElementSpec("Loading Spinner", FindBy.Css(".loading-spinner")));

    public string GetSuccessAlertMessage()
    {
        var message = SuccessPopUp.Text;
        SuccessPopUp.WaitUntilItDisappears();
        return message;
    }
}