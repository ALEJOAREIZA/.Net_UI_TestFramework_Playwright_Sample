public class NavigationComponent(IUIDriver uiDriver)
{
    private readonly UIElement ui = new UIElement(uiDriver);

    public Tab TabByName(string tabName) => ui.Tab(new UIElementSpec($"{tabName} Tab", FindBy.Css($"li:has([value='{tabName}'])")));
    public Tab HomeTab => ui.Tab(new UIElementSpec("Home Tab", FindBy.Css("[value='home']")));
    public Tab UsersTab => TabByName("users");
    public Tab ReportTrackerTab => TabByName("reporttracker");
    public Tab NotificationTab => TabByName("notifications");
    public Tab UploadReportTab => TabByName("uploadreport");
    public CustomElement ProfileContainer => ui.CustomElement(new UIElementSpec("profile container", FindBy.Css(".username")));
}