public class AdminPortalUIEnvConfig
{
    public UIEnvConfig DIT { get; set; }
    public UIEnvConfig UAT { get; set; }
}