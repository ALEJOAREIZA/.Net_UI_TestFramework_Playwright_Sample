public static class AdminPortalUIConfigManager
{
    public static AdminPortalUIEnvConfig GetSettings()
    {
        var fileName = $"UI/AdminPortalUI.Config.json";
        return new ConfigurationManager<AdminPortalUIEnvConfig>()
            .WithConfigFiles(fileName)
            .Get();
    }
}