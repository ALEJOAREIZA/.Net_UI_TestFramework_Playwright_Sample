public static class AdminPortalApiConfigManager
{
    public static AdminPortalApiConfig GetSettings()
    {
        var fileName = $"API/AdminPortalApi.ConfigData.json";
        return new ConfigurationManager<AdminPortalApiConfig>()
            .WithConfigFiles(fileName)
            .WithUserSecrets<AdminPortalApiConfig>()
            .Get();
    }
    public static AdminPortalApiConfig GetMessagingCenterSettings()
    {
        var fileName = $"API/MessagingCenterApi.ConfigData.json";
        return new ConfigurationManager<AdminPortalApiConfig>()
            .WithConfigFiles(fileName)
            .WithUserSecrets<AdminPortalApiConfig>()
            .Get();
    }
}