public class AdminPortalApiConfig
{
    public APIEnvConfig DIT { get; set; }
    public APIEnvConfig UAT { get; set; }
}