public class AdminPortalAPI(APIEnvConfig adminPortalApiEnvConfig)
{
    private readonly APIEnvConfig adminPortalApiEnvConfig = adminPortalApiEnvConfig;

    public IAdminPortalApi Authenticate(Credentials credentials)
    {
        adminPortalApiEnvConfig.APIAuthSettings.Credentials = credentials;
        return new RefitClientBuilder<IAdminPortalApi>()
        .WithHttpClient(new HttpClientBuilder()
            .WithBaseAddress(adminPortalApiEnvConfig.BaseAddress)
            .WithAuthHandler(new OAuthHandler(adminPortalApiEnvConfig.APIAuthSettings))
            .WithRequestHandler(new APITracingHandler())
            .WithRequestHandler(new APITestStepHandler())
            .Build())
        .Build();
    }
}
public class MessagingCenterlAPI(APIEnvConfig messagingCenterApiEnvConfig)
{
    private readonly APIEnvConfig messagingCenterApiEnvConfig = messagingCenterApiEnvConfig;

    public IMessagingCenter Authenticate(Credentials credentials)
    {
        messagingCenterApiEnvConfig.APIAuthSettings.Credentials = credentials;
        return new RefitClientBuilder<IMessagingCenter>()
        .WithHttpClient(new HttpClientBuilder()
            .WithBaseAddress(messagingCenterApiEnvConfig.BaseAddress)
            .WithAuthHandler(new OAuthHandler(messagingCenterApiEnvConfig.APIAuthSettings))
            .WithRequestHandler(new APITracingHandler())
            .WithRequestHandler(new APITestStepHandler())
            .Build())
        .Build();
    }
}