public interface IHomePage
{
    [Get("/users/info")]
    Task<ApiResponse<CurrentUser>> GetCurrentUserInfo();
}