public interface IReportTrakerPage
{
    [Get("/portfolios/logs/?endDate={endDate}&groupCodes={groupCodes}&startDate={startDate}")]
    Task<ApiResponse<List<PortfolioLog>>> GetPortfolioReports(string groupCodes, string startDate, string endDate);

    [Get("/portfolios/logs/all?endDate={endDate}&groupCodes={groupCodes}&startDate={startDate}")]
    Task<IApiResponse> DownloadPortfolioReports(string groupCodes, string startDate, string endDate);

    [Post("/auditor-reports/update")]
    Task<IApiResponse> SubmitReport([Body] CheckReports checkReports);
}