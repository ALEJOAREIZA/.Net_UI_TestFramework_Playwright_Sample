public interface IAdminPortalApi :
    IHomePage,
    IUserPage,
    IUploadReportPage,
    IReportTrakerPage,
    ISendNotificationPage,
    IMaintainReferenceDataPage
{ }