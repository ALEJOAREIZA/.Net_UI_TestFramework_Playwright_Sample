public interface IUserPage
{
    [Get("/users/list?keywords={keyword}")]
    Task<ApiResponse<User>> GetListOfUsers(string keyword);

    [Get("/groups/list")]
    Task<ApiResponse<List<UserRoles>>> GetUserRoles();

    [Get("/users/all")]
    Task<IApiResponse> GetDownloadListOfUsers();

    [Get("/users/{UserId}/userinfo")]
    Task<ApiResponse<UserData>> GetUserInfoById(string userId);

    [Get("/users/{UserId}/groups")]
    Task<ApiResponse<List<int>>> GetUserRolesById(string userId);

    [Put("/users/{UserId}/groups")]
    Task<IApiResponse> UpdateUserRolesById([Body] List<UserRole> userGroups, string userId);

    [Get("/portfolios/linkages/list?userId={UserId}")]
    Task<ApiResponse<Portfolio>> GetLinkedPortfoliosByUserId(string userId);

    [Post("/users/{UserId}/reset_password")]
    Task<IApiResponse> SendResetPassword(string userId);

    [Get("/portfolios/{UserId}/unlinked-accounts/search")]
    Task<ApiResponse<Portfolio>> GetUnlinkedPortfoliosByUserId(string userId);

    [Post("/portfolios/linkages/save")]
    Task<ApiResponse<List<PortfolioData>>> AddAccount([Body] UserAccount userAccount);

    [Delete("/portfolios/linkages/remove")]
    Task<ApiResponse<bool>> RemoveAccount([Body] List<int> entityIds);
}