public interface IMaintainReferenceDataPage
{
    [Get("/npv/search")]
    Task<ApiResponse<NpvAccounts>> GetNPVAccounts();

    [Get("/npv/newaccountnumber")]
    Task<ApiResponse<string>> GetNextNPVAccountNumber();

    [Post("/npv/upsert")]
    Task<ApiResponse<NpvAccount>> UpsertNewNPVAccount([Body] NpvAccount npvAccount);

    [Get("/reporttypes/search")]
    Task<ApiResponse<ReportTypes>> GetReportTypes();

    [Post("/reporttypes")]
    Task<ApiResponse<ReportType>> UpsertNewReportType([Body] ReportType reportType);
}