public interface IMessagingCenter
{
    [Get("/messages")]
    Task<ApiResponse<List<MessagingCenter>>> GetListOfMessages();

    [Get("/messages/{messageId}")]
    Task<ApiResponse<MessagingCenter>> GetMessageById(int? messageId);

    [Post("/messages")]
    Task<ApiResponse<MessagingCenter>> CreateUpdateMessage([Body] MessagingCenter message);

    [Get("/UserGroups")]
    Task<ApiResponse<List<MessageUserGroup>>> GetUserGroups();

    [Get("/UserRegions")]
    Task<ApiResponse<List<string>>> GetRegions();

    [Get("/users/{userId}/messages")]
    Task<ApiResponse<List<UserMessagingCenter>>> GetUserMessages(string userId);

    [Get("/users/{userId}/messages/{messageId}/dismissal")]
    Task<IApiResponse> DismissMessage(string userId, string messageId);
}