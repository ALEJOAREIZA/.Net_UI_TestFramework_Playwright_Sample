public interface ISendNotificationPage
{
    [Get("/notifications/recipients?keywords={keywords}")]
    Task<ApiResponse<Recipient>> GetRecipientsByKeywords(string keywords);

    [Post("/notifications/enqueue")]
    Task<ApiResponse<Notification>> SendNotification([Body] Notification notification);
}