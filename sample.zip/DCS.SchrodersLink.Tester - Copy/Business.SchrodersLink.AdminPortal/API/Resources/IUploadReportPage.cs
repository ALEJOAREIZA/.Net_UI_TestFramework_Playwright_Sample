public interface IUploadReportPage
{
    [Get("/reports/report-types/list")]
    Task<ApiResponse<DocumentType>> GetAllDocumentTypes();

    [Get("/portfolios/search")]
    Task<ApiResponse<PortfolioUser>> GetPortfolios();
}