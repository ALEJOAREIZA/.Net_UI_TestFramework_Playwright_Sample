public class UserRole
{
    [JsonPropertyName("groupId")]
    public int GroupId { get; set; }

    [JsonPropertyName("isDropped")]
    public bool IsDropped { get; set; }
}