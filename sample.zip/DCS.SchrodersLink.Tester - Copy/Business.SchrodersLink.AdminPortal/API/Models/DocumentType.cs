public class DocumentType
{
    [JsonPropertyName("generalDocumentTypes")]
    public List<GeneralDocumentType> GeneralDocumentTypes { get; set; }

    [JsonPropertyName("portfolioDocumentTypes")]
    public List<PortfolioDocumentType> PortfolioDocumentTypes { get; set; }
}
public class GeneralDocumentType
{
    [JsonPropertyName("documentType")]
    public string DocumentType { get; set; }

    [JsonPropertyName("documentTypeName")]
    public string DocumentTypeName { get; set; }
}

public class PortfolioDocumentType
{
    [JsonPropertyName("documentType")]
    public string DocumentType { get; set; }

    [JsonPropertyName("documentTypeName")]
    public string DocumentTypeName { get; set; }
}