public class CheckReports
{
    [JsonPropertyName("checkedList")]
    public List<int> CheckedList { get; set; }

    [JsonPropertyName("uncheckedList")]
    public List<int> UncheckedList { get; set; }
}