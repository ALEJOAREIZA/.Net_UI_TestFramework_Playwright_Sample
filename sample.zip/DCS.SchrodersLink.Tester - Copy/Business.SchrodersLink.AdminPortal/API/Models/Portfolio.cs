public class PortfolioData
{
    [JsonPropertyName("linkId")]
    public int LinkId { get; set; }

    [JsonPropertyName("portfolioId")]
    public int PortfolioId { get; set; }

    [JsonPropertyName("portfolioCode")]
    public string PortfolioCode { get; set; }

    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }

    [JsonPropertyName("isAccount")]
    public bool IsAccount { get; set; }
}

public class Portfolio
{
    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("portfolios")]
    public List<PortfolioData> Portfolios { get; set; }
}