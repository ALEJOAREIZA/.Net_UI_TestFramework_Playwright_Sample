public class User
{
    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("users")]
    public List<UserData> Users { get; set; }
}
public class UserData
{
    [JsonPropertyName("userId")]
    public string UserId { get; set; }

    [JsonPropertyName("firstName")]
    public string FirstName { get; set; }

    [JsonPropertyName("lastName")]
    public string LastName { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("lockoutStatus")]
    public string LockoutStatus { get; set; }

    [JsonPropertyName("lastLoggedIn")]
    public object LastLoggedIn { get; set; }

    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("viewType")]
    public object ViewType { get; set; }

    [JsonPropertyName("securityQuestionsSet")]
    public bool SecurityQuestionsSet { get; set; }

    [JsonPropertyName("passwordSet")]
    public bool PasswordSet { get; set; }

    [JsonPropertyName("lastChangedPassword")]
    public object LastChangedPassword { get; set; }

    [JsonPropertyName("masterSource")]
    public string MasterSource { get; set; }

    [JsonPropertyName("termsAccepted")]
    public bool TermsAccepted { get; set; }

    [JsonPropertyName("termsLastAcceptanceDate")]
    public object TermsLastAcceptanceDate { get; set; }

    [JsonPropertyName("verificationTime")]
    public object VerificationTime { get; set; }

    [JsonPropertyName("verifiedBy")]
    public object VerifiedBy { get; set; }

    [JsonPropertyName("twoFactorEnabled")]
    public bool TwoFactorEnabled { get; set; }
}
public class CurrentUser
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("roles")]
    public List<string> Roles { get; set; }

    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("allowedRegion")]
    public string AllowedRegion { get; set; }
}