﻿public class MessagingCenter
{
    [JsonPropertyName("id")]
    public int? Id { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("message")]
    public string Message { get; set; }

    [JsonPropertyName("userDismissable")]
    public bool UserDismissable { get; set; }

    [JsonPropertyName("expirationDate")]
    public string ExpirationDate { get; set; }

    [JsonPropertyName("userRegions")]
    public List<string> UserRegions { get; set; }

    [JsonPropertyName("userGroupIds")]
    public List<int> UserGroupIds { get; set; }

    [JsonPropertyName("isActive")]
    public bool IsActive { get; set; }

    [JsonPropertyName("createdByUserId")]
    public string CreatedByUserId { get; set; }

    [JsonPropertyName("modifiedByUserId")]
    public string ModifiedByUserId { get; set; }

    [JsonPropertyName("createdDateTime")]
    public DateTime? CreatedDateTime { get; set; }

    [JsonPropertyName("modifiedDateTime")]
    public DateTime? ModifiedDateTime { get; set; }
}
public class UserMessagingCenter
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("message")]
    public string Message { get; set; }

    [JsonPropertyName("userDismissable")]
    public bool UserDismissable { get; set; }
}
public class UserRoleMessagingCenter
{
    [JsonPropertyName("groupId")]
    public int GroupId { get; set; }

    [JsonPropertyName("isDropped")]
    public bool IsDropped { get; set; }
}
public class MessageUserGroup
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }
}