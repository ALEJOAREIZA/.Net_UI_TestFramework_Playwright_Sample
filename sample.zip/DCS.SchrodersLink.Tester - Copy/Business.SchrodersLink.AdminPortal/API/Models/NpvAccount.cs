public class NpvAccount
{
    [JsonPropertyName("accountCode")]
    public string AccountCode { get; set; }

    [JsonPropertyName("accountName")]
    public string AccountName { get; set; }

    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("reportingCurrency")]
    public string ReportingCurrency { get; set; }

    [JsonPropertyName("isActive")]
    public bool IsActive { get; set; }
}

public class NpvAccounts
{
    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("npvAccounts")]
    public List<NpvAccount> NpvAccountList { get; set; }
}