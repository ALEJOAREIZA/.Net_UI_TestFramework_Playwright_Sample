public class PortfolioLog
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("documentName")]
    public string DocumentName { get; set; }

    [JsonPropertyName("documentType")]
    public string DocumentType { get; set; }

    [JsonPropertyName("documentTypeName")]
    public string DocumentTypeName { get; set; }

    [JsonPropertyName("currentVersionId")]
    public string CurrentVersionId { get; set; }

    [JsonPropertyName("startDate")]
    public DateTime StartDate { get; set; }

    [JsonPropertyName("endDate")]
    public DateTime EndDate { get; set; }

    [JsonPropertyName("creationDate")]
    public DateTime CreationDate { get; set; }

    [JsonPropertyName("exportDate")]
    public DateTime ExportDate { get; set; }

    [JsonPropertyName("frequency")]
    public string Frequency { get; set; }

    [JsonPropertyName("entityCode")]
    public string EntityCode { get; set; }

    [JsonPropertyName("clientLegalName")]
    public string ClientLegalName { get; set; }

    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("reportingGroupCode")]
    public string ReportingGroupCode { get; set; }

    [JsonPropertyName("portfolioGroupCode")]
    public string PortfolioGroupCode { get; set; }

    [JsonPropertyName("fileName")]
    public string FileName { get; set; }

    [JsonPropertyName("folderName")]
    public string FolderName { get; set; }

    [JsonPropertyName("recordStatus")]
    public string RecordStatus { get; set; }

    [JsonPropertyName("transactionStatus")]
    public string TransactionStatus { get; set; }

    [JsonPropertyName("timeStamp")]
    public DateTime TimeStamp { get; set; }

    [JsonPropertyName("auditVisible")]
    public bool AuditVisible { get; set; }

    [JsonPropertyName("unpublished")]
    public bool Unpublished { get; set; }
}

public class PortfolioDate
{
    public string StartDate { get; set; }
    public string EndDate { get; set; }
}