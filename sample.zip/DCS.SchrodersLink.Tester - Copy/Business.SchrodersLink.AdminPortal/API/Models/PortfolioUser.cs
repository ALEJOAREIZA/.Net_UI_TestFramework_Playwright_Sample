public class PortfolioUser
{
    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("portfolios")]
    public List<PortfolioUserData> Portfolios { get; set; }
}
public class PortfolioUserData
{
    [JsonPropertyName("clientName")]
    public string ClientName { get; set; }

    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }

    [JsonPropertyName("portfolioCode")]
    public string PortfolioCode { get; set; }
}