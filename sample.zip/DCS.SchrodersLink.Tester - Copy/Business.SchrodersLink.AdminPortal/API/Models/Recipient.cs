public class Recipient
{
    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("portfolios")]
    public List<RecipientPortfolio> Portfolios { get; set; }
}
public class RecipientPortfolio
{
    [JsonPropertyName("portfolioCode")]
    public string PortfolioCode { get; set; }

    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }

    [JsonPropertyName("reportingGroupName")]
    public string ReportingGroupName { get; set; }

    [JsonPropertyName("recipients")]
    public List<RecipientData> Recipients { get; set; }
}

public class RecipientData
{
    [JsonPropertyName("userId")]
    public string UserId { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }
}