public class RecipientNotification
{
    [JsonPropertyName("portfolioCode")]
    public string PortfolioCode { get; set; }

    [JsonPropertyName("userIds")]
    public List<string> UserIds { get; set; }
}

public class Notification
{
    [JsonPropertyName("type")]
    public int Type { get; set; }

    [JsonPropertyName("subject")]
    public string Subject { get; set; }

    [JsonPropertyName("body")]
    public string Body { get; set; }

    [JsonPropertyName("recipients")]
    public List<RecipientNotification> Recipients { get; set; }
}