public class UserAccount
{
    [JsonPropertyName("userId")]
    public string UserId { get; set; }

    [JsonPropertyName("entityIds")]
    public List<int> EntityIds { get; set; }
}
