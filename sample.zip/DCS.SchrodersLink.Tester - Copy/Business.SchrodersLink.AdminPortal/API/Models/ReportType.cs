public class ReportType
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("documentType")]
    public string DocumentType { get; set; }

    [JsonPropertyName("documentTypeName")]
    public string DocumentTypeName { get; set; }

    [JsonPropertyName("visible")]
    public string Visible { get; set; }

    [JsonPropertyName("audience")]
    public string Audience { get; set; }

    [JsonPropertyName("mifidDocTypeOrder")]
    public int? MifidDocTypeOrder { get; set; }

    [JsonPropertyName("isAdminVisible")]
    public bool IsAdminVisible { get; set; }

    [JsonPropertyName("category")]
    public string Category { get; set; }
}

public class ReportTypes
{
    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("reportTypes")]
    public List<ReportType> ReportTypeList { get; set; }
}

