public class ClientPortalUIEnvConfig
{
    public UIEnvConfig DIT { get; set; }
    public UIEnvConfig UAT { get; set; }
}