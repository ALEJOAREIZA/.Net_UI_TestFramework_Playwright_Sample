public static class ClientPortalUIConfigManager
{
    public static ClientPortalUIEnvConfig GetSettings()
    {
        var fileName = $"UI/ClientPortalUI.Config.json";
        return new ConfigurationManager<ClientPortalUIEnvConfig>()
            .WithConfigFiles(fileName)
            .Get();
    }
}