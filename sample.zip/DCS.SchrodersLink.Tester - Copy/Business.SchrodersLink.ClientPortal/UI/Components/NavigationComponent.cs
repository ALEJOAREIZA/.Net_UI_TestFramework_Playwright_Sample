public class NavigationComponent(IUIDriver uiDriver)
{
    private readonly UIElement ui = new UIElement(uiDriver);

    public Button ProfileIcon => ui.Button(new UIElementSpec("Profile Icon", FindBy.Css(".my-profile__user")));
    public Button LogOutOption => ui.Button(new UIElementSpec("Log Out Option", FindBy.Xpath("//button//*[contains(text(),'Log out')]")));
}
