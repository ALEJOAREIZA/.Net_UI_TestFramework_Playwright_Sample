public class CommonElement(IUIDriver uiDriver)
{
    private readonly UIElement ui = new UIElement(uiDriver);

    public Button SelectButton => ui.Button(new UIElementSpec("Select Button", FindBy.Xpath("//button//*[text()='Select']")));
}
