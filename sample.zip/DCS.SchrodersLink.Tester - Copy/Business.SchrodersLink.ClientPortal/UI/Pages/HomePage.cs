public class HomePage : BasePage
{
    public HomePage(IUIDriver uiDriver) : base(uiDriver)
    {
        if (!HomeTab.SelectedStatus)
        {
            HomeTab.Click();
        }
    }
    public Tab HomeTab => UI.Tab(new UIElementSpec("Home Tab", FindBy.Css("li:has([data-testid='Home'])")));
    public Button PortfolioSelector => UI.Button(new UIElementSpec("Portfolio Selector", FindBy.Css(".portfolio-selector_button ")));
    public Button PortfolioSelectorItem(string itemName) => UI.Button(new UIElementSpec($"{itemName[..10]}... Portfolio", FindBy.Xpath($"//*[@class='portfolio-name'][text()='{itemName}']")));
    public SearchInput PortfolioSelectorInput => UI.SearchInput(new UIElementSpec("Portfolio Selector", FindBy.Css(".search-field input")));
    public Chart FundingLevel => UI.Chart(new UIElementSpec("Funding Level Chart", FindBy.Id("ldi-chart")));
    public Link AllQuickLinks => UI.Link(new UIElementSpec("Quick Links", FindBy.Css(".quick-links__item")));
    public Link QuickLinkByName(string quickLinkName) => UI.Link(new UIElementSpec($"{quickLinkName} Quick Link", FindBy.Xpath($"//li//a[text()='{quickLinkName}']")));
    public Link QuickLinkItem => UI.Link(new UIElementSpec("Quick Link Item", FindBy.Css(".quick-links__item")));
    public CustomElement AUMValue => UI.CustomElement(new UIElementSpec("AUM Value", FindBy.Css(".home__aum-info__value")));
    public Image RssInsights => UI.Image(new UIElementSpec("Rss Insights", FindBy.Css(".insight-item__image")));
    public Button AcceptTermsAndConditionsButton => UI.Button(new UIElementSpec("Accept Terms And Conditions Button", FindBy.Xpath("//*[@class='terms-conditions']/ancestor::*[3]//button")));
    public void SelectPortfolio(string portfolioName)
    {
        PortfolioSelector.Click();
        PortfolioSelectorInput.TypeText(portfolioName);
        PortfolioSelectorItem(portfolioName).Click();
        CommonElement.SelectButton.Click();
    }
    public void AcceptTermsAndConditionsIfNeeded()
    {
        if (AcceptTermsAndConditionsButton.Visibility)
        {
            AcceptTermsAndConditionsButton.Click();
        }
    }
}