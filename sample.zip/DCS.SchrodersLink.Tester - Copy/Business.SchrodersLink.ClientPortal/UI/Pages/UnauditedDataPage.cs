public class UnauditedDataPage : BasePage
{
    public UnauditedDataPage(IUIDriver uiDriver) : base(uiDriver)
    {
        if (!UnauditedDataTab.SelectedStatus)
        {
            UnauditedDataTab.Click();
        }
    }
    public Tab UnauditedDataTab => UI.Tab(new UIElementSpec("Unaudited Data Tab", FindBy.Css("li:has([data-testid='Unaudited'])")));
}