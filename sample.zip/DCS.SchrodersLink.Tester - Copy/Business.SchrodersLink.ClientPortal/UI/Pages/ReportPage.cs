public class ReportPage : BasePage
{
    public ReportPage(IUIDriver uiDriver) : base(uiDriver)
    {
        if (!ReportsTab.SelectedStatus)
        {
            ReportsTab.Click();
        }
    }
    public Tab ReportsTab => UI.Tab(new UIElementSpec("Report Tab", FindBy.Css("li:has([data-testid='Reports'])")));
    public Button FundSelector => UI.Button(new UIElementSpec("Fund Selector", FindBy.Css(".fund-selector_button")));
    public Button FundSelectorItem(string itemName) => UI.Button(new UIElementSpec($"{itemName[..10]}... Fund", FindBy.Xpath($"//*[@class='fund-selector_body_list-item-name'][text()='{itemName}']")));
    public SearchInput FundSelectorInput => UI.SearchInput(new UIElementSpec("Fund Selector", FindBy.Css("input[placeholder=\"Enter text to search fund\"]")));
    public CustomElement FundsReportTable => UI.CustomElement(new UIElementSpec("Fund Report Table", FindBy.Css(".report__report-table-wrapper")));
    public Button ReportDownloadIcon(string fundName) => UI.Button(new UIElementSpec($"{fundName[..10]}...Report download icon", FindBy.Xpath($"//*[text()='{fundName}']/../..//table//tr[1]//td//*[@data-icon='download']")));
    public void SelectFund(List<string> funds)
    {
        FundSelector.Click();
        foreach (var fund in funds)
        {
            FundSelectorInput.TypeText(fund);
            FundSelectorItem(fund).Click();
        }
        CommonElement.SelectButton.Click();
    }
    public void DownloadLatestReport(List<string> funds)
    {
        foreach (var fund in funds)
        {
            ReportDownloadIcon(fund).ClickToDownload();
        }
    }
}
