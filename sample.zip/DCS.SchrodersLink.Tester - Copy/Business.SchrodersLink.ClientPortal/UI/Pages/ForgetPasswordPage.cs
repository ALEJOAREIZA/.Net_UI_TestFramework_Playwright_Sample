public class ForgetPasswordPage(IUIDriver uiDriver)
{
    private readonly UIElement ui = new UIElement(uiDriver);

    public Button SubmitButton => ui.Button(new UIElementSpec("Select Button", FindBy.Text("Submit")));
    public Input Email => ui.Input(new UIElementSpec("Email", FindBy.Name("email")));
    public CustomElement ForgetPasswordForm => ui.CustomElement(new UIElementSpec("Forget Password Form", FindBy.Css(".auth-form__title")));

    public void SendResetPassword(string username)
    {
        Email.TypeText(username);
        SubmitButton.Click().WaitUntilItDisappears();
    }
}