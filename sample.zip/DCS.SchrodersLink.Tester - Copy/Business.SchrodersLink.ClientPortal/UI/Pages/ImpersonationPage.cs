public class ImpersonationPage : BasePage
{
    public ImpersonationPage(IUIDriver uiDriver) : base(uiDriver)
    {
        if (!ImpersonationTab.SelectedStatus)
        {
            ImpersonationTab.Click();
        }
    }
    public Tab ImpersonationTab => UI.Tab(new UIElementSpec("Impersonation Tab", FindBy.Css("li:has([data-testid='Impersonation'])")));
}