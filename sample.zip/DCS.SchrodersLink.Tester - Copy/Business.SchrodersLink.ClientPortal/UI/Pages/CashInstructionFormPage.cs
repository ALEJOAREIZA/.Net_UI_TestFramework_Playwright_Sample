public class CashInstructionFormPage : BasePage
{
    public CashInstructionFormPage(IUIDriver uiDriver) : base(uiDriver)
    {
        if (!CashInstructionTab.SelectedStatus)
        {
            CashInstructionTab.Click();
        }
    }
    public Tab CashInstructionTab => UI.Tab(new UIElementSpec("Cash Instruction Tab", FindBy.Css("li:has([data-testid='CashInstruction'])")));
}