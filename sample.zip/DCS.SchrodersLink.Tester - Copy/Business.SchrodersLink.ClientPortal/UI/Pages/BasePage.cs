public class BasePage(IUIDriver uiDriver)
{
    internal UIElement UI { get; set; } = new UIElement(uiDriver);
    public NavigationComponent NavBar { get; set; } = new NavigationComponent(uiDriver);
    public CommonElement CommonElement { get; set; } = new CommonElement(uiDriver);

    public void LogOut()
    {
        NavBar.ProfileIcon.Click();
        NavBar.LogOutOption.Click().WaitUntilItDisappears();
    }
}