public class LoginPage(IUIDriver uiDriver)
{
    private readonly UIElement ui = new UIElement(uiDriver);

    public Input Username => ui.Input(new UIElementSpec("Username", FindBy.Name("email")));
    public Input Password => ui.Input(new UIElementSpec("Password", FindBy.Name("password")));
    public Button LoginButton => ui.Button(new UIElementSpec("Login Button", FindBy.Css("button:not(disabled)")));
    public Alert LoginAlert => ui.Alert(new UIElementSpec("Login Alert", FindBy.Css(".alert-banner--error")));
    public CheckBox RememberEmail => ui.CheckBox(new UIElementSpec("Remember My Email", FindBy.Css(".ant-checkbox")));
    public Button ForgetPassword => ui.Button(new UIElementSpec($"Forget password Link", FindBy.Text($"Forgot Password?")));
    public CustomElement HelpAndSupportLink => ui.CustomElement(new UIElementSpec("Help and Support Link", FindBy.Xpath("//*[@href='/helpSupport']")));
    public CustomElement RegisterHereLink => ui.CustomElement(new UIElementSpec("Register Here Link", FindBy.Xpath("//*[@href='/register']")));
    public Input HelpAndSupportUsername => ui.Input(new UIElementSpec("Help and Support Username", FindBy.Name("UserName")));
    public Input HelpAndSupportEmail => ui.Input(new UIElementSpec("Help and Support Email", FindBy.Name("email")));
    public Input HelpAndSupportMessage => ui.Input(new UIElementSpec("Help and Support Message", FindBy.Xpath("//textarea[@placeholder='Enter your message']")));
    public Button SendButton => ui.Button(new UIElementSpec("Help and Support Send Button", FindBy.Xpath("//button[not(@disabled)]//span[text()='Send'] ")));
    public CustomElement HelpAndSupportSuccessMessage => ui.CustomElement(new UIElementSpec("Help and Support Success Message", FindBy.Xpath("//div[contains(@class, 'auth-form__content--help-support-confirm')]")));
    public CustomElement RegisterSuccessMessage => ui.CustomElement(new UIElementSpec("Register Success Message", FindBy.Xpath("//div[contains(@class, 'auth-form__content auth-form__content--register-confirm')]")));
    public Input RegisterFullName => ui.Input(new UIElementSpec("Register Username", FindBy.Name("fullName")));
    public Input RegisterEmail => ui.Input(new UIElementSpec("Register Email", FindBy.Name("email")));
    public Input RegisterOrganisation => ui.Input(new UIElementSpec("Register Organisation", FindBy.Name("organisation")));
    public CustomElement RegisterRoleDropDown => ui.CustomElement(new UIElementSpec("Register Role", FindBy.Xpath("//*[@class='schroders-selector ']")));
    public CustomElement RegisterRoles(string role) => ui.CustomElement(new UIElementSpec("Register Role", FindBy.Xpath($"//div[@class='schroders-selector__list__item']//*[text()='{role}']")));
    public Input RegisterAccountNames => ui.Input(new UIElementSpec("Register Account Names", FindBy.Xpath("//textarea[@placeholder='Enter your account(s)']")));
    public Button SubmitButton => ui.Button(new UIElementSpec("Register Submit Button", FindBy.Xpath("//button[not(@disabled)]//span[text()='Submit']")));

    public void Authenticate(string username, string password)
    {
        Username.TypeText(username);
        Password.TypeText(password, true);
        LoginButton.Click();
    }
    public void SendHelpAndSupportMessage(string username, string email, string message)
    {
        HelpAndSupportUsername.TypeText(username);
        HelpAndSupportEmail.TypeText(email);
        HelpAndSupportMessage.TypeText(message);
        SendButton.Click();
    }
    public void PopulateRegisterForm(string fullaname, string email, string organisation, string role, string accountNames)
    {
        RegisterFullName.TypeText(fullaname);
        RegisterEmail.TypeText(email);
        RegisterOrganisation.TypeText(organisation);
        RegisterRoleDropDown.Click();
        RegisterRoles(role).Click();
        RegisterAccountNames.TypeText(accountNames);
        SubmitButton.Click();
    }
}