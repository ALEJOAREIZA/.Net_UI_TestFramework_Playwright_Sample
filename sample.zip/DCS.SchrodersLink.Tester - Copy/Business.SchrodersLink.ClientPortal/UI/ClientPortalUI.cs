public class ClientPortalUI(IUIDriver uiDriver)
{
    private readonly IUIDriver uiDriver = uiDriver;

    public LoginPage LoginPage => new LoginPage(uiDriver);
    public HomePage HomePage => new HomePage(uiDriver);
    public ReportPage ReportPage => new ReportPage(uiDriver);
    public ForgetPasswordPage ForgetPasswordPage => new ForgetPasswordPage(uiDriver);
    public void ChangeToTab(int pageNumber) => uiDriver.ChangeToTab(pageNumber);
    public void BackToMainTab() => uiDriver.ChangeToTab(1);
    public void CloseCurrentTab() => uiDriver.CloseCurrentTab();
    public void OpenPage(string url) => uiDriver.NavigateToPage(url);
    public string GetPageTitle() => uiDriver.GetPageTitle();
}