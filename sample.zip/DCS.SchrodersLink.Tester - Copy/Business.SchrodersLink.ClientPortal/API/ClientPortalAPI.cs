public class ClientPortalAPI(APIEnvConfig clientPortalApiEnvConfig)
{
    private readonly APIEnvConfig clientPortalApiEnvConfig = clientPortalApiEnvConfig;

    public IClientPortalAPIAuth Authenticate(Credentials credentials)
    {
        clientPortalApiEnvConfig.APIAuthSettings.Credentials = credentials;
        return new RefitClientBuilder<IClientPortalAPIAuth>()
            .WithHttpClient(new HttpClientBuilder()
            .WithBaseAddress(clientPortalApiEnvConfig.BaseAddress)
            .WithAuthHandler(new BearerTokenAuthHandler(clientPortalApiEnvConfig.APIAuthSettings))
            .WithRequestHandler(new APITracingHandler())
            .WithRequestHandler(new APITestStepHandler())
            .Build())
        .Build();
    }
    public IClientPortalAPI Authenticate() => new RefitClientBuilder<IClientPortalAPI>()
        .WithHttpClient(new HttpClientBuilder()
            .WithBaseAddress(clientPortalApiEnvConfig.BaseAddress)
            .WithRequestHandler(new APITracingHandler())
            .WithRequestHandler(new APITestStepHandler())
            .Build())
        .Build();
}