public interface IHomePage
{
    [Post("/myclientserviceteam/contacts")]
    Task<ApiResponse<MyClientServiceTeam>> GetMyClientServiceTeamByPortfolio([Body] List<string> portfolioCodes);

    [Get("/portfolios/{PortfolioCode}/aum")]
    Task<ApiResponse<AUM>> GetAUMDetailsByPortfolio(string portfolioCode);

    [Get("/portfolios/ldi/list")]
    Task<ApiResponse<List<Portfolio>>> GetPortfoliosAssociatedToUser();

    [Get("/npv/latestReportsForHomepage")]
    Task<ApiResponse<NPVReport>> GetLatestNPVReports();

    [Get("/portfolios/{PortfolioCode}/ldi/summary")]
    Task<ApiResponse<ChartSummary>> GetChartSummaryByPortfolio(string portfolioCode);

    [Get("/portfolios/ldi/list?portfolioCode={PortfolioCode}&startDate={StartDate}&endDate={EndDate}")]
    Task<ApiResponse<PortfolioChartData>> GetPortfolioChartData(string portfolioCode, string startDate, string endDate);

    [Get("/rss/list")]
    Task<ApiResponse<RssInsights>> GetRssInsights();

    [Get("/support/whatsnew/list")]
    Task<ApiResponse<List<WhatsNew>>> GetWhatsNew();

    [Get("/support/walkthrough/list")]
    Task<ApiResponse<List<NewUserTour>>> GetNewUserTour();

    [Get("/resources/{Language}/all")]
    Task<ApiResponse<Translation>> GetTranslations(string language);

    [Get("/messages")]
    Task<ApiResponse<List<CPMessagingCenter>>> GetUserMessages();

    [Post("/messages/{UserMessageId}/dismissal")]
    Task<IApiResponse> DismissUserMessage(string userMessageId);
}