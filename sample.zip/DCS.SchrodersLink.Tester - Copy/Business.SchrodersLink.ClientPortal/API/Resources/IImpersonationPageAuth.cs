public interface IImpersonationPageAuth
{
    [Get("/admin/auth/users/{userId}/impersonation_token")]
    Task<ApiResponse<ImpersonationToken>> ImpersonateUser(string userId);

    [Get("/admin/users/list")]
    Task<ApiResponse<List<User>>> GetAllImpersonateUsers();
}
public interface IImpersonationPage
{
    [Delete("/admin/auth/impersonation_token")]
    Task<ApiResponse<ImpersonationToken>> StopImpersonation([Header("Authorization")] string impersonateAccessToken);
}