public interface IMiscellaneous
{
    [Get("/_configs/switch/features")]
    Task<ApiResponse<List<Feature>>> GetFeatures();
}