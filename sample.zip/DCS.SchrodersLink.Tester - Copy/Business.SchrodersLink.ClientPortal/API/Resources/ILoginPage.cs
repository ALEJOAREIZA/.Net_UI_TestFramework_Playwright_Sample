public interface ILoginPage
{
    [Get("/test/apirunning")]
    Task<IApiResponse> CheckAPIStatus();

    [Post("/users/send_reset_password")]
    Task<IApiResponse> SendResetPasswordNotification([Body] User user);

    [Headers("X-Bypass-Recaptcha:true")]
    [Post("/support/help")]
    Task<IApiResponse> SendHelpMessage([Body] HelpMessage helpMessage);

    [Headers("X-Bypass-Recaptcha:true")]
    [Post("/users/request_for_access")]
    Task<IApiResponse> SendRequestAccessMessage([Body] RequestAccessMessage requestAccess);
}