public interface ISupportPage
{
    [Get("/support/category/list?lng='en'")]
    Task<ApiResponse<List<Question>>> GetQuestionList();

    [Post("/support/cases")]
    Task<IApiResponse> SendSupportMessage([Body] SupportMessage supportMessage);
}