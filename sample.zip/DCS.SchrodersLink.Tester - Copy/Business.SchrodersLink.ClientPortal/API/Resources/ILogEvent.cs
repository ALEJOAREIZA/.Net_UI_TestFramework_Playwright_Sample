public interface ILogEvent
{
    [Post("/log/LogEvent")]
    Task<IApiResponse> SendEvent([Body] LogEvent logEvent);
}