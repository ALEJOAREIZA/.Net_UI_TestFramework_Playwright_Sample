public interface IUnauditedPage
{
    [Get("/portfolios/holdings/dates?groupCodes={PortfolioCode}")]
    Task<ApiResponse<List<DateTime>>> GetHoldingsDatesByPortfolio([Body] string portfolioCode);

    [Get("/unaudited/portfolios/holdings?groupCodes={PortfolioCode}&selectedDate={HoldingDate}")]
    Task<ApiResponse<Holding>> GetHoldingsByPortfolio([Body] string portfolioCode, string holdingDate);

    [Get("/unaudited/portfolios/{PortfolioCode}/transactions?fromDate={FromDate}&toDate={ToDate}&dateType={DateType}")]
    Task<ApiResponse<Transaction>> GetTransactionsByPortfolio([Body] string portfolioCode, string dateType, string fromDate, string toDate);

    [Get("/unaudited/portfolios/{PortfolioCode}/income?fromDate={FromDate}&toDate={ToDate}&dateType={DateType}")]
    Task<ApiResponse<List<Income>>> GetIncomeByPortfolio([Body] string portfolioCode, string dateType, string fromDate, string toDate);

    [Get("/unaudited/portfolios/offbook/holdings?groupCodes={PortfolioCode}&selectedDate={HoldingDate}")]
    Task<ApiResponse<Holding>> GetHoldingsByOffbookPortfolio([Body] string portfolioCode, string holdingDate);

    [Get("/unaudited/portfolios/{PortfolioCode}/offbook/transactions?fromDate={fromDate}&toDate={toDate}&dateType={DateType}")]
    Task<ApiResponse<Transaction>> GetTransactionsByOffbookPortfolio([Body] string portfolioCode, string dateType, string fromDate, string toDate);

    [Post("/datapicker/createSearchCriteria")]
    Task<IApiResponse> CreateDataView(DataView dataView);

    [Get("/datapicker/listSearchCriteria")]
    Task<ApiResponse<List<DataView>>> GetAllDataViews();

    [Delete("/datapicker/deleteSearchCriteria/{Id}")]
    Task<IApiResponse> DeleteDataView(string id);

    [Get("/support/tutorial/list")]
    Task<ApiResponse<List<UnauditedTutorial>>> GetUnauditedTutorial();
}