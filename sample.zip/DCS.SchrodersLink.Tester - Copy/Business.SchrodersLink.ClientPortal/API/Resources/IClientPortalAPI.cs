public interface IClientPortalAPIAuth :
    IHomePage,
    IReportsPage,
    IUnauditedPage,
    IImpersonationPageAuth,
    IAuditorPage,
    ISupportPage,
    IProfilePage,
    ILogEvent,
    IUserSurveyPage,
    IMiscellaneous
{
}
public interface IClientPortalAPI :
    ILoginPage,
    IImpersonationPage
{
}