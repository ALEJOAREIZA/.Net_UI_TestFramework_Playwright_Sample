public interface IAuditorPage
{
    [Get("/portfolios/query")]
    Task<ApiResponse<List<AuditorPortfolio>>> GetAuditorPortfolios();

    [Get("/reports/{PortfolioCode}/auditor/list")]
    Task<ApiResponse<List<AuditorReport>>> GetAuditorReportsByPortfolio(string portfolioCode);
}