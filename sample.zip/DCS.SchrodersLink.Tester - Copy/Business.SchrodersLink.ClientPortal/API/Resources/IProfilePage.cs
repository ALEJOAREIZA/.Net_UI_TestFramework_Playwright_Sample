public interface IProfilePage
{
    [Get("/notifications/settings")]
    Task<ApiResponse<NotificationSettings>> GetNotificationSettings();

    [Put("/notifications/settings")]
    Task<IApiResponse> UpdateNotificationSettings([Body] NotificationSettings notificationReport);

    [Put("/users/me/password")]
    Task<IApiResponse> ChangePassword([Body] Password passwords);
}