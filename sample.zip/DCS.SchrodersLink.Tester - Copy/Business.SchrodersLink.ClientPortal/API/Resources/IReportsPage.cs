public interface IReportsPage
{

    [Post("/reports/search/latest")]
    Task<ApiResponse<AllReport>> GetLatestReportsByPortfolio([Body] PortfolioCode portfolioCode);

    [Post("/reports/search")]
    Task<ApiResponse<PortfolioReports>> GetReportsByPortfolio([Body] ReportQuery reportQuery);

    [Post("/report-schedulers/add")]
    Task<ApiResponse<string>> CreateScheduledReport([Body] ScheduledReport reportQuery);

    [Post("/report-schedulers/find-duplicates")]
    Task<ApiResponse<string>> FindDuplicatedScheduledReport([Body] ScheduledReport reportQuery);

    [Get("/report-schedulers/list?limit=999&offset=0")]
    Task<ApiResponse<ReportScheduler>> GetAllScheduledReports();

    [Put("/report-schedulers/{ScheduledReportId}")]
    Task<IApiResponse> UpdateScheduledReport(string scheduledReportId, [Body] ScheduledReport reportQuery);

    [Delete("/report-schedulers/{ScheduledReportId}")]
    Task<IApiResponse> DeleteScheduledReport(string scheduledReportId);

    [Get("/report-schedulers/{ScheduledReportId}")]
    Task<ApiResponse<ScheduledReport>> GetScheduledReport(string scheduledReportId);

    [Get("/npv/UserReportCategories")]
    Task<ApiResponse<List<ReportCategory>>> GetNpvReportCategories();

    [Post("/npv/search")]
    Task<ApiResponse<List<NPVReport>>> GetNpvReportsByCategories([Body] NpvReportSearch npvReportSearch);
}