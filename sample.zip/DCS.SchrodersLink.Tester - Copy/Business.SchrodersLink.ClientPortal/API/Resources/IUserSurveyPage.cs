public interface IUserSurveyPage
{
    [Get("/usersurvey/list")]
    Task<ApiResponse<UserSurvey>> GetUserSurvey();

    [Post("/usersurvey/set")]
    Task<IApiResponse> SendUserSurvey([Body] UserSurveyItem userSurveyItem);
}