public class SupportMessage
{
    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("viewType")]
    public string ViewType { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("fullName")]
    public string FullName { get; set; }

    [JsonPropertyName("subject")]
    public string Subject { get; set; }

    [JsonPropertyName("description")]
    public string Description { get; set; }
}