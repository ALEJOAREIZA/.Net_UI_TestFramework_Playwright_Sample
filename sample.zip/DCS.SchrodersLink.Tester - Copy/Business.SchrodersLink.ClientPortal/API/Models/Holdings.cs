public class Holding
{
    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("holdings")]
    public List<HoldingData> Holdings { get; set; }
}
public class HoldingData
{
    [JsonPropertyName("observationPointType")]
    public string ObservationPointType { get; set; }

    [JsonPropertyName("baseCurrency")]
    public string BaseCurrency { get; set; }

    [JsonPropertyName("accountingSource")]
    public string AccountingSource { get; set; }

    [JsonPropertyName("assetName")]
    public string AssetName { get; set; }

    [JsonPropertyName("countryOfRisk")]
    public string CountryOfRisk { get; set; }

    [JsonPropertyName("currencyPrice")]
    public string CurrencyPrice { get; set; }

    [JsonPropertyName("quantityHeld")]
    public double QuantityHeld { get; set; }

    [JsonPropertyName("securityType")]
    public string SecurityType { get; set; }

    [JsonPropertyName("simInvestmentTypes")]
    public string SimInvestmentTypes { get; set; }

    [JsonPropertyName("securityAlias")]
    public int SecurityAlias { get; set; }

    [JsonPropertyName("price")]
    public double Price { get; set; }

    [JsonPropertyName("bookValueBase")]
    public object BookValueBase { get; set; }

    [JsonPropertyName("bookValueLocal")]
    public object BookValueLocal { get; set; }

    [JsonPropertyName("accruedIncomeLocal")]
    public double AccruedIncomeLocal { get; set; }

    [JsonPropertyName("accruedIncomeBase")]
    public double AccruedIncomeBase { get; set; }

    [JsonPropertyName("marketValueLocal")]
    public double MarketValueLocal { get; set; }

    [JsonPropertyName("marketValueBase")]
    public double MarketValueBase { get; set; }

    [JsonPropertyName("totalMarketValueLocal")]
    public double TotalMarketValueLocal { get; set; }

    [JsonPropertyName("totalMarketValueBase")]
    public double TotalMarketValueBase { get; set; }

    [JsonPropertyName("taxReclaimLocal")]
    public object TaxReclaimLocal { get; set; }

    [JsonPropertyName("taxReclaimBase")]
    public object TaxReclaimBase { get; set; }

    [JsonPropertyName("dividendReceivableLocal")]
    public object DividendReceivableLocal { get; set; }

    [JsonPropertyName("dividendReceivableBase")]
    public object DividendReceivableBase { get; set; }

    [JsonPropertyName("averageCost")]
    public object AverageCost { get; set; }

    [JsonPropertyName("yield")]
    public double Yield { get; set; }

    [JsonPropertyName("sedol")]
    public string Sedol { get; set; }

    [JsonPropertyName("isin")]
    public string Isin { get; set; }

    [JsonPropertyName("portfolioId")]
    public string PortfolioId { get; set; }

    [JsonPropertyName("effectiveDate")]
    public DateTime EffectiveDate { get; set; }

    [JsonPropertyName("clientName")]
    public string ClientName { get; set; }

    [JsonPropertyName("cusip")]
    public string Cusip { get; set; }
}