public class PortfolioDate
{
    public string FromDate { get; set; }
    public string ToDate { get; set; }
}
