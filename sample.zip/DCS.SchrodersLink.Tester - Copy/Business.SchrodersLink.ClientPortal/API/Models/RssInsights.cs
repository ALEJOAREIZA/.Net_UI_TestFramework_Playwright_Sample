public class RssInsights
{
    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("insightsURL")]
    public string InsightsURL { get; set; }

    [JsonPropertyName("feedList")]
    public List<FeedList> FeedList { get; set; }
}
public class FeedList
{
    [JsonPropertyName("imageUrl")]
    public string ImageUrl { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("description")]
    public string Description { get; set; }

    [JsonPropertyName("pubDate")]
    public DateTime PubDate { get; set; }

    [JsonPropertyName("link")]
    public string Link { get; set; }
}