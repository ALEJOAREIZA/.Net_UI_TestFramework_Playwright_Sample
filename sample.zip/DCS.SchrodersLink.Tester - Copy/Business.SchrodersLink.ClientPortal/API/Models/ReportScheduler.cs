public class ReportScheduler
{
    [JsonPropertyName("reportSchedulers")]
    public List<ScheduledReportData> ScheduledReports { get; set; }

    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }
}
public class Criteria
{
    [JsonPropertyName("holdingPositionType")]
    public string HoldingPositionType { get; set; }

    [JsonPropertyName("transactionPeriodType")]
    public string TransactionPeriodType { get; set; }

    [JsonPropertyName("transactionDataType")]
    public string TransactionDataType { get; set; }
}

public class PortfolioScheduledReport
{
    [JsonPropertyName("clientCode")]
    public string ClientCode { get; set; }

    [JsonPropertyName("groupCode")]
    public string GroupCode { get; set; }

    [JsonPropertyName("clientName")]
    public string ClientName { get; set; }

    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }

    [JsonPropertyName("reportingGroupCode")]
    public object ReportingGroupCode { get; set; }
}

public class ScheduledReportData
{
    [JsonPropertyName("reportSchedulerId")]
    public int ReportSchedulerId { get; set; }

    [JsonPropertyName("isNotificationEnabled")]
    public bool IsNotificationEnabled { get; set; }

    [JsonPropertyName("criteria")]
    public Criteria Criteria { get; set; }

    [JsonPropertyName("updatedDateTimeUtc")]
    public DateTime UpdatedDateTimeUtc { get; set; }

    [JsonPropertyName("portfolios")]
    public List<Portfolio> Portfolios { get; set; }

    [JsonPropertyName("frequency")]
    public string Frequency { get; set; }

    [JsonPropertyName("startAtUtc")]
    public DateTime StartAtUtc { get; set; }
}