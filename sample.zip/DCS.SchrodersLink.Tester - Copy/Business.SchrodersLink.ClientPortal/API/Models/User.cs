public class User
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("userName")]
    public string UserName { get; set; }

    [JsonPropertyName("firstName")]
    public string FirstName { get; set; }

    [JsonPropertyName("lastName")]
    public string LastName { get; set; }

    [JsonPropertyName("lockoutStatus")]
    public string LockoutStatus { get; set; }

    [JsonPropertyName("lastLoggedIn")]
    public DateTime? LastLoggedIn { get; set; }

    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("viewType")]
    public string ViewType { get; set; }

    [JsonPropertyName("isDeleted")]
    public bool IsDeleted { get; set; }

    [JsonPropertyName("securityQuestionsSet")]
    public bool SecurityQuestionsSet { get; set; }

    [JsonPropertyName("passwordSet")]
    public bool PasswordSet { get; set; }

    [JsonPropertyName("lastChangedPassword")]
    public DateTime? LastChangedPassword { get; set; }

    [JsonPropertyName("masterSource")]
    public string MasterSource { get; set; }

    [JsonPropertyName("needsToMigrate")]
    public bool NeedsToMigrate { get; set; }

    [JsonPropertyName("termsAccepted")]
    public bool TermsAccepted { get; set; }

    [JsonPropertyName("termsLastAcceptanceDate")]
    public DateTime? TermsLastAcceptanceDate { get; set; }

    [JsonPropertyName("updatedTermsAccepted")]
    public bool UpdatedTermsAccepted { get; set; }
}