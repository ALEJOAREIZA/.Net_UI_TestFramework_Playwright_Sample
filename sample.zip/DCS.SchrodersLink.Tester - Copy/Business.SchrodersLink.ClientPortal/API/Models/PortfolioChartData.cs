public class PortfolioChartData
{
    [JsonPropertyName("chart")]
    public List<PortfolioChart> Chart { get; set; }

    [JsonPropertyName("label")]
    public Label Label { get; set; }
}
public class PortfolioChart
{
    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("data")]
    public List<List<string>> Data { get; set; }
}
public class Datum
{
    [JsonPropertyName("fundingLevel")]
    public double FundingLevel { get; set; }

    [JsonPropertyName("totalAssets")]
    public double TotalAssets { get; set; }

    [JsonPropertyName("totalLiabilities")]
    public double TotalLiabilities { get; set; }
}
public class Label
{
    [JsonPropertyName("data")]
    public List<Datum> Data { get; set; }
}