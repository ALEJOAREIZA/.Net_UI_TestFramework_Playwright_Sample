public class AuditorReport
{
    [JsonPropertyName("portfolios")]
    public List<AuditorPortfolio> Portfolios { get; set; }

    [JsonPropertyName("currentVersionId")]
    public string CurrentVersionId { get; set; }

    [JsonPropertyName("documentName")]
    public string DocumentName { get; set; }

    [JsonPropertyName("documentType")]
    public string DocumentType { get; set; }

    [JsonPropertyName("documentTypeName")]
    public string DocumentTypeName { get; set; }

    [JsonPropertyName("fileExtension")]
    public string FileExtension { get; set; }

    [JsonPropertyName("startDate")]
    public DateTime StartDate { get; set; }

    [JsonPropertyName("endDate")]
    public DateTime EndDate { get; set; }

    [JsonPropertyName("frequency")]
    public string Frequency { get; set; }

    [JsonPropertyName("isNew")]
    public bool IsNew { get; set; }

    [JsonPropertyName("alertType")]
    public object AlertType { get; set; }

    [JsonPropertyName("creationDate")]
    public DateTime CreationDate { get; set; }

    [JsonPropertyName("mifidDocTypeOrder")]
    public int MifidDocTypeOrder { get; set; }

    [JsonPropertyName("documentMetadataId")]
    public int DocumentMetadataId { get; set; }

    [JsonPropertyName("documentTypeExtension")]
    public object DocumentTypeExtension { get; set; }

    [JsonPropertyName("reportType")]
    public string ReportType { get; set; }
}