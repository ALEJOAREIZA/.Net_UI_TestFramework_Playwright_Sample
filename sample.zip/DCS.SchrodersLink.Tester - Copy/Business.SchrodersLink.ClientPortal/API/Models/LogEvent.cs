public class LogEvent
{
    [JsonPropertyName("eventType")]
    public string EventType { get; set; }

    [JsonPropertyName("sessionId")]
    public string SessionId { get; set; }

    [JsonPropertyName("eventDetails")]
    public string EventDetails { get; set; }
}