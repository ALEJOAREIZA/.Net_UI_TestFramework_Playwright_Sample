public class ChartSummary
{
    [JsonPropertyName("portfolioCode")]
    public string PortfolioCode { get; set; }

    [JsonPropertyName("startDate")]
    public DateTime StartDate { get; set; }

    [JsonPropertyName("endDate")]
    public DateTime EndDate { get; set; }

    [JsonPropertyName("fundingLevel")]
    public double FundingLevel { get; set; }

    [JsonPropertyName("asOfDate")]
    public DateTime AsOfDate { get; set; }
}
