public class DataView
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("dataSet")]
    public string DataSet { get; set; }

    [JsonPropertyName("portfolios")]
    public List<string> Portfolios { get; set; }

    [JsonPropertyName("positionType")]
    public string PositionType { get; set; }

    [JsonPropertyName("startDate")]
    public object StartDate { get; set; }

    [JsonPropertyName("endDate")]
    public object EndDate { get; set; }

    [JsonPropertyName("dataType")]
    public string DataType { get; set; }

    [JsonPropertyName("viewName")]
    public string ViewName { get; set; }

    [JsonPropertyName("displaySettings")]
    public DisplaySettings DisplaySettings { get; set; }

    [JsonPropertyName("lastModifiedDate")]
    public DateTime LastModifiedDate { get; set; }
}
public class DisplaySettings
{
    [JsonPropertyName("columns")]
    public List<string> Columns { get; set; }

    [JsonPropertyName("rowsPerPage")]
    public int RowsPerPage { get; set; }
}