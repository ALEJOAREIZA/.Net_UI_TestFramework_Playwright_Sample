public class Portfolio
{
    [JsonPropertyName("clientCode")]
    public string ClientCode { get; set; }

    [JsonPropertyName("groupCode")]
    public string GroupCode { get; set; }

    [JsonPropertyName("clientName")]
    public string ClientName { get; set; }

    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }

    [JsonPropertyName("aumReportingCurrency")]
    public string AumReportingCurrency { get; set; }

    [JsonPropertyName("isLDIPortfolio")]
    public bool IsLDIPortfolio { get; set; }

    [JsonPropertyName("isOffBook")]
    public bool IsOffBook { get; set; }

    [JsonPropertyName("observationPointTypes")]
    public List<ObservationPointType> ObservationPointTypes { get; set; }
}
public class ObservationPointType
{
    [JsonPropertyName("value")]
    public string Value { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }
}
public class PortfolioCode
{
    [JsonPropertyName("portfolioCodes")]
    public List<string> PortfolioCodes { get; set; }
    [JsonPropertyName("limit")]
    public int Limit { get; set; }
    [JsonPropertyName("offset")]
    public int Offset { get; set; }
}