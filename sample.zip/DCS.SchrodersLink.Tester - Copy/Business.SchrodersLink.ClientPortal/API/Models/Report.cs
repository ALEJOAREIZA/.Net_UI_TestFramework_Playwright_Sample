public class AllReport
{
    [JsonPropertyName("scheduledReports")]
    public ScheduledReports ScheduledReports { get; set; }

    [JsonPropertyName("portfolioReports")]
    public PortfolioReports PortfolioReports { get; set; }
}
public class ReportPortfolio
{
    [JsonPropertyName("clientCode")]
    public string ClientCode { get; set; }

    [JsonPropertyName("groupCode")]
    public string GroupCode { get; set; }

    [JsonPropertyName("clientName")]
    public string ClientName { get; set; }

    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }

    [JsonPropertyName("reportingGroupCode")]
    public object ReportingGroupCode { get; set; }
}
public class Report
{
    [JsonPropertyName("portfolios")]
    public List<ReportPortfolio> Portfolios { get; set; }

    [JsonPropertyName("currentVersionId")]
    public string CurrentVersionId { get; set; }

    [JsonPropertyName("documentName")]
    public object DocumentName { get; set; }

    [JsonPropertyName("documentType")]
    public string DocumentType { get; set; }

    [JsonPropertyName("documentTypeName")]
    public string DocumentTypeName { get; set; }

    [JsonPropertyName("fileExtension")]
    public string FileExtension { get; set; }

    [JsonPropertyName("startDate")]
    public DateTime StartDate { get; set; }

    [JsonPropertyName("endDate")]
    public DateTime? EndDate { get; set; }

    [JsonPropertyName("frequency")]
    public string Frequency { get; set; }

    [JsonPropertyName("isNew")]
    public bool IsNew { get; set; }

    [JsonPropertyName("alertType")]
    public object AlertType { get; set; }

    [JsonPropertyName("creationDate")]
    public DateTime CreationDate { get; set; }

    [JsonPropertyName("mifidDocTypeOrder")]
    public object MifidDocTypeOrder { get; set; }

    [JsonPropertyName("documentMetadataId")]
    public int DocumentMetadataId { get; set; }

    [JsonPropertyName("documentTypeExtension")]
    public object DocumentTypeExtension { get; set; }

    [JsonPropertyName("reportType")]
    public string ReportType { get; set; }
}
public class PortfolioReports
{
    [JsonPropertyName("reports")]
    public List<Report> Reports { get; set; }

    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }
}
public class ScheduledReports
{
    [JsonPropertyName("reports")]
    public List<Report> Reports { get; set; }

    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }
}