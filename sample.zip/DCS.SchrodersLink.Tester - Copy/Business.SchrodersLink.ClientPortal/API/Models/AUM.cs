public class AUM
{
    [JsonPropertyName("portfolioGroupCode")]
    public string PortfolioGroupCode { get; set; }
    [JsonPropertyName("aumMarketValue")]
    public double AUMMarketValue { get; set; }
    [JsonPropertyName("aumEffectiveDate")]
    public DateTime AUMEffectiveDate { get; set; }
}