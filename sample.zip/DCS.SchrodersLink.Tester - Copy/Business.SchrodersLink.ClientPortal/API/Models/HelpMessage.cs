public class HelpMessage
{
    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("UserName")]
    public string UserName { get; set; }

    [JsonPropertyName("message")]
    public string Message { get; set; }
}