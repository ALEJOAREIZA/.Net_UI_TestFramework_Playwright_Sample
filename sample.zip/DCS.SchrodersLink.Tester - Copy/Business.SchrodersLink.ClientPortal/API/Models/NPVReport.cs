public class NPVReport
{
    [JsonPropertyName("category")]
    public string Category { get; set; }

    [JsonPropertyName("reports")]
    public List<Report> Reports { get; set; }

    [JsonPropertyName("unreadReportsCount")]
    public int UnreadReportsCount { get; set; }
}
public class Reports
{
    [JsonPropertyName("documentType")]
    public string DocumentType { get; set; }

    [JsonPropertyName("frequency")]
    public string Frequency { get; set; }

    [JsonPropertyName("isNew")]
    public bool IsNew { get; set; }

    [JsonPropertyName("currentVersionId")]
    public string CurrentVersionId { get; set; }

    [JsonPropertyName("category")]
    public string Category { get; set; }

    [JsonPropertyName("documentTypeName")]
    public string DocumentTypeName { get; set; }

    [JsonPropertyName("fileExtension")]
    public string FileExtension { get; set; }

    [JsonPropertyName("startDate")]
    public DateTime StartDate { get; set; }

    [JsonPropertyName("endDate")]
    public DateTime EndDate { get; set; }

    [JsonPropertyName("exportDate")]
    public DateTime ExportDate { get; set; }
}