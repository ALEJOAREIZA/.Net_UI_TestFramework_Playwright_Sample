public class MyClientServiceTeam
{
    [JsonPropertyName("portfolioContactInfos")]
    public List<PortfolioContactInfo> PortfolioContactInfos { get; set; }
    [JsonPropertyName("photos")]
    public List<PhotoData> Photos { get; set; }
}
public class Contactor
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Title { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }
    public int EmployeeId { get; set; }
    public string Identifier { get; set; }
}
public class PhotoData
{
    public string Identifier { get; set; }
    public int EmployeeId { get; set; }
    public string Photo { get; set; }
}
public class PortfolioContactInfo
{
    [JsonPropertyName("portfolioCode")]
    public string PortfolioCode { get; set; }
    [JsonPropertyName("accountName")]
    public string AccountName { get; set; }
    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }
    [JsonPropertyName("contactors")]
    public List<Contactor> Contactors { get; set; }
}