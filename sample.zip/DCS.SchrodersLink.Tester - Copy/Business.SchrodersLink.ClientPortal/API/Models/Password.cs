public class Password
{
    [JsonPropertyName("oldPassword")]
    public string OldPassword { get; set; }

    [JsonPropertyName("newPassword")]
    public string NewPassword { get; set; }
}