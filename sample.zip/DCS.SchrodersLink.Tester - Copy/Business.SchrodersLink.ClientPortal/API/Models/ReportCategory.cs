public class ReportCategory
{
    [JsonPropertyName("category")]
    public string Category { get; set; }
}
