public class UserSurvey
{
    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("surveys")]
    public List<Survey> Surveys { get; set; }
}

public class Survey
{
    [JsonPropertyName("userSurveyItem")]
    public UserSurveyItem UserSurveyItem { get; set; }

    [JsonPropertyName("dateTaken")]
    public DateTime DateTaken { get; set; }
}

public class UserSurveyItem
{
    [JsonPropertyName("surveyUrl")]
    public string SurveyUrl { get; set; }

    [JsonPropertyName("surveyDeclined")]
    public bool SurveyDeclined { get; set; }
}