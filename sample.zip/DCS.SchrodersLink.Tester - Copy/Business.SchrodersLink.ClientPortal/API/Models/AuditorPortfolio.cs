public class AuditorPortfolio
{
    [JsonPropertyName("clientCode")]
    public string ClientCode { get; set; }

    [JsonPropertyName("groupCode")]
    public string GroupCode { get; set; }

    [JsonPropertyName("clientName")]
    public string ClientName { get; set; }

    [JsonPropertyName("portfolioName")]
    public string PortfolioName { get; set; }

    [JsonPropertyName("aumMarketValue")]
    public double AumMarketValue { get; set; }

    [JsonPropertyName("aumEffectiveDate")]
    public object AumEffectiveDate { get; set; }

    [JsonPropertyName("aumReportingCurrency")]
    public string AumReportingCurrency { get; set; }

    [JsonPropertyName("isLDIPortfolio")]
    public bool IsLDIPortfolio { get; set; }

    [JsonPropertyName("isOffBook")]
    public bool IsOffBook { get; set; }

    [JsonPropertyName("observationPointTypes")]
    public List<AuditorObservationPointType> ObservationPointTypes { get; set; }

    [JsonPropertyName("reportingGroupCode")]
    public string ReportingGroupCode { get; set; }
}
public class AuditorObservationPointType
{
    [JsonPropertyName("value")]
    public string Value { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }
}