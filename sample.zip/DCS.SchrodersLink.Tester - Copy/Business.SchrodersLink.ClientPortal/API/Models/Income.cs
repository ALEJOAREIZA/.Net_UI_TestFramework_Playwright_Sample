public class Income
{
    [JsonPropertyName("assetName")]
    public string AssetName { get; set; }

    [JsonPropertyName("settlementDate")]
    public DateTime SettlementDate { get; set; }

    [JsonPropertyName("totalAmountBase")]
    public double TotalAmountBase { get; set; }

    [JsonPropertyName("totalAmountLocal")]
    public double TotalAmountLocal { get; set; }

    [JsonPropertyName("transCode")]
    public string TransCode { get; set; }

    [JsonPropertyName("tradeDatetime")]
    public DateTime TradeDatetime { get; set; }

    [JsonPropertyName("underlyingSecurityCode")]
    public int UnderlyingSecurityCode { get; set; }

    [JsonPropertyName("underlyingAssetDesc")]
    public string UnderlyingAssetDesc { get; set; }

    [JsonPropertyName("underlyingSedol")]
    public object UnderlyingSedol { get; set; }

    [JsonPropertyName("portfolioId")]
    public string PortfolioId { get; set; }

    [JsonPropertyName("client")]
    public string Client { get; set; }

    [JsonPropertyName("underlyingIsin")]
    public object UnderlyingIsin { get; set; }

    [JsonPropertyName("altTradeReference")]
    public string AltTradeReference { get; set; }

    [JsonPropertyName("underlyingCusip")]
    public object UnderlyingCusip { get; set; }
}