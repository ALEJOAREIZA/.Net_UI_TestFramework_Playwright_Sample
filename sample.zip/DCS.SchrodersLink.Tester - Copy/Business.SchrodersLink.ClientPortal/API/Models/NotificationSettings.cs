public class NotificationSettings
{
    [JsonPropertyName("reports")]
    public List<NotificationReport> Reports { get; set; }
}
public class NotificationReport
{
    [JsonPropertyName("reportId")]
    public string ReportId { get; set; }

    [JsonPropertyName("description")]
    public string Description { get; set; }

    [JsonPropertyName("audienceId")]
    public string AudienceId { get; set; }

    [JsonPropertyName("selected")]
    public bool Selected { get; set; }

    [JsonPropertyName("readonly")]
    public bool Readonly { get; set; }
}