public class Translation
{
    [JsonPropertyName("navigation")]
    public Navigation Navigation { get; set; }

    [JsonPropertyName("auth_register")]
    public AuthRegister AuthRegister { get; set; }

    [JsonPropertyName("auth_login")]
    public AuthLogin AuthLogin { get; set; }

    [JsonPropertyName("auth_help_support")]
    public AuthHelpSupport AuthHelpSupport { get; set; }

    [JsonPropertyName("auth_forgot_pwd")]
    public AuthForgotPwd AuthForgotPwd { get; set; }

    [JsonPropertyName("auth_confirm")]
    public AuthConfirm AuthConfirm { get; set; }

    [JsonPropertyName("auth_recaptcha")]
    public AuthRecaptcha AuthRecaptcha { get; set; }

    [JsonPropertyName("auth_reset_password")]
    public AuthResetPassword AuthResetPassword { get; set; }

    [JsonPropertyName("auth_otp")]
    public AuthOtp AuthOtp { get; set; }

    [JsonPropertyName("auth_security_question")]
    public AuthSecurityQuestion AuthSecurityQuestion { get; set; }

    [JsonPropertyName("auth_set_password")]
    public AuthSetPassword AuthSetPassword { get; set; }

    [JsonPropertyName("ldi")]
    public Ldi Ldi { get; set; }

    [JsonPropertyName("cash_form")]
    public CashForm CashForm { get; set; }

    [JsonPropertyName("support")]
    public Support Support { get; set; }

    [JsonPropertyName("portfolio_selector")]
    public PortfolioSelector PortfolioSelector { get; set; }

    [JsonPropertyName("mcst_menu")]
    public McstMenu McstMenu { get; set; }

    [JsonPropertyName("mcst_view")]
    public McstView McstView { get; set; }

    [JsonPropertyName("profile")]
    public Profile Profile { get; set; }

    [JsonPropertyName("reportstab")]
    public Reportstab Reportstab { get; set; }

    [JsonPropertyName("auditor")]
    public Auditor Auditor { get; set; }

    [JsonPropertyName("unaudited")]
    public Unaudited Unaudited { get; set; }

    [JsonPropertyName("general")]
    public General General { get; set; }

    [JsonPropertyName("footer")]
    public Footer Footer { get; set; }

    [JsonPropertyName("terms_conditions")]
    public TermsConditions TermsConditions { get; set; }

    [JsonPropertyName("home")]
    public Home Home { get; set; }

    [JsonPropertyName("impersonation")]
    public Impersonation Impersonation { get; set; }

    [JsonPropertyName("session_inactive")]
    public SessionInactive SessionInactive { get; set; }

    [JsonPropertyName("page")]
    public Page Page { get; set; }
}
public class Auditor
{
    [JsonPropertyName("welcome")]
    public string Welcome { get; set; }

    [JsonPropertyName("msg")]
    public string Msg { get; set; }

    [JsonPropertyName("selector_search_placeholder")]
    public string SelectorSearchPlaceholder { get; set; }
}

public class AuthConfirm
{
    [JsonPropertyName("register_confirm_subtitle")]
    public string RegisterConfirmSubtitle { get; set; }

    [JsonPropertyName("register_confirm_view_policy")]
    public string RegisterConfirmViewPolicy { get; set; }

    [JsonPropertyName("register_confirm_button")]
    public string RegisterConfirmButton { get; set; }

    [JsonPropertyName("register_confirm_resend_success")]
    public string RegisterConfirmResendSuccess { get; set; }

    [JsonPropertyName("forgot_pwd_confirm_title")]
    public string ForgotPwdConfirmTitle { get; set; }

    [JsonPropertyName("forgot_pwd_confirm_subtitle")]
    public string ForgotPwdConfirmSubtitle { get; set; }

    [JsonPropertyName("forgot_pwd_confirm_footer")]
    public string ForgotPwdConfirmFooter { get; set; }

    [JsonPropertyName("forgot_pwd_confirm_resend")]
    public string ForgotPwdConfirmResend { get; set; }

    [JsonPropertyName("forgot_pwd_confirm_back")]
    public string ForgotPwdConfirmBack { get; set; }

    [JsonPropertyName("forgot_pwd_confirm_close")]
    public string ForgotPwdConfirmClose { get; set; }

    [JsonPropertyName("help_confirm_title")]
    public string HelpConfirmTitle { get; set; }

    [JsonPropertyName("help_confirm_subtitle")]
    public string HelpConfirmSubtitle { get; set; }

    [JsonPropertyName("help_confirm_button")]
    public string HelpConfirmButton { get; set; }

    [JsonPropertyName("reset_pwd_confirm_title")]
    public string ResetPwdConfirmTitle { get; set; }

    [JsonPropertyName("reset_pwd_confirm_subtitle")]
    public string ResetPwdConfirmSubtitle { get; set; }

    [JsonPropertyName("reset_pwd_confirm_button")]
    public string ResetPwdConfirmButton { get; set; }

    [JsonPropertyName("register_confirm_title")]
    public string RegisterConfirmTitle { get; set; }
}

public class AuthForgotPwd
{
    [JsonPropertyName("cancel_btn")]
    public string CancelBtn { get; set; }

    [JsonPropertyName("ok_btn")]
    public string OkBtn { get; set; }

    [JsonPropertyName("email_empty_msg")]
    public string EmailEmptyMsg { get; set; }

    [JsonPropertyName("general_error")]
    public string GeneralError { get; set; }

    [JsonPropertyName("user_configuration_error")]
    public string UserConfigurationError { get; set; }

    [JsonPropertyName("user_action_forbidden")]
    public string UserActionForbidden { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("explanation")]
    public string Explanation { get; set; }

    [JsonPropertyName("placeholder")]
    public string Placeholder { get; set; }

    [JsonPropertyName("email_validation_msg")]
    public string EmailValidationMsg { get; set; }
}

public class AuthHelpSupport
{
    [JsonPropertyName("name_placeholder")]
    public string NamePlaceholder { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("no_email_msg")]
    public string NoEmailMsg { get; set; }

    [JsonPropertyName("email_err_msg")]
    public string EmailErrMsg { get; set; }

    [JsonPropertyName("email_placeholder")]
    public string EmailPlaceholder { get; set; }

    [JsonPropertyName("message")]
    public string Message { get; set; }

    [JsonPropertyName("msg_err_msg")]
    public string MsgErrMsg { get; set; }

    [JsonPropertyName("message_placeholder")]
    public string MessagePlaceholder { get; set; }

    [JsonPropertyName("cancel_button")]
    public string CancelButton { get; set; }

    [JsonPropertyName("ok_button")]
    public string OkButton { get; set; }

    [JsonPropertyName("locked_title")]
    public string LockedTitle { get; set; }

    [JsonPropertyName("locked_text")]
    public string LockedText { get; set; }

    [JsonPropertyName("locked_subject")]
    public string LockedSubject { get; set; }

    [JsonPropertyName("locked_subject_default")]
    public string LockedSubjectDefault { get; set; }

    [JsonPropertyName("locked_subject_placeholder")]
    public string LockedSubjectPlaceholder { get; set; }

    [JsonPropertyName("name_err_msg")]
    public string NameErrMsg { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("subtitle")]
    public string Subtitle { get; set; }
}

public class AuthLogin
{
    [JsonPropertyName("general_error")]
    public string GeneralError { get; set; }

    [JsonPropertyName("user_configuration_error")]
    public string UserConfigurationError { get; set; }

    [JsonPropertyName("user_action_forbidden")]
    public string UserActionForbidden { get; set; }

    [JsonPropertyName("login_error")]
    public string LoginError { get; set; }

    [JsonPropertyName("pending_totp")]
    public string PendingTotp { get; set; }

    [JsonPropertyName("permanent_lock_out")]
    public string PermanentLockOut { get; set; }

    [JsonPropertyName("invalid_totp")]
    public string InvalidTotp { get; set; }

    [JsonPropertyName("permanent_lock_login")]
    public string PermanentLockLogin { get; set; }

    [JsonPropertyName("email_empty_msg")]
    public string EmailEmptyMsg { get; set; }

    [JsonPropertyName("pwd_input")]
    public string PwdInput { get; set; }

    [JsonPropertyName("pwd_placeholder")]
    public string PwdPlaceholder { get; set; }

    [JsonPropertyName("pwd_validation_msg")]
    public string PwdValidationMsg { get; set; }

    [JsonPropertyName("remember_email")]
    public string RememberEmail { get; set; }

    [JsonPropertyName("forgot_password")]
    public string ForgotPassword { get; set; }

    [JsonPropertyName("ok_btn")]
    public string OkBtn { get; set; }

    [JsonPropertyName("help_support")]
    public string HelpSupport { get; set; }

    [JsonPropertyName("email_validation_msg")]
    public string EmailValidationMsg { get; set; }

    [JsonPropertyName("footer_text")]
    public string FooterText { get; set; }

    [JsonPropertyName("accept")]
    public string Accept { get; set; }

    [JsonPropertyName("footer_link")]
    public string FooterLink { get; set; }

    [JsonPropertyName("email_placeholder")]
    public string EmailPlaceholder { get; set; }

    [JsonPropertyName("email_input")]
    public string EmailInput { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }
}

public class AuthOtp
{
    [JsonPropertyName("pending_totp")]
    public string PendingTotp { get; set; }

    [JsonPropertyName("permanent_lock_out")]
    public string PermanentLockOut { get; set; }

    [JsonPropertyName("invalid_totp")]
    public string InvalidTotp { get; set; }

    [JsonPropertyName("success_title")]
    public string SuccessTitle { get; set; }

    [JsonPropertyName("success")]
    public string Success { get; set; }

    [JsonPropertyName("resend")]
    public string Resend { get; set; }

    [JsonPropertyName("cancel_button")]
    public string CancelButton { get; set; }

    [JsonPropertyName("ok_button")]
    public string OkButton { get; set; }

    [JsonPropertyName("close_button")]
    public string CloseButton { get; set; }

    [JsonPropertyName("general_error")]
    public string GeneralError { get; set; }

    [JsonPropertyName("user_configuration_error")]
    public string UserConfigurationError { get; set; }

    [JsonPropertyName("user_action_forbidden")]
    public string UserActionForbidden { get; set; }

    [JsonPropertyName("footer")]
    public string Footer { get; set; }

    [JsonPropertyName("subtitle")]
    public string Subtitle { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }
}

public class AuthRecaptcha
{
    [JsonPropertyName("ok_button")]
    public string OkButton { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("subtitle")]
    public string Subtitle { get; set; }

    [JsonPropertyName("cancel_button")]
    public string CancelButton { get; set; }
}

public class AuthRegister
{
    [JsonPropertyName("general_error")]
    public string GeneralError { get; set; }

    [JsonPropertyName("user_configuration_error")]
    public string UserConfigurationError { get; set; }

    [JsonPropertyName("user_action_forbidden")]
    public string UserActionForbidden { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("subtitle")]
    public string Subtitle { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("name_placeholder")]
    public string NamePlaceholder { get; set; }

    [JsonPropertyName("name_require_msg")]
    public string NameRequireMsg { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("email_placeholder")]
    public string EmailPlaceholder { get; set; }

    [JsonPropertyName("email_require_msg")]
    public string EmailRequireMsg { get; set; }

    [JsonPropertyName("email_validation_msg")]
    public string EmailValidationMsg { get; set; }

    [JsonPropertyName("organisation")]
    public string Organisation { get; set; }

    [JsonPropertyName("organisation_placeholder")]
    public string OrganisationPlaceholder { get; set; }

    [JsonPropertyName("organisation_require_msg")]
    public string OrganisationRequireMsg { get; set; }

    [JsonPropertyName("role")]
    public string Role { get; set; }

    [JsonPropertyName("role_placeholder")]
    public string RolePlaceholder { get; set; }

    [JsonPropertyName("role_remark")]
    public string RoleRemark { get; set; }

    [JsonPropertyName("trustee")]
    public string Trustee { get; set; }

    [JsonPropertyName("general_management")]
    public string GeneralManagement { get; set; }

    [JsonPropertyName("general_finance")]
    public string GeneralFinance { get; set; }

    [JsonPropertyName("investment_research")]
    public string InvestmentResearch { get; set; }

    [JsonPropertyName("advisor")]
    public string Advisor { get; set; }

    [JsonPropertyName("consultant")]
    public string Consultant { get; set; }

    [JsonPropertyName("operations_administration")]
    public string OperationsAdministration { get; set; }

    [JsonPropertyName("other")]
    public string Other { get; set; }

    [JsonPropertyName("account_name")]
    public string AccountName { get; set; }

    [JsonPropertyName("account_placehoder")]
    public string AccountPlacehoder { get; set; }

    [JsonPropertyName("account_require_msg")]
    public string AccountRequireMsg { get; set; }

    [JsonPropertyName("account_remark")]
    public string AccountRemark { get; set; }

    [JsonPropertyName("footer")]
    public string Footer { get; set; }

    [JsonPropertyName("login")]
    public string Login { get; set; }

    [JsonPropertyName("submit")]
    public string Submit { get; set; }

    [JsonPropertyName("auditor")]
    public string Auditor { get; set; }
}

public class AuthResetPassword
{
    [JsonPropertyName("general_error")]
    public string GeneralError { get; set; }

    [JsonPropertyName("user_configuration_error")]
    public string UserConfigurationError { get; set; }

    [JsonPropertyName("user_action_forbidden")]
    public string UserActionForbidden { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("question_require_msg")]
    public string QuestionRequireMsg { get; set; }

    [JsonPropertyName("new_password")]
    public string NewPassword { get; set; }

    [JsonPropertyName("confirm_new_password")]
    public string ConfirmNewPassword { get; set; }

    [JsonPropertyName("set_button")]
    public string SetButton { get; set; }

    [JsonPropertyName("validation_title")]
    public string ValidationTitle { get; set; }

    [JsonPropertyName("rule1_p1")]
    public string Rule1P1 { get; set; }

    [JsonPropertyName("rule1_p2")]
    public string Rule1P2 { get; set; }

    [JsonPropertyName("rule1_p3")]
    public string Rule1P3 { get; set; }

    [JsonPropertyName("rule2_p1")]
    public string Rule2P1 { get; set; }

    [JsonPropertyName("rule2_p2")]
    public string Rule2P2 { get; set; }

    [JsonPropertyName("rule3_p1")]
    public string Rule3P1 { get; set; }

    [JsonPropertyName("confirm_err_msg")]
    public string ConfirmErrMsg { get; set; }

    [JsonPropertyName("rule3_p2")]
    public string Rule3P2 { get; set; }

    [JsonPropertyName("rule3_p3")]
    public string Rule3P3 { get; set; }

    [JsonPropertyName("rule4_p2")]
    public string Rule4P2 { get; set; }

    [JsonPropertyName("rule4_p3")]
    public string Rule4P3 { get; set; }

    [JsonPropertyName("rule5_p1")]
    public string Rule5P1 { get; set; }

    [JsonPropertyName("rule5_p2")]
    public string Rule5P2 { get; set; }

    [JsonPropertyName("rule5_p3")]
    public string Rule5P3 { get; set; }

    [JsonPropertyName("no_access_msg")]
    public string NoAccessMsg { get; set; }

    [JsonPropertyName("rule4_p1")]
    public string Rule4P1 { get; set; }
}

public class AuthSecurityQuestion
{
    [JsonPropertyName("q8")]
    public string Q8 { get; set; }

    [JsonPropertyName("q9")]
    public string Q9 { get; set; }

    [JsonPropertyName("q10")]
    public string Q10 { get; set; }

    [JsonPropertyName("note")]
    public string Note { get; set; }

    [JsonPropertyName("set_button")]
    public string SetButton { get; set; }

    [JsonPropertyName("q7")]
    public string Q7 { get; set; }

    [JsonPropertyName("q6")]
    public string Q6 { get; set; }

    [JsonPropertyName("q5")]
    public string Q5 { get; set; }

    [JsonPropertyName("q4")]
    public string Q4 { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("subtitle1")]
    public string Subtitle1 { get; set; }

    [JsonPropertyName("subtitle2")]
    public string Subtitle2 { get; set; }

    [JsonPropertyName("q1_label")]
    public string Q1Label { get; set; }

    [JsonPropertyName("q1_placeholder")]
    public string Q1Placeholder { get; set; }

    [JsonPropertyName("q2_label")]
    public string Q2Label { get; set; }

    [JsonPropertyName("q2_placeholder")]
    public string Q2Placeholder { get; set; }

    [JsonPropertyName("q3_label")]
    public string Q3Label { get; set; }

    [JsonPropertyName("q3_placeholder")]
    public string Q3Placeholder { get; set; }

    [JsonPropertyName("answer_label")]
    public string AnswerLabel { get; set; }

    [JsonPropertyName("answer_err_msg")]
    public string AnswerErrMsg { get; set; }

    [JsonPropertyName("q1")]
    public string Q1 { get; set; }

    [JsonPropertyName("q2")]
    public string Q2 { get; set; }

    [JsonPropertyName("q3")]
    public string Q3 { get; set; }
}

public class AuthSetPassword
{
    [JsonPropertyName("general_error")]
    public string GeneralError { get; set; }

    [JsonPropertyName("user_configuration_error")]
    public string UserConfigurationError { get; set; }

    [JsonPropertyName("user_action_forbidden")]
    public string UserActionForbidden { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("new_password")]
    public string NewPassword { get; set; }

    [JsonPropertyName("confirm_password")]
    public string ConfirmPassword { get; set; }

    [JsonPropertyName("set_button")]
    public string SetButton { get; set; }

    [JsonPropertyName("confirm_msg")]
    public string ConfirmMsg { get; set; }

    [JsonPropertyName("ban_err_msg")]
    public string BanErrMsg { get; set; }

    [JsonPropertyName("note")]
    public string Note { get; set; }

    [JsonPropertyName("no_access_msg")]
    public string NoAccessMsg { get; set; }

    [JsonPropertyName("password_msg")]
    public string PasswordMsg { get; set; }
}

public class CashForm
{
    [JsonPropertyName("date_of_signing")]
    public string DateOfSigning { get; set; }

    [JsonPropertyName("flow_type")]
    public string FlowType { get; set; }

    [JsonPropertyName("please_select_one")]
    public string PleaseSelectOne { get; set; }

    [JsonPropertyName("special_instruction")]
    public string SpecialInstruction { get; set; }

    [JsonPropertyName("reset")]
    public string Reset { get; set; }

    [JsonPropertyName("portfolio")]
    public string Portfolio { get; set; }

    [JsonPropertyName("custodian_account")]
    public string CustodianAccount { get; set; }

    [JsonPropertyName("subscription")]
    public string Subscription { get; set; }

    [JsonPropertyName("signature")]
    public string Signature { get; set; }

    [JsonPropertyName("redemption")]
    public string Redemption { get; set; }

    [JsonPropertyName("amount")]
    public string Amount { get; set; }

    [JsonPropertyName("name_1")]
    public string Name1 { get; set; }

    [JsonPropertyName("name_2")]
    public string Name2 { get; set; }

    [JsonPropertyName("note")]
    public string Note { get; set; }

    [JsonPropertyName("subscription_des")]
    public string SubscriptionDes { get; set; }

    [JsonPropertyName("redemption_des")]
    public string RedemptionDes { get; set; }

    [JsonPropertyName("print")]
    public string Print { get; set; }

    [JsonPropertyName("currency")]
    public string Currency { get; set; }

    [JsonPropertyName("signatories")]
    public string Signatories { get; set; }

    [JsonPropertyName("reminder")]
    public string Reminder { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("dd")]
    public string Dd { get; set; }

    [JsonPropertyName("mm")]
    public string Mm { get; set; }

    [JsonPropertyName("yyyy")]
    public string Yyyy { get; set; }
}

public class Footer
{
    [JsonPropertyName("close")]
    public string Close { get; set; }

    [JsonPropertyName("disclaimer")]
    public string Disclaimer { get; set; }

    [JsonPropertyName("security")]
    public string Security { get; set; }
}

public class General
{
    [JsonPropertyName("loading_msg")]
    public string LoadingMsg { get; set; }

    [JsonPropertyName("show_result_button")]
    public string ShowResultButton { get; set; }

    [JsonPropertyName("reset_button")]
    public string ResetButton { get; set; }

    [JsonPropertyName("no_available_date")]
    public string NoAvailableDate { get; set; }

    [JsonPropertyName("period_selector_default_title")]
    public string PeriodSelectorDefaultTitle { get; set; }

    [JsonPropertyName("period_selector_types")]
    public string PeriodSelectorTypes { get; set; }

    [JsonPropertyName("period_selector_months")]
    public string PeriodSelectorMonths { get; set; }

    [JsonPropertyName("period_selector_quarters")]
    public string PeriodSelectorQuarters { get; set; }

    [JsonPropertyName("select_data_set")]
    public string SelectDataSet { get; set; }

    [JsonPropertyName("save_view_success")]
    public string SaveViewSuccess { get; set; }

    [JsonPropertyName("save_visible_data")]
    public string SaveVisibleData { get; set; }

    [JsonPropertyName("save_all_data")]
    public string SaveAllData { get; set; }

    [JsonPropertyName("headername_group")]
    public string HeadernameGroup { get; set; }

    [JsonPropertyName("headername_sim_investment_type")]
    public string HeadernameSimInvestmentType { get; set; }

    [JsonPropertyName("headername_country_of_issue")]
    public string HeadernameCountryOfIssue { get; set; }

    [JsonPropertyName("headername_security_security_type")]
    public string HeadernameSecuritySecurityType { get; set; }

    [JsonPropertyName("headername_country of_risk")]
    public string HeadernameCountryOfRisk { get; set; }

    [JsonPropertyName("click_to_download")]
    public string ClickToDownload { get; set; }

    [JsonPropertyName("select_all_portfolios")]
    public string SelectAllPortfolios { get; set; }

    [JsonPropertyName("missing_information_contact")]
    public string MissingInformationContact { get; set; }

    [JsonPropertyName("last_three_months")]
    public string LastThreeMonths { get; set; }

    [JsonPropertyName("fund_reports")]
    public string FundReports { get; set; }

    [JsonPropertyName("please_select_fund_category")]
    public string PleaseSelectFundCategory { get; set; }

    [JsonPropertyName("api_service_is_not_ready")]
    public string ApiServiceIsNotReady { get; set; }

    [JsonPropertyName("specific_api_is_not_ready")]
    public string SpecificApiIsNotReady { get; set; }

    [JsonPropertyName("reset_your_password")]
    public string ResetYourPassword { get; set; }

    [JsonPropertyName("ok")]
    public string Ok { get; set; }

    [JsonPropertyName("retry")]
    public string Retry { get; set; }

    [JsonPropertyName("latest_report")]
    public string LatestReport { get; set; }

    [JsonPropertyName("view_all_reports")]
    public string ViewAllReports { get; set; }

    [JsonPropertyName("fund_centre")]
    public string FundCentre { get; set; }

    [JsonPropertyName("reset")]
    public string Reset { get; set; }

    [JsonPropertyName("submit")]
    public string Submit { get; set; }

    [JsonPropertyName("portfolios_selected")]
    public string PortfoliosSelected { get; set; }

    [JsonPropertyName("months_short")]
    public string MonthsShort { get; set; }

    [JsonPropertyName("date_intervals")]
    public string DateIntervals { get; set; }

    [JsonPropertyName("year_quarters")]
    public string YearQuarters { get; set; }

    [JsonPropertyName("yesterday")]
    public string Yesterday { get; set; }

    [JsonPropertyName("fund_selector_placeholder")]
    public string FundSelectorPlaceholder { get; set; }

    [JsonPropertyName("no_matched_result")]
    public string NoMatchedResult { get; set; }

    [JsonPropertyName("select_fund_category")]
    public string SelectFundCategory { get; set; }

    [JsonPropertyName("no_funds_found")]
    public string NoFundsFound { get; set; }

    [JsonPropertyName("title_we_welcome_your_feedback")]
    public string TitleWeWelcomeYourFeedback { get; set; }

    [JsonPropertyName("feedback_content_text")]
    public string FeedbackContentText { get; set; }

    [JsonPropertyName("take_survey_button")]
    public string TakeSurveyButton { get; set; }

    [JsonPropertyName("cancel_text_no_thanks")]
    public string CancelTextNoThanks { get; set; }

    [JsonPropertyName("feedback")]
    public string Feedback { get; set; }

    [JsonPropertyName("search_placeholder")]
    public string SearchPlaceholder { get; set; }

    [JsonPropertyName("no_search_results")]
    public string NoSearchResults { get; set; }

    [JsonPropertyName("download")]
    public string Download { get; set; }

    [JsonPropertyName("funds_selected")]
    public string FundsSelected { get; set; }

    [JsonPropertyName("span_select_all")]
    public string SpanSelectAll { get; set; }

    [JsonPropertyName("clear_selection")]
    public string ClearSelection { get; set; }

    [JsonPropertyName("select")]
    public string Select { get; set; }

    [JsonPropertyName("client")]
    public string Client { get; set; }

    [JsonPropertyName("portfolio")]
    public string Portfolio { get; set; }

    [JsonPropertyName("code")]
    public string Code { get; set; }

    [JsonPropertyName("report_type")]
    public string ReportType { get; set; }

    [JsonPropertyName("reporting_date")]
    public string ReportingDate { get; set; }

    [JsonPropertyName("reporting_query")]
    public string ReportingQuery { get; set; }

    [JsonPropertyName("technical_query")]
    public string TechnicalQuery { get; set; }

    [JsonPropertyName("update_contact_details")]
    public string UpdateContactDetails { get; set; }

    [JsonPropertyName("feedback_query")]
    public string FeedbackQuery { get; set; }

    [JsonPropertyName("support_case_submitted")]
    public string SupportCaseSubmitted { get; set; }

    [JsonPropertyName("help_us_improve_title")]
    public string HelpUsImproveTitle { get; set; }

    [JsonPropertyName("help_us_improve_content")]
    public string HelpUsImproveContent { get; set; }

    [JsonPropertyName("help_us_improve_button_text")]
    public string HelpUsImproveButtonText { get; set; }

    [JsonPropertyName("new")]
    public string New { get; set; }

    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("npv_reports_not_found")]
    public string NpvReportsNotFound { get; set; }

    [JsonPropertyName("quick_report_picker")]
    public string QuickReportPicker { get; set; }

    [JsonPropertyName("go")]
    public string Go { get; set; }

    [JsonPropertyName("welcome")]
    public string Welcome { get; set; }

    [JsonPropertyName("npv_greetings_text")]
    public string NpvGreetingsText { get; set; }

    [JsonPropertyName("frequency")]
    public string Frequency { get; set; }

    [JsonPropertyName("report_download_error_message")]
    public string ReportDownloadErrorMessage { get; set; }

    [JsonPropertyName("updated_notifications")]
    public string UpdatedNotifications { get; set; }

    [JsonPropertyName("successfully_updated_notifications")]
    public string SuccessfullyUpdatedNotifications { get; set; }

    [JsonPropertyName("updated_password")]
    public string UpdatedPassword { get; set; }

    [JsonPropertyName("successfully_updated_password")]
    public string SuccessfullyUpdatedPassword { get; set; }

    [JsonPropertyName("profile_search_placeholder")]
    public string ProfileSearchPlaceholder { get; set; }

    [JsonPropertyName("invalid_date")]
    public string InvalidDate { get; set; }
}

public class Home
{
    [JsonPropertyName("latest_report_portfolio_report")]
    public string LatestReportPortfolioReport { get; set; }

    [JsonPropertyName("quick_links_title")]
    public string QuickLinksTitle { get; set; }

    [JsonPropertyName("insights_no_data_title")]
    public string InsightsNoDataTitle { get; set; }

    [JsonPropertyName("insights_error_title")]
    public string InsightsErrorTitle { get; set; }

    [JsonPropertyName("insights_error_text")]
    public string InsightsErrorText { get; set; }

    [JsonPropertyName("insights_button")]
    public string InsightsButton { get; set; }

    [JsonPropertyName("greeting_ok_btn")]
    public string GreetingOkBtn { get; set; }

    [JsonPropertyName("greeting_cancel_btn")]
    public string GreetingCancelBtn { get; set; }

    [JsonPropertyName("latest_report_scheduled_report")]
    public string LatestReportScheduledReport { get; set; }

    [JsonPropertyName("new_user_greeting_title")]
    public string NewUserGreetingTitle { get; set; }

    [JsonPropertyName("existing_user_greeting_title")]
    public string ExistingUserGreetingTitle { get; set; }

    [JsonPropertyName("existing_user_greeting_text")]
    public string ExistingUserGreetingText { get; set; }

    [JsonPropertyName("existing_user_greeting_text2")]
    public string ExistingUserGreetingText2 { get; set; }

    [JsonPropertyName("user_dismiss")]
    public string UserDismiss { get; set; }

    [JsonPropertyName("new_user_greeting_text")]
    public string NewUserGreetingText { get; set; }

    [JsonPropertyName("latest_report_no_data")]
    public string LatestReportNoData { get; set; }

    [JsonPropertyName("latest_report_tips")]
    public string LatestReportTips { get; set; }

    [JsonPropertyName("latest_report_redirect")]
    public string LatestReportRedirect { get; set; }

    [JsonPropertyName("search_placeholder")]
    public string SearchPlaceholder { get; set; }

    [JsonPropertyName("selector_client")]
    public string SelectorClient { get; set; }

    [JsonPropertyName("selector_portfolio")]
    public string SelectorPortfolio { get; set; }

    [JsonPropertyName("selector_code")]
    public string SelectorCode { get; set; }

    [JsonPropertyName("brief1")]
    public string Brief1 { get; set; }

    [JsonPropertyName("description1")]
    public string Description1 { get; set; }

    [JsonPropertyName("title2")]
    public string Title2 { get; set; }

    [JsonPropertyName("brief2")]
    public string Brief2 { get; set; }

    [JsonPropertyName("description2")]
    public string Description2 { get; set; }

    [JsonPropertyName("whatsnew_title")]
    public string WhatsnewTitle { get; set; }

    [JsonPropertyName("whatsnew_view_all")]
    public string WhatsnewViewAll { get; set; }

    [JsonPropertyName("aum_as_of")]
    public string AumAsOf { get; set; }

    [JsonPropertyName("aum_title")]
    public string AumTitle { get; set; }

    [JsonPropertyName("aum_no_data_title")]
    public string AumNoDataTitle { get; set; }

    [JsonPropertyName("aum_no_data_text")]
    public string AumNoDataText { get; set; }

    [JsonPropertyName("aum_tips")]
    public string AumTips { get; set; }

    [JsonPropertyName("aum_redirect")]
    public string AumRedirect { get; set; }

    [JsonPropertyName("latest_report_title")]
    public string LatestReportTitle { get; set; }
}

public class Impersonation
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("impersonate")]
    public string Impersonate { get; set; }

    [JsonPropertyName("nousertext")]
    public string Nousertext { get; set; }

    [JsonPropertyName("search_placeholder")]
    public string SearchPlaceholder { get; set; }
}

public class Ldi
{
    [JsonPropertyName("3d")]
    public string Threed { get; set; }

    [JsonPropertyName("1m")]
    public string OneM { get; set; }

    [JsonPropertyName("3m")]
    public string ThreeM { get; set; }

    [JsonPropertyName("6m")]
    public string SixM { get; set; }

    [JsonPropertyName("1y")]
    public string OneY { get; set; }

    [JsonPropertyName("5y")]
    public string FiveY { get; set; }

    [JsonPropertyName("all")]
    public string All { get; set; }

    [JsonPropertyName("funding_level_over_view")]
    public string FundingLevelOverView { get; set; }

    [JsonPropertyName("in")]
    public string In { get; set; }

    [JsonPropertyName("out")]
    public string Out { get; set; }

    [JsonPropertyName("source_text_four")]
    public string SourceTextFour { get; set; }

    [JsonPropertyName("source_text_title")]
    public string SourceTextTitle { get; set; }

    [JsonPropertyName("source_text_one")]
    public string SourceTextOne { get; set; }

    [JsonPropertyName("source_text_two")]
    public string SourceTextTwo { get; set; }

    [JsonPropertyName("source_text_three")]
    public string SourceTextThree { get; set; }

    [JsonPropertyName("load_summary_error")]
    public string LoadSummaryError { get; set; }

    [JsonPropertyName("funding_level")]
    public string FundingLevel { get; set; }

    [JsonPropertyName("asset_value")]
    public string AssetValue { get; set; }

    [JsonPropertyName("liability_value")]
    public string LiabilityValue { get; set; }

    [JsonPropertyName("client_name")]
    public string ClientName { get; set; }

    [JsonPropertyName("account_number")]
    public string AccountNumber { get; set; }

    [JsonPropertyName("load_chart_data_error")]
    public string LoadChartDataError { get; set; }

    [JsonPropertyName("funding_level_as_of")]
    public string FundingLevelAsOf { get; set; }

    [JsonPropertyName("funding_level_disclaimer")]
    public string FundingLevelDisclaimer { get; set; }

    [JsonPropertyName("asset_value_disclaimer")]
    public string AssetValueDisclaimer { get; set; }

    [JsonPropertyName("liability_value_disclaimer")]
    public string LiabilityValueDisclaimer { get; set; }

    [JsonPropertyName("pension_management_limit")]
    public string PensionManagementLimit { get; set; }

    [JsonPropertyName("investment_management_limit")]
    public string InvestmentManagementLimit { get; set; }

    [JsonPropertyName("an_error_occured")]
    public string AnErrorOccured { get; set; }

    [JsonPropertyName("please_refresh")]
    public string PleaseRefresh { get; set; }

    [JsonPropertyName("funding_level_overview")]
    public string FundingLevelOverviewTwo { get; set; }

    [JsonPropertyName("print")]
    public string Print { get; set; }

    [JsonPropertyName("select_date_range")]
    public string SelectDateRange { get; set; }

    [JsonPropertyName("more_about_the_chart")]
    public string MoreAboutTheChart { get; set; }
}

public class McstMenu
{
    [JsonPropertyName("mcst")]
    public string Mcst { get; set; }

    [JsonPropertyName("empty_message")]
    public string EmptyMessage { get; set; }

    [JsonPropertyName("view_all")]
    public string ViewAll { get; set; }
}

public class McstView
{
    [JsonPropertyName("mcst")]
    public string Mcst { get; set; }

    [JsonPropertyName("empty_message")]
    public string EmptyMessage { get; set; }

    [JsonPropertyName("empty_contact")]
    public string EmptyContact { get; set; }
}

public class Navigation
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("logout")]
    public string Logout { get; set; }

    [JsonPropertyName("reset_pwd")]
    public string ResetPwd { get; set; }

    [JsonPropertyName("nav_report")]
    public string NavReport { get; set; }

    [JsonPropertyName("nav_reportdesc")]
    public string NavReportdesc { get; set; }

    [JsonPropertyName("nav_home")]
    public string NavHome { get; set; }

    [JsonPropertyName("nav_homedesc")]
    public string NavHomedesc { get; set; }

    [JsonPropertyName("nav_unaudited")]
    public string NavUnaudited { get; set; }

    [JsonPropertyName("nav_unauditeddesc")]
    public string NavUnauditeddesc { get; set; }

    [JsonPropertyName("nav_cash")]
    public string NavCash { get; set; }

    [JsonPropertyName("nav_cashdesc")]
    public string NavCashdesc { get; set; }

    [JsonPropertyName("nav_auditor")]
    public string NavAuditor { get; set; }

    [JsonPropertyName("nav_auditordesc")]
    public string NavAuditordesc { get; set; }

    [JsonPropertyName("nav_nonportfolioview")]
    public string NavNonportfolioview { get; set; }

    [JsonPropertyName("nav_impersonation")]
    public string NavImpersonation { get; set; }

    [JsonPropertyName("nav_consultantreport")]
    public string NavConsultantreport { get; set; }

    [JsonPropertyName("help_support")]
    public string HelpSupport { get; set; }

    [JsonPropertyName("impersonate_help_text")]
    public string ImpersonateHelpText { get; set; }

    [JsonPropertyName("stop_impersonate")]
    public string StopImpersonate { get; set; }
}

public class Page
{
    [JsonPropertyName("back")]
    public string Back { get; set; }

    [JsonPropertyName("error_msg")]
    public string ErrorMsg { get; set; }

    [JsonPropertyName("under_construction_title")]
    public string UnderConstructionTitle { get; set; }

    [JsonPropertyName("under_construction_description")]
    public string UnderConstructionDescription { get; set; }

    [JsonPropertyName("error_handling_title")]
    public string ErrorHandlingTitle { get; set; }

    [JsonPropertyName("error_handling_unauthorized")]
    public string ErrorHandlingUnauthorized { get; set; }

    [JsonPropertyName("error_handling_forbidden")]
    public string ErrorHandlingForbidden { get; set; }

    [JsonPropertyName("error_handling_default")]
    public string ErrorHandlingDefault { get; set; }

    [JsonPropertyName("error_handling_server_error")]
    public string ErrorHandlingServerError { get; set; }
}

public class PortfolioSelector
{
    [JsonPropertyName("code")]
    public string Code { get; set; }

    [JsonPropertyName("portfolio")]
    public string Portfolio { get; set; }

    [JsonPropertyName("select_same_client")]
    public string SelectSameClient { get; set; }

    [JsonPropertyName("default_title")]
    public string DefaultTitle { get; set; }

    [JsonPropertyName("view_all")]
    public string ViewAll { get; set; }

    [JsonPropertyName("help_text")]
    public string HelpText { get; set; }

    [JsonPropertyName("search_text")]
    public string SearchText { get; set; }

    [JsonPropertyName("submit")]
    public string Submit { get; set; }

    [JsonPropertyName("reset")]
    public string Reset { get; set; }

    [JsonPropertyName("clear_all")]
    public string ClearAll { get; set; }

    [JsonPropertyName("empty")]
    public string Empty { get; set; }

    [JsonPropertyName("select")]
    public string Select { get; set; }

    [JsonPropertyName("client")]
    public string Client { get; set; }

    [JsonPropertyName("default_title_auditor")]
    public string DefaultTitleAuditor { get; set; }
}

public class Profile
{
    [JsonPropertyName("password_rule_uppercase_des")]
    public string PasswordRuleUppercaseDes { get; set; }

    [JsonPropertyName("password_rule_lowercase_des")]
    public string PasswordRuleLowercaseDes { get; set; }

    [JsonPropertyName("password_rule_bannedpassword_des")]
    public string PasswordRuleBannedpasswordDes { get; set; }

    [JsonPropertyName("password_form_current_title")]
    public string PasswordFormCurrentTitle { get; set; }

    [JsonPropertyName("password_form_current_placeholder")]
    public string PasswordFormCurrentPlaceholder { get; set; }

    [JsonPropertyName("password_form_current_errmessage")]
    public string PasswordFormCurrentErrmessage { get; set; }

    [JsonPropertyName("password_form_new_title")]
    public string PasswordFormNewTitle { get; set; }

    [JsonPropertyName("password_form_new_placeholder")]
    public string PasswordFormNewPlaceholder { get; set; }

    [JsonPropertyName("password_rule_digit_des")]
    public string PasswordRuleDigitDes { get; set; }

    [JsonPropertyName("password_form_new_errmessage")]
    public string PasswordFormNewErrmessage { get; set; }

    [JsonPropertyName("password_form_confirm_placeholder")]
    public string PasswordFormConfirmPlaceholder { get; set; }

    [JsonPropertyName("password_form_confirm_errmessage")]
    public string PasswordFormConfirmErrmessage { get; set; }

    [JsonPropertyName("tac")]
    public string Tac { get; set; }

    [JsonPropertyName("logout")]
    public string Logout { get; set; }

    [JsonPropertyName("close")]
    public string Close { get; set; }

    [JsonPropertyName("greeting")]
    public string Greeting { get; set; }

    [JsonPropertyName("stopimpersonate")]
    public string Stopimpersonate { get; set; }

    [JsonPropertyName("password_form_confirm_title")]
    public string PasswordFormConfirmTitle { get; set; }

    [JsonPropertyName("password_rule_length_des")]
    public string PasswordRuleLengthDes { get; set; }

    [JsonPropertyName("password_rule_bannedpassword")]
    public string PasswordRuleBannedpassword { get; set; }

    [JsonPropertyName("password_rule_lowercase")]
    public string PasswordRuleLowercase { get; set; }

    [JsonPropertyName("address_city")]
    public string AddressCity { get; set; }

    [JsonPropertyName("address_state")]
    public string AddressState { get; set; }

    [JsonPropertyName("address_postcode")]
    public string AddressPostcode { get; set; }

    [JsonPropertyName("address_country")]
    public string AddressCountry { get; set; }

    [JsonPropertyName("notification_alert_msg")]
    public string NotificationAlertMsg { get; set; }

    [JsonPropertyName("notification_update")]
    public string NotificationUpdate { get; set; }

    [JsonPropertyName("notification_user_report")]
    public string NotificationUserReport { get; set; }

    [JsonPropertyName("notification_general_report")]
    public string NotificationGeneralReport { get; set; }

    [JsonPropertyName("notification_note")]
    public string NotificationNote { get; set; }

    [JsonPropertyName("password_alert_msg")]
    public string PasswordAlertMsg { get; set; }

    [JsonPropertyName("password_title")]
    public string PasswordTitle { get; set; }

    [JsonPropertyName("password_note_head")]
    public string PasswordNoteHead { get; set; }

    [JsonPropertyName("password_success_msg")]
    public string PasswordSuccessMsg { get; set; }

    [JsonPropertyName("password_mismatch_msg")]
    public string PasswordMismatchMsg { get; set; }

    [JsonPropertyName("password_char_err_msg")]
    public string PasswordCharErrMsg { get; set; }

    [JsonPropertyName("password_err_ban")]
    public string PasswordErrBan { get; set; }

    [JsonPropertyName("password_rule_length")]
    public string PasswordRuleLength { get; set; }

    [JsonPropertyName("password_rule_digit")]
    public string PasswordRuleDigit { get; set; }

    [JsonPropertyName("password_rule_uppercase")]
    public string PasswordRuleUppercase { get; set; }

    [JsonPropertyName("address_street")]
    public string AddressStreet { get; set; }

    [JsonPropertyName("address_alert_msg")]
    public string AddressAlertMsg { get; set; }

    [JsonPropertyName("details_update")]
    public string DetailsUpdate { get; set; }

    [JsonPropertyName("tab_title")]
    public string TabTitle { get; set; }

    [JsonPropertyName("tab_personal_details")]
    public string TabPersonalDetails { get; set; }

    [JsonPropertyName("tab_portfolio_address")]
    public string TabPortfolioAddress { get; set; }

    [JsonPropertyName("tab_notification")]
    public string TabNotification { get; set; }

    [JsonPropertyName("tab_change_password")]
    public string TabChangePassword { get; set; }

    [JsonPropertyName("details_alert_msg")]
    public string DetailsAlertMsg { get; set; }

    [JsonPropertyName("details_name")]
    public string DetailsName { get; set; }

    [JsonPropertyName("details_title")]
    public string DetailsTitle { get; set; }

    [JsonPropertyName("details_organisation")]
    public string DetailsOrganisation { get; set; }

    [JsonPropertyName("details_role")]
    public string DetailsRole { get; set; }

    [JsonPropertyName("details_email")]
    public string DetailsEmail { get; set; }

    [JsonPropertyName("details_contact_number")]
    public string DetailsContactNumber { get; set; }

    [JsonPropertyName("details_request_update")]
    public string DetailsRequestUpdate { get; set; }

    [JsonPropertyName("details_cancel_btn")]
    public string DetailsCancelBtn { get; set; }

    [JsonPropertyName("contact_us")]
    public string ContactUs { get; set; }
}

public class Reportstab
{
    [JsonPropertyName("bi-annually")]
    public string BiAnnually { get; set; }

    [JsonPropertyName("annually")]
    public string Annually { get; set; }

    [JsonPropertyName("reports_not_found_title")]
    public string ReportsNotFoundTitle { get; set; }

    [JsonPropertyName("reports_not_found_text")]
    public string ReportsNotFoundText { get; set; }

    [JsonPropertyName("latest_reports_not_found_title")]
    public string LatestReportsNotFoundTitle { get; set; }

    [JsonPropertyName("latest_reports_not_found_text")]
    public string LatestReportsNotFoundText { get; set; }

    [JsonPropertyName("scheduled_reports_not_found_title")]
    public string ScheduledReportsNotFoundTitle { get; set; }

    [JsonPropertyName("scheduled_reports_not_found_text")]
    public string ScheduledReportsNotFoundText { get; set; }

    [JsonPropertyName("scheduled_reports_not_found_link")]
    public string ScheduledReportsNotFoundLink { get; set; }

    [JsonPropertyName("latest_scheduled_reports_not_found_title")]
    public string LatestScheduledReportsNotFoundTitle { get; set; }

    [JsonPropertyName("latest_scheduled_reports_not_found_text")]
    public string LatestScheduledReportsNotFoundText { get; set; }

    [JsonPropertyName("quarterly")]
    public string Quarterly { get; set; }

    [JsonPropertyName("scheduler_not_found_title")]
    public string SchedulerNotFoundTitle { get; set; }

    [JsonPropertyName("filter_header_text")]
    public string FilterHeaderText { get; set; }

    [JsonPropertyName("filter_button_text")]
    public string FilterButtonText { get; set; }

    [JsonPropertyName("results_for")]
    public string ResultsFor { get; set; }

    [JsonPropertyName("period_selector_title")]
    public string PeriodSelectorTitle { get; set; }

    [JsonPropertyName("result_tooltip")]
    public string ResultTooltip { get; set; }

    [JsonPropertyName("period_selector_note")]
    public string PeriodSelectorNote { get; set; }

    [JsonPropertyName("keywords")]
    public string Keywords { get; set; }

    [JsonPropertyName("select_all")]
    public string SelectAll { get; set; }

    [JsonPropertyName("scheduler_not_found_text")]
    public string SchedulerNotFoundText { get; set; }

    [JsonPropertyName("monthly")]
    public string Monthly { get; set; }

    [JsonPropertyName("weekly")]
    public string Weekly { get; set; }

    [JsonPropertyName("daily")]
    public string Daily { get; set; }

    [JsonPropertyName("qhd_tooltip")]
    public string QhdTooltip { get; set; }

    [JsonPropertyName("qgc_tooltip")]
    public string QgcTooltip { get; set; }

    [JsonPropertyName("qgb_tooltip")]
    public string QgbTooltip { get; set; }

    [JsonPropertyName("npv9_tooltip")]
    public string Npv9Tooltip { get; set; }

    [JsonPropertyName("aaf_tooltip")]
    public string AafTooltip { get; set; }

    [JsonPropertyName("bnd_tooltip")]
    public string BndTooltip { get; set; }

    [JsonPropertyName("dge_tooltip")]
    public string DgeTooltip { get; set; }

    [JsonPropertyName("dgf_tooltip")]
    public string DgfTooltip { get; set; }

    [JsonPropertyName("gav_tooltip")]
    public string GavTooltip { get; set; }

    [JsonPropertyName("gea_tooltip")]
    public string GeaTooltip { get; set; }

    [JsonPropertyName("gem_tooltip")]
    public string GemTooltip { get; set; }

    [JsonPropertyName("geq_tooltip")]
    public string GeqTooltip { get; set; }

    [JsonPropertyName("idg_tooltip")]
    public string IdgTooltip { get; set; }

    [JsonPropertyName("mbi_tooltip")]
    public string MbiTooltip { get; set; }

    [JsonPropertyName("mbx_tooltip")]
    public string MbxTooltip { get; set; }

    [JsonPropertyName("mef_tooltip")]
    public string MefTooltip { get; set; }

    [JsonPropertyName("pac_tooltip")]
    public string PacTooltip { get; set; }

    [JsonPropertyName("qep_tooltip")]
    public string QepTooltip { get; set; }

    [JsonPropertyName("oneoff")]
    public string Oneoff { get; set; }

    [JsonPropertyName("clear_all")]
    public string ClearAll { get; set; }

    [JsonPropertyName("glo_tooltip")]
    public string GloTooltip { get; set; }

    [JsonPropertyName("search_title")]
    public string SearchTitle { get; set; }

    [JsonPropertyName("view_report_scheduler_button")]
    public string ViewReportSchedulerButton { get; set; }

    [JsonPropertyName("transaction_period_day")]
    public string TransactionPeriodDay { get; set; }

    [JsonPropertyName("transaction_period_week")]
    public string TransactionPeriodWeek { get; set; }

    [JsonPropertyName("transaction_period_month")]
    public string TransactionPeriodMonth { get; set; }

    [JsonPropertyName("transaction_period_quarter")]
    public string TransactionPeriodQuarter { get; set; }

    [JsonPropertyName("transaction_trade_date")]
    public string TransactionTradeDate { get; set; }

    [JsonPropertyName("transaction_settlement_date")]
    public string TransactionSettlementDate { get; set; }

    [JsonPropertyName("scheduler_modal_one_off")]
    public string SchedulerModalOneOff { get; set; }

    [JsonPropertyName("scheduler_modal_daily")]
    public string SchedulerModalDaily { get; set; }

    [JsonPropertyName("scheduler_modal_transaction_type")]
    public string SchedulerModalTransactionType { get; set; }

    [JsonPropertyName("scheduler_modal_weekly")]
    public string SchedulerModalWeekly { get; set; }

    [JsonPropertyName("scheduler_modal_freq_tomorrow")]
    public string SchedulerModalFreqTomorrow { get; set; }

    [JsonPropertyName("on_a_date")]
    public string OnADate { get; set; }

    [JsonPropertyName("scheduler_modal_freq_mon")]
    public string SchedulerModalFreqMon { get; set; }

    [JsonPropertyName("scheduler_modal_freq_tue")]
    public string SchedulerModalFreqTue { get; set; }

    [JsonPropertyName("scheduler_modal_freq_wed")]
    public string SchedulerModalFreqWed { get; set; }

    [JsonPropertyName("scheduler_modal_freq_thur")]
    public string SchedulerModalFreqThur { get; set; }

    [JsonPropertyName("scheduler_modal_freq_fri")]
    public string SchedulerModalFreqFri { get; set; }

    [JsonPropertyName("scheduler_modal_freq_sat")]
    public string SchedulerModalFreqSat { get; set; }

    [JsonPropertyName("scheduler_modal_monthly")]
    public string SchedulerModalMonthly { get; set; }

    [JsonPropertyName("transaction_date_selector")]
    public string TransactionDateSelector { get; set; }

    [JsonPropertyName("transaction_reporting_selector")]
    public string TransactionReportingSelector { get; set; }

    [JsonPropertyName("holding_selector_title")]
    public string HoldingSelectorTitle { get; set; }

    [JsonPropertyName("create_scheduler_success_msg")]
    public string CreateSchedulerSuccessMsg { get; set; }

    [JsonPropertyName("create_scheduler_success_title")]
    public string CreateSchedulerSuccessTitle { get; set; }

    [JsonPropertyName("remove_scheduler_success_msg")]
    public string RemoveSchedulerSuccessMsg { get; set; }

    [JsonPropertyName("remove_scheduler_success_title")]
    public string RemoveSchedulerSuccessTitle { get; set; }

    [JsonPropertyName("scheduler_back_button")]
    public string SchedulerBackButton { get; set; }

    [JsonPropertyName("scheduler_create_button")]
    public string SchedulerCreateButton { get; set; }

    [JsonPropertyName("scheduler_holding_type")]
    public string SchedulerHoldingType { get; set; }

    [JsonPropertyName("scheduler_transaction_type")]
    public string SchedulerTransactionType { get; set; }

    [JsonPropertyName("scheduler_edit_button")]
    public string SchedulerEditButton { get; set; }

    [JsonPropertyName("scheduler_remove_button")]
    public string SchedulerRemoveButton { get; set; }

    [JsonPropertyName("scheduler_columns_portfolio")]
    public string SchedulerColumnsPortfolio { get; set; }

    [JsonPropertyName("scheduler_columns_code")]
    public string SchedulerColumnsCode { get; set; }

    [JsonPropertyName("scheduler_columns_type")]
    public string SchedulerColumnsType { get; set; }

    [JsonPropertyName("scheduler_columns_freq")]
    public string SchedulerColumnsFreq { get; set; }

    [JsonPropertyName("scheduler_columns_date")]
    public string SchedulerColumnsDate { get; set; }

    [JsonPropertyName("scheduler_modal_title")]
    public string SchedulerModalTitle { get; set; }

    [JsonPropertyName("scheduler_modal_edit_title")]
    public string SchedulerModalEditTitle { get; set; }

    [JsonPropertyName("scheduler_modal_freq_title")]
    public string SchedulerModalFreqTitle { get; set; }

    [JsonPropertyName("scheduler_modal_type_title")]
    public string SchedulerModalTypeTitle { get; set; }

    [JsonPropertyName("scheduler_modal_holding_type")]
    public string SchedulerModalHoldingType { get; set; }

    [JsonPropertyName("search_placeholder")]
    public string SearchPlaceholder { get; set; }

    [JsonPropertyName("sir_tooltip")]
    public string SirTooltip { get; set; }

    [JsonPropertyName("qgm2_tooltip")]
    public string Qgm2Tooltip { get; set; }

    [JsonPropertyName("mst_tooltip")]
    public string MstTooltip { get; set; }

    [JsonPropertyName("dgf")]
    public string Dgf { get; set; }

    [JsonPropertyName("npv1")]
    public string Npv1 { get; set; }

    [JsonPropertyName("fvc")]
    public string Fvc { get; set; }

    [JsonPropertyName("mkr")]
    public string Mkr { get; set; }

    [JsonPropertyName("lrr")]
    public string Lrr { get; set; }

    [JsonPropertyName("lv2")]
    public string Lv2 { get; set; }

    [JsonPropertyName("spr")]
    public string Spr { get; set; }

    [JsonPropertyName("orc")]
    public string Orc { get; set; }

    [JsonPropertyName("gea")]
    public string Gea { get; set; }

    [JsonPropertyName("spc")]
    public string Spc { get; set; }

    [JsonPropertyName("fun")]
    public string Fun { get; set; }

    [JsonPropertyName("rsk")]
    public string Rsk { get; set; }

    [JsonPropertyName("bar")]
    public string Bar { get; set; }

    [JsonPropertyName("fac")]
    public string Fac { get; set; }

    [JsonPropertyName("rsc")]
    public string Rsc { get; set; }

    [JsonPropertyName("cou")]
    public string Cou { get; set; }

    [JsonPropertyName("lrs")]
    public string Lrs { get; set; }

    [JsonPropertyName("dex")]
    public string Dex { get; set; }

    [JsonPropertyName("pos")]
    public string Pos { get; set; }

    [JsonPropertyName("gem")]
    public string Gem { get; set; }

    [JsonPropertyName("geq")]
    public string Geq { get; set; }

    [JsonPropertyName("idg")]
    public string Idg { get; set; }

    [JsonPropertyName("inv")]
    public string Inv { get; set; }

    [JsonPropertyName("inp")]
    public string Inp { get; set; }

    [JsonPropertyName("glo")]
    public string Glo { get; set; }

    [JsonPropertyName("fvr")]
    public string Fvr { get; set; }

    [JsonPropertyName("fvb")]
    public string Fvb { get; set; }

    [JsonPropertyName("ets")]
    public string Ets { get; set; }

    [JsonPropertyName("dmf")]
    public string Dmf { get; set; }

    [JsonPropertyName("usv")]
    public string Usv { get; set; }

    [JsonPropertyName("usp")]
    public string Usp { get; set; }

    [JsonPropertyName("ueq")]
    public string Ueq { get; set; }

    [JsonPropertyName("qhg")]
    public string Qhg { get; set; }

    [JsonPropertyName("qhd")]
    public string Qhd { get; set; }

    [JsonPropertyName("qgc")]
    public string Qgc { get; set; }

    [JsonPropertyName("qgb")]
    public string Qgb { get; set; }

    [JsonPropertyName("qep")]
    public string Qep { get; set; }

    [JsonPropertyName("pac")]
    public string Pac { get; set; }

    [JsonPropertyName("mef")]
    public string Mef { get; set; }

    [JsonPropertyName("mbx")]
    public string Mbx { get; set; }

    [JsonPropertyName("mbi")]
    public string Mbi { get; set; }

    [JsonPropertyName("vag")]
    public string Vag { get; set; }

    [JsonPropertyName("sqo")]
    public string Sqo { get; set; }

    [JsonPropertyName("mpr")]
    public string Mpr { get; set; }

    [JsonPropertyName("mes")]
    public string Mes { get; set; }

    [JsonPropertyName("npv1_tooltip")]
    public string Npv1Tooltip { get; set; }

    [JsonPropertyName("npv10_tooltip")]
    public string Npv10Tooltip { get; set; }

    [JsonPropertyName("npv11_tooltip")]
    public string Npv11Tooltip { get; set; }

    [JsonPropertyName("npv12_tooltip")]
    public string Npv12Tooltip { get; set; }

    [JsonPropertyName("npv13_tooltip")]
    public string Npv13Tooltip { get; set; }

    [JsonPropertyName("npv6_tooltip")]
    public string Npv6Tooltip { get; set; }

    [JsonPropertyName("npv7_tooltip")]
    public string Npv7Tooltip { get; set; }

    [JsonPropertyName("npv8_tooltip")]
    public string Npv8Tooltip { get; set; }

    [JsonPropertyName("ueq_tooltip")]
    public string UeqTooltip { get; set; }

    [JsonPropertyName("usp_tooltip")]
    public string UspTooltip { get; set; }

    [JsonPropertyName("usv_tooltip")]
    public string UsvTooltip { get; set; }

    [JsonPropertyName("dmf_tooltip")]
    public string DmfTooltip { get; set; }

    [JsonPropertyName("ets_tooltip")]
    public string EtsTooltip { get; set; }

    [JsonPropertyName("fvb_tooltip")]
    public string FvbTooltip { get; set; }

    [JsonPropertyName("qhg_tooltip")]
    public string QhgTooltip { get; set; }

    [JsonPropertyName("fvr_tooltip")]
    public string FvrTooltip { get; set; }

    [JsonPropertyName("inp_tooltip")]
    public string InpTooltip { get; set; }

    [JsonPropertyName("inv_tooltip")]
    public string InvTooltip { get; set; }

    [JsonPropertyName("msh_tooltip")]
    public string MshTooltip { get; set; }

    [JsonPropertyName("npv15_tooltip")]
    public string Npv15Tooltip { get; set; }

    [JsonPropertyName("scheduler_modal_freq_sun")]
    public string SchedulerModalFreqSun { get; set; }

    [JsonPropertyName("npv14_tooltip")]
    public string Npv14Tooltip { get; set; }

    [JsonPropertyName("npv5_tooltip")]
    public string Npv5Tooltip { get; set; }

    [JsonPropertyName("mcc")]
    public string Mcc { get; set; }

    [JsonPropertyName("att")]
    public string Att { get; set; }

    [JsonPropertyName("adt")]
    public string Adt { get; set; }

    [JsonPropertyName("srr_tooltip")]
    public string SrrTooltip { get; set; }

    [JsonPropertyName("npv18_tooltip")]
    public string Npv18Tooltip { get; set; }

    [JsonPropertyName("npv19_tooltip")]
    public string Npv19Tooltip { get; set; }

    [JsonPropertyName("npv2_tooltip")]
    public string Npv2Tooltip { get; set; }

    [JsonPropertyName("npv20_tooltip")]
    public string Npv20Tooltip { get; set; }

    [JsonPropertyName("npv21_tooltip")]
    public string Npv21Tooltip { get; set; }

    [JsonPropertyName("npv22_tooltip")]
    public string Npv22Tooltip { get; set; }

    [JsonPropertyName("npv17_tooltip")]
    public string Npv17Tooltip { get; set; }

    [JsonPropertyName("npv23_tooltip")]
    public string Npv23Tooltip { get; set; }

    [JsonPropertyName("npv25_tooltip")]
    public string Npv25Tooltip { get; set; }

    [JsonPropertyName("npv26_tooltip")]
    public string Npv26Tooltip { get; set; }

    [JsonPropertyName("npv27_tooltip")]
    public string Npv27Tooltip { get; set; }

    [JsonPropertyName("npv28_tooltip")]
    public string Npv28Tooltip { get; set; }

    [JsonPropertyName("npv3_tooltip")]
    public string Npv3Tooltip { get; set; }

    [JsonPropertyName("npv4_tooltip")]
    public string Npv4Tooltip { get; set; }

    [JsonPropertyName("npv24_tooltip")]
    public string Npv24Tooltip { get; set; }

    [JsonPropertyName("npv16_tooltip")]
    public string Npv16Tooltip { get; set; }

    [JsonPropertyName("psr")]
    public string Psr { get; set; }

    [JsonPropertyName("lep")]
    public string Lep { get; set; }

    [JsonPropertyName("str")]
    public string Str { get; set; }

    [JsonPropertyName("fvre")]
    public string Fvre { get; set; }

    [JsonPropertyName("fvbe")]
    public string Fvbe { get; set; }

    [JsonPropertyName("fvre_tooltip")]
    public string FvreTooltip { get; set; }

    [JsonPropertyName("fvbe_tooltip")]
    public string FvbeTooltip { get; set; }

    [JsonPropertyName("msh")]
    public string Msh { get; set; }

    [JsonPropertyName("first_day_of_the_month")]
    public string FirstDayOfTheMonth { get; set; }

    [JsonPropertyName("on_a_day")]
    public string OnADay { get; set; }

    [JsonPropertyName("create_scheduler_error_duplicate")]
    public string CreateSchedulerErrorDuplicate { get; set; }

    [JsonPropertyName("st_suffix")]
    public string StSuffix { get; set; }

    [JsonPropertyName("nd_suffix")]
    public string NdSuffix { get; set; }

    [JsonPropertyName("rd_suffix")]
    public string RdSuffix { get; set; }

    [JsonPropertyName("th_suffix")]
    public string ThSuffix { get; set; }

    [JsonPropertyName("scheduler_modal_start_from")]
    public string SchedulerModalStartFrom { get; set; }

    [JsonPropertyName("scheduler_modal_notification_title")]
    public string SchedulerModalNotificationTitle { get; set; }

    [JsonPropertyName("scheduler_modal_notification_text")]
    public string SchedulerModalNotificationText { get; set; }

    [JsonPropertyName("scheduler_modal_notification_yes")]
    public string SchedulerModalNotificationYes { get; set; }

    [JsonPropertyName("scheduler_modal_notification_no")]
    public string SchedulerModalNotificationNo { get; set; }

    [JsonPropertyName("remove_modal_title")]
    public string RemoveModalTitle { get; set; }

    [JsonPropertyName("remove_modal_text")]
    public string RemoveModalText { get; set; }

    [JsonPropertyName("remove_modal_ok_button")]
    public string RemoveModalOkButton { get; set; }

    [JsonPropertyName("save_button")]
    public string SaveButton { get; set; }

    [JsonPropertyName("cancel_button")]
    public string CancelButton { get; set; }

    [JsonPropertyName("last_day_of_the_month")]
    public string LastDayOfTheMonth { get; set; }

    [JsonPropertyName("mst")]
    public string Mst { get; set; }

    [JsonPropertyName("qgm2")]
    public string Qgm2 { get; set; }

    [JsonPropertyName("sir")]
    public string Sir { get; set; }

    [JsonPropertyName("frequency")]
    public string Frequency { get; set; }

    [JsonPropertyName("scheduler_type_holdings")]
    public string SchedulerTypeHoldings { get; set; }

    [JsonPropertyName("scheduler_type_transactions")]
    public string SchedulerTypeTransactions { get; set; }

    [JsonPropertyName("selector_pre_title")]
    public string SelectorPreTitle { get; set; }

    [JsonPropertyName("tab_latest_reports")]
    public string TabLatestReports { get; set; }

    [JsonPropertyName("npv24")]
    public string Npv24 { get; set; }

    [JsonPropertyName("npv23")]
    public string Npv23 { get; set; }

    [JsonPropertyName("npv22")]
    public string Npv22 { get; set; }

    [JsonPropertyName("npv21")]
    public string Npv21 { get; set; }

    [JsonPropertyName("npv20")]
    public string Npv20 { get; set; }

    [JsonPropertyName("npv2")]
    public string Npv2 { get; set; }

    [JsonPropertyName("npv19")]
    public string Npv19 { get; set; }

    [JsonPropertyName("npv18")]
    public string Npv18 { get; set; }

    [JsonPropertyName("npv17")]
    public string Npv17 { get; set; }

    [JsonPropertyName("npv16")]
    public string Npv16 { get; set; }

    [JsonPropertyName("npv15")]
    public string Npv15 { get; set; }

    [JsonPropertyName("npv14")]
    public string Npv14 { get; set; }

    [JsonPropertyName("npv13")]
    public string Npv13 { get; set; }

    [JsonPropertyName("npv12")]
    public string Npv12 { get; set; }

    [JsonPropertyName("npv11")]
    public string Npv11 { get; set; }

    [JsonPropertyName("bnd")]
    public string Bnd { get; set; }

    [JsonPropertyName("npv10")]
    public string Npv10 { get; set; }

    [JsonPropertyName("dge")]
    public string Dge { get; set; }

    [JsonPropertyName("gav")]
    public string Gav { get; set; }

    [JsonPropertyName("npv25")]
    public string Npv25 { get; set; }

    [JsonPropertyName("npv26")]
    public string Npv26 { get; set; }

    [JsonPropertyName("npv28")]
    public string Npv28 { get; set; }

    [JsonPropertyName("tab_reports")]
    public string TabReports { get; set; }

    [JsonPropertyName("tab_my_scheduled_reports")]
    public string TabMyScheduledReports { get; set; }

    [JsonPropertyName("latest_report_type_portfolio")]
    public string LatestReportTypePortfolio { get; set; }

    [JsonPropertyName("latest_report_type_scheduled")]
    public string LatestReportTypeScheduled { get; set; }

    [JsonPropertyName("updated")]
    public string Updated { get; set; }

    [JsonPropertyName("default_range_text")]
    public string DefaultRangeText { get; set; }

    [JsonPropertyName("filter_title_portfolio")]
    public string FilterTitlePortfolio { get; set; }

    [JsonPropertyName("filter_title_general")]
    public string FilterTitleGeneral { get; set; }

    [JsonPropertyName("filter_title_scheduled")]
    public string FilterTitleScheduled { get; set; }

    [JsonPropertyName("select_period_tooltip")]
    public string SelectPeriodTooltip { get; set; }

    [JsonPropertyName("srr")]
    public string Srr { get; set; }

    [JsonPropertyName("aaf")]
    public string Aaf { get; set; }

    [JsonPropertyName("npv9")]
    public string Npv9 { get; set; }

    [JsonPropertyName("npv8")]
    public string Npv8 { get; set; }

    [JsonPropertyName("npv7")]
    public string Npv7 { get; set; }

    [JsonPropertyName("npv6")]
    public string Npv6 { get; set; }

    [JsonPropertyName("npv5")]
    public string Npv5 { get; set; }

    [JsonPropertyName("npv4")]
    public string Npv4 { get; set; }

    [JsonPropertyName("npv3")]
    public string Npv3 { get; set; }

    [JsonPropertyName("npv27")]
    public string Npv27 { get; set; }

    [JsonPropertyName("drr")]
    public string Drr { get; set; }

    [JsonPropertyName("drc")]
    public string Drc { get; set; }

    [JsonPropertyName("irm")]
    public string Irm { get; set; }

    [JsonPropertyName("brl")]
    public string Brl { get; set; }

    [JsonPropertyName("foc")]
    public string Foc { get; set; }

    [JsonPropertyName("ecb")]
    public string Ecb { get; set; }

    [JsonPropertyName("vot")]
    public string Vot { get; set; }

    [JsonPropertyName("sol")]
    public string Sol { get; set; }

    [JsonPropertyName("pls")]
    public string Pls { get; set; }

    [JsonPropertyName("ahs")]
    public string Ahs { get; set; }

    [JsonPropertyName("ahm")]
    public string Ahm { get; set; }

    [JsonPropertyName("filter_title_portfolio_auditor")]
    public string FilterTitlePortfolioAuditor { get; set; }

    [JsonPropertyName("selector_pre_title_auditor")]
    public string SelectorPreTitleAuditor { get; set; }
}

public class SessionInactive
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("content_1")]
    public string Content1 { get; set; }

    [JsonPropertyName("content_2")]
    public string Content2 { get; set; }

    [JsonPropertyName("ok_text")]
    public string OkText { get; set; }

    [JsonPropertyName("cancel_text")]
    public string CancelText { get; set; }
}

public class Support
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("tour_button")]
    public string TourButton { get; set; }

    [JsonPropertyName("tour_end")]
    public string TourEnd { get; set; }

    [JsonPropertyName("form_message_button")]
    public string FormMessageButton { get; set; }

    [JsonPropertyName("form_leave_message")]
    public string FormLeaveMessage { get; set; }

    [JsonPropertyName("form_title")]
    public string FormTitle { get; set; }

    [JsonPropertyName("form_description")]
    public string FormDescription { get; set; }

    [JsonPropertyName("form_full_name")]
    public string FormFullName { get; set; }

    [JsonPropertyName("form_email")]
    public string FormEmail { get; set; }

    [JsonPropertyName("form_subject")]
    public string FormSubject { get; set; }

    [JsonPropertyName("form_subject_select")]
    public string FormSubjectSelect { get; set; }

    [JsonPropertyName("form_subject_portfolio_request")]
    public string FormSubjectPortfolioRequest { get; set; }

    [JsonPropertyName("form_subject_reporting_query")]
    public string FormSubjectReportingQuery { get; set; }

    [JsonPropertyName("form_subject_technical_query")]
    public string FormSubjectTechnicalQuery { get; set; }

    [JsonPropertyName("form_subject_update_contact_details")]
    public string FormSubjectUpdateContactDetails { get; set; }

    [JsonPropertyName("form_subject_general_feedback_query")]
    public string FormSubjectGeneralFeedbackQuery { get; set; }

    [JsonPropertyName("form_comment")]
    public string FormComment { get; set; }

    [JsonPropertyName("form_comment_description")]
    public string FormCommentDescription { get; set; }

    [JsonPropertyName("form_submit")]
    public string FormSubmit { get; set; }

    [JsonPropertyName("form_cancel")]
    public string FormCancel { get; set; }

    [JsonPropertyName("form_required_fields")]
    public string FormRequiredFields { get; set; }

    [JsonPropertyName("form_subject_request_bridging_letter")]
    public string FormSubjectRequestBridgingLetter { get; set; }
}

public class TermsConditions
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("header")]
    public string Header { get; set; }

    [JsonPropertyName("summary_title")]
    public string SummaryTitle { get; set; }

    [JsonPropertyName("summary_content")]
    public string SummaryContent { get; set; }

    [JsonPropertyName("content")]
    public string Content { get; set; }
}

public class Unaudited
{
    [JsonPropertyName("error_data_title")]
    public string ErrorDataTitle { get; set; }

    [JsonPropertyName("error_data")]
    public string ErrorData { get; set; }

    [JsonPropertyName("table_col_security_alias")]
    public string TableColSecurityAlias { get; set; }

    [JsonPropertyName("table_col_underlying_ad")]
    public string TableColUnderlyingAd { get; set; }

    [JsonPropertyName("table_col_underlying_cusip")]
    public string TableColUnderlyingCusip { get; set; }

    [JsonPropertyName("table_col_underlying_isin")]
    public string TableColUnderlyingIsin { get; set; }

    [JsonPropertyName("table_col_settlement_date")]
    public string TableColSettlementDate { get; set; }

    [JsonPropertyName("table_col_san")]
    public string TableColSan { get; set; }

    [JsonPropertyName("table_col_tal")]
    public string TableColTal { get; set; }

    [JsonPropertyName("table_col_tab")]
    public string TableColTab { get; set; }

    [JsonPropertyName("table_col_pos")]
    public string TableColPos { get; set; }

    [JsonPropertyName("table_col_trade_price")]
    public string TableColTradePrice { get; set; }

    [JsonPropertyName("table_col_commission_l")]
    public string TableColCommissionL { get; set; }

    [JsonPropertyName("table_col_tcl")]
    public string TableColTcl { get; set; }

    [JsonPropertyName("table_col_tcb")]
    public string TableColTcb { get; set; }

    [JsonPropertyName("table_col_tcs")]
    public string TableColTcs { get; set; }

    [JsonPropertyName("table_col_ers_l")]
    public string TableColErsL { get; set; }

    [JsonPropertyName("table_col_ers_b")]
    public string TableColErsB { get; set; }

    [JsonPropertyName("table_col_consideration_l")]
    public string TableColConsiderationL { get; set; }

    [JsonPropertyName("table_col_ci")]
    public string TableColCi { get; set; }

    [JsonPropertyName("table_col_atr")]
    public string TableColAtr { get; set; }

    [JsonPropertyName("table_col_ailr")]
    public string TableColAilr { get; set; }

    [JsonPropertyName("table_col_aibc")]
    public string TableColAibc { get; set; }

    [JsonPropertyName("table_col_trans_code")]
    public string TableColTransCode { get; set; }

    [JsonPropertyName("table_col_underlying_sedol")]
    public string TableColUnderlyingSedol { get; set; }

    [JsonPropertyName("table_col_trade_reference")]
    public string TableColTradeReference { get; set; }

    [JsonPropertyName("table_col_trade_date")]
    public string TableColTradeDate { get; set; }

    [JsonPropertyName("table_col_coi")]
    public string TableColCoi { get; set; }

    [JsonPropertyName("table_col_buy_sell")]
    public string TableColBuySell { get; set; }

    [JsonPropertyName("ok_btn")]
    public string OkBtn { get; set; }

    [JsonPropertyName("select_btn")]
    public string SelectBtn { get; set; }

    [JsonPropertyName("select_portfolio")]
    public string SelectPortfolio { get; set; }

    [JsonPropertyName("select_period")]
    public string SelectPeriod { get; set; }

    [JsonPropertyName("select_period_note")]
    public string SelectPeriodNote { get; set; }

    [JsonPropertyName("opt_placeholder")]
    public string OptPlaceholder { get; set; }

    [JsonPropertyName("default_opt_description")]
    public string DefaultOptDescription { get; set; }

    [JsonPropertyName("option_position")]
    public string OptionPosition { get; set; }

    [JsonPropertyName("default_description")]
    public string DefaultDescription { get; set; }

    [JsonPropertyName("cia_description1")]
    public string CiaDescription1 { get; set; }

    [JsonPropertyName("cia_name")]
    public string CiaName { get; set; }

    [JsonPropertyName("cob_name")]
    public string CobName { get; set; }

    [JsonPropertyName("cob_description1")]
    public string CobDescription1 { get; set; }

    [JsonPropertyName("cob_description2")]
    public string CobDescription2 { get; set; }

    [JsonPropertyName("disclaimer")]
    public string Disclaimer { get; set; }

    [JsonPropertyName("cia_description2")]
    public string CiaDescription2 { get; set; }

    [JsonPropertyName("tab_title")]
    public string TabTitle { get; set; }

    [JsonPropertyName("option_settlement_date")]
    public string OptionSettlementDate { get; set; }

    [JsonPropertyName("option_trade_date")]
    public string OptionTradeDate { get; set; }

    [JsonPropertyName("option_full_view")]
    public string OptionFullView { get; set; }

    [JsonPropertyName("table_col_ac")]
    public string TableColAc { get; set; }

    [JsonPropertyName("table_col_cp")]
    public string TableColCp { get; set; }

    [JsonPropertyName("table_col_bv_l")]
    public string TableColBvL { get; set; }

    [JsonPropertyName("table_col_bv_b")]
    public string TableColBvB { get; set; }

    [JsonPropertyName("table_col_ai_l")]
    public string TableColAiL { get; set; }

    [JsonPropertyName("table_col_ai_b")]
    public string TableColAiB { get; set; }

    [JsonPropertyName("table_col_mv_l")]
    public string TableColMvL { get; set; }

    [JsonPropertyName("table_col_mv_b")]
    public string TableColMvB { get; set; }

    [JsonPropertyName("table_col_tmv_l")]
    public string TableColTmvL { get; set; }

    [JsonPropertyName("table_col_tmv_b")]
    public string TableColTmvB { get; set; }

    [JsonPropertyName("table_col_tr_l")]
    public string TableColTrL { get; set; }

    [JsonPropertyName("table_col_tr_b")]
    public string TableColTrB { get; set; }

    [JsonPropertyName("table_col_dr_l")]
    public string TableColDrL { get; set; }

    [JsonPropertyName("table_col_dr_b")]
    public string TableColDrB { get; set; }

    [JsonPropertyName("table_col_yield")]
    public string TableColYield { get; set; }

    [JsonPropertyName("number_of_lines")]
    public string NumberOfLines { get; set; }

    [JsonPropertyName("table_col_group")]
    public string TableColGroup { get; set; }

    [JsonPropertyName("table_col_client")]
    public string TableColClient { get; set; }

    [JsonPropertyName("table_col_client_name")]
    public string TableColClientName { get; set; }

    [JsonPropertyName("table_col_price")]
    public string TableColPrice { get; set; }

    [JsonPropertyName("table_col_qh")]
    public string TableColQh { get; set; }

    [JsonPropertyName("table_col_isin")]
    public string TableColIsin { get; set; }

    [JsonPropertyName("option_simple_view")]
    public string OptionSimpleView { get; set; }

    [JsonPropertyName("option_filter")]
    public string OptionFilter { get; set; }

    [JsonPropertyName("option_save_placeholder")]
    public string OptionSavePlaceholder { get; set; }

    [JsonPropertyName("option_save_all")]
    public string OptionSaveAll { get; set; }

    [JsonPropertyName("option_save_visable")]
    public string OptionSaveVisable { get; set; }

    [JsonPropertyName("option_lines")]
    public string OptionLines { get; set; }

    [JsonPropertyName("option_tip_collapse")]
    public string OptionTipCollapse { get; set; }

    [JsonPropertyName("option_tip_expand")]
    public string OptionTipExpand { get; set; }

    [JsonPropertyName("option_tip_reset")]
    public string OptionTipReset { get; set; }

    [JsonPropertyName("table_col_portfolio_id")]
    public string TableColPortfolioId { get; set; }

    [JsonPropertyName("table_col_portfolio_name")]
    public string TableColPortfolioName { get; set; }

    [JsonPropertyName("table_col_sim")]
    public string TableColSim { get; set; }

    [JsonPropertyName("table_col_cor")]
    public string TableColCor { get; set; }

    [JsonPropertyName("table_col_security_type")]
    public string TableColSecurityType { get; set; }

    [JsonPropertyName("table_col_asset_name")]
    public string TableColAssetName { get; set; }

    [JsonPropertyName("table_col_effective_date")]
    public string TableColEffectiveDate { get; set; }

    [JsonPropertyName("table_col_sedol")]
    public string TableColSedol { get; set; }

    [JsonPropertyName("table_col_cusip")]
    public string TableColCusip { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("ok")]
    public string Ok { get; set; }

    [JsonPropertyName("mandatory_field")]
    public string MandatoryField { get; set; }

    [JsonPropertyName("view_name_tip")]
    public string ViewNameTip { get; set; }

    [JsonPropertyName("max_20_characters")]
    public string Max20Characters { get; set; }

    [JsonPropertyName("please_select_another_option")]
    public string PleaseSelectAnotherOption { get; set; }

    [JsonPropertyName("no_data_selected")]
    public string NoDataSelected { get; set; }

    [JsonPropertyName("recently_saved")]
    public string RecentlySaved { get; set; }

    [JsonPropertyName("save_view_success")]
    public string SaveViewSuccess { get; set; }

    [JsonPropertyName("currently_viewing")]
    public string CurrentlyViewing { get; set; }

    [JsonPropertyName("saved_data_view_tab")]
    public string SavedDataViewTab { get; set; }

    [JsonPropertyName("portfolios_selected")]
    public string PortfoliosSelected { get; set; }

    [JsonPropertyName("default_title")]
    public string DefaultTitle { get; set; }

    [JsonPropertyName("reset")]
    public string Reset { get; set; }

    [JsonPropertyName("select")]
    public string Select { get; set; }

    [JsonPropertyName("select_all")]
    public string SelectAll { get; set; }

    [JsonPropertyName("clear_all")]
    public string ClearAll { get; set; }

    [JsonPropertyName("view_data")]
    public string ViewData { get; set; }

    [JsonPropertyName("saved_data_views")]
    public string SavedDataViews { get; set; }

    [JsonPropertyName("type_holdings")]
    public string TypeHoldings { get; set; }

    [JsonPropertyName("type_transactions")]
    public string TypeTransactions { get; set; }

    [JsonPropertyName("type_income")]
    public string TypeIncome { get; set; }

    [JsonPropertyName("type_accruals")]
    public string TypeAccruals { get; set; }

    [JsonPropertyName("no_saved_data_view")]
    public string NoSavedDataView { get; set; }

    [JsonPropertyName("option_viewing_options")]
    public string OptionViewingOptions { get; set; }

    [JsonPropertyName("option_select_data_points")]
    public string OptionSelectDataPoints { get; set; }

    [JsonPropertyName("option_filter_with_keyword")]
    public string OptionFilterWithKeyword { get; set; }

    [JsonPropertyName("option_save_view_for_future")]
    public string OptionSaveViewForFuture { get; set; }

    [JsonPropertyName("option_schedule_as_report")]
    public string OptionScheduleAsReport { get; set; }

    [JsonPropertyName("option_download_as_file")]
    public string OptionDownloadAsFile { get; set; }

    [JsonPropertyName("option_rows")]
    public string OptionRows { get; set; }

    [JsonPropertyName("option_tip_line")]
    public string OptionTipLine { get; set; }

    [JsonPropertyName("expand_all_columns")]
    public string ExpandAllColumns { get; set; }

    [JsonPropertyName("data_points")]
    public string DataPoints { get; set; }

    [JsonPropertyName("download_file_modal_format_title")]
    public string DownloadFileModalFormatTitle { get; set; }

    [JsonPropertyName("all")]
    public string All { get; set; }

    [JsonPropertyName("visible_data_points")]
    public string VisibleDataPoints { get; set; }

    [JsonPropertyName("form_submit")]
    public string FormSubmit { get; set; }

    [JsonPropertyName("form_cancel")]
    public string FormCancel { get; set; }

    [JsonPropertyName("settlement_date")]
    public string SettlementDate { get; set; }

    [JsonPropertyName("trade_date")]
    public string TradeDate { get; set; }

    [JsonPropertyName("remove")]
    public string Remove { get; set; }

    [JsonPropertyName("remove_modal_title")]
    public string RemoveModalTitle { get; set; }

    [JsonPropertyName("remove_modal_text")]
    public string RemoveModalText { get; set; }

    [JsonPropertyName("portfolio")]
    public string Portfolio { get; set; }

    [JsonPropertyName("data_type")]
    public string DataType { get; set; }

    [JsonPropertyName("date_saved")]
    public string DateSaved { get; set; }

    [JsonPropertyName("tutorial")]
    public string Tutorial { get; set; }

    [JsonPropertyName("select_type")]
    public string SelectType { get; set; }

    [JsonPropertyName("offbook_table_col_accountnumber")]
    public string OffbookTableColAccountnumber { get; set; }

    [JsonPropertyName("offbook_table_col_agentcategory")]
    public string OffbookTableColAgentcategory { get; set; }

    [JsonPropertyName("offbook_table_col_agentcode")]
    public string OffbookTableColAgentcode { get; set; }

    [JsonPropertyName("offbook_table_col_cdrclientname")]
    public string OffbookTableColCdrclientname { get; set; }

    [JsonPropertyName("offbook_table_col_fxrate")]
    public string OffbookTableColFxrate { get; set; }

    [JsonPropertyName("offbook_table_col_holdings")]
    public string OffbookTableColHoldings { get; set; }

    [JsonPropertyName("offbook_table_col_navprice")]
    public string OffbookTableColNavprice { get; set; }

    [JsonPropertyName("offbook_table_col_periodenddate")]
    public string OffbookTableColPeriodenddate { get; set; }

    [JsonPropertyName("offbook_table_col_periodstartdate")]
    public string OffbookTableColPeriodstartdate { get; set; }

    [JsonPropertyName("offbook_table_col_shareclass")]
    public string OffbookTableColShareclass { get; set; }

    [JsonPropertyName("offbook_table_col_shareclassname")]
    public string OffbookTableColShareclassname { get; set; }

    [JsonPropertyName("offbook_table_col_shareclasscurrency")]
    public string OffbookTableColShareclasscurrency { get; set; }

    [JsonPropertyName("offbook_table_col_totalunits")]
    public string OffbookTableColTotalunits { get; set; }

    [JsonPropertyName("offbook_table_col_amountinvestedgbp")]
    public string OffbookTableColAmountinvestedgbp { get; set; }

    [JsonPropertyName("offbook_table_col_clientorganisation")]
    public string OffbookTableColClientorganisation { get; set; }

    [JsonPropertyName("offbook_table_col_contractreference")]
    public string OffbookTableColContractreference { get; set; }

    [JsonPropertyName("offbook_table_col_transactiondirectiontypename")]
    public string OffbookTableColTransactiondirectiontypename { get; set; }

    [JsonPropertyName("offbook_table_col_transactiontypename")]
    public string OffbookTableColTransactiontypename { get; set; }

    [JsonPropertyName("offbook_table_col_numberofunits")]
    public string OffbookTableColNumberofunits { get; set; }

    [JsonPropertyName("offbook_table_col_pricedate")]
    public string OffbookTableColPricedate { get; set; }

    [JsonPropertyName("offbook_table_col_systemdate")]
    public string OffbookTableColSystemdate { get; set; }

    [JsonPropertyName("offbook_table_col_settlementdate")]
    public string OffbookTableColSettlementdate { get; set; }

    [JsonPropertyName("offbook_table_col_quartalreference")]
    public string OffbookTableColQuartalreference { get; set; }

    [JsonPropertyName("offbook_table_col_isinnumber")]
    public string OffbookTableColIsinnumber { get; set; }

    [JsonPropertyName("table_col_base_currency")]
    public string TableColBaseCurrency { get; set; }

    [JsonPropertyName("table_col_observation_point_type")]
    public string TableColObservationPointType { get; set; }

    [JsonPropertyName("table_col_accounting_source")]
    public string TableColAccountingSource { get; set; }
}

