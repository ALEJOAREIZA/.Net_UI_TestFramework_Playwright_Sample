public class ReportQuery
{
    [JsonPropertyName("category")]
    public string Category { get; set; }

    [JsonPropertyName("portfolioCodes")]
    public List<string> PortfolioCodes { get; set; }

    [JsonPropertyName("startDate")]
    public string StartDate { get; set; }

    [JsonPropertyName("endDate")]
    public string EndDate { get; set; }
}
