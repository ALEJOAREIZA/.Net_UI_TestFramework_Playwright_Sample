public class ScheduledReport
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("dayOfMonth")]
    public object DayOfMonth { get; set; }

    [JsonPropertyName("dayOfWeek")]
    public object DayOfWeek { get; set; }

    [JsonPropertyName("frequencyType")]
    public string FrequencyType { get; set; }

    [JsonPropertyName("holdingPositionType")]
    public string HoldingPositionType { get; set; }

    [JsonPropertyName("isNotificationEnabled")]
    public bool IsNotificationEnabled { get; set; }

    [JsonPropertyName("portfolioCodes")]
    public List<string> PortfolioCodes { get; set; }

    [JsonPropertyName("startAtUtc")]
    public DateTime StartAtUtc { get; set; }

    [JsonPropertyName("transactionDataType")]
    public string TransactionDataType { get; set; }

    [JsonPropertyName("transactionPeriodType")]
    public string TransactionPeriodType { get; set; }
}