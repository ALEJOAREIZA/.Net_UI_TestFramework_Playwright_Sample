public class Question
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("category")]
    public string Category { get; set; }

    [JsonPropertyName("questions")]
    public List<QuestionBinder> Questions { get; set; }
}
public class QuestionBinder
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("question")]
    public string QuestionProp { get; set; }

    [JsonPropertyName("answer")]
    public string Answer { get; set; }
}