public class Transaction
{
    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("transactions")]
    public List<TransactionData> Transactions { get; set; }
}

public class TransactionData
{
    [JsonPropertyName("accountingSource")]
    public string AccountingSource { get; set; }

    [JsonPropertyName("shortAssetName")]
    public string ShortAssetName { get; set; }

    [JsonPropertyName("simInvestmentType")]
    public string SimInvestmentType { get; set; }

    [JsonPropertyName("countryOfIssue")]
    public string CountryOfIssue { get; set; }

    [JsonPropertyName("securityType")]
    public string SecurityType { get; set; }

    [JsonPropertyName("buySell")]
    public string BuySell { get; set; }

    [JsonPropertyName("settlementDate")]
    public DateTime SettlementDate { get; set; }

    [JsonPropertyName("tradeDatetime")]
    public DateTime TradeDatetime { get; set; }

    [JsonPropertyName("tradeBaseCurrency")]
    public string TradeBaseCurrency { get; set; }

    [JsonPropertyName("tradeLocalCurrency")]
    public string TradeLocalCurrency { get; set; }

    [JsonPropertyName("tradeSettlementCurrency")]
    public string TradeSettlementCurrency { get; set; }

    [JsonPropertyName("totalAmountLocal")]
    public double TotalAmountLocal { get; set; }

    [JsonPropertyName("totalAmountBase")]
    public double TotalAmountBase { get; set; }

    [JsonPropertyName("exchRateSettlementToLocal")]
    public object ExchRateSettlementToLocal { get; set; }

    [JsonPropertyName("exchRateSettlementToBase")]
    public object ExchRateSettlementToBase { get; set; }

    [JsonPropertyName("parOrShares")]
    public double ParOrShares { get; set; }

    [JsonPropertyName("tradePrice")]
    public double TradePrice { get; set; }

    [JsonPropertyName("considerationLocal")]
    public double ConsiderationLocal { get; set; }

    [JsonPropertyName("commissionLocal")]
    public double CommissionLocal { get; set; }

    [JsonPropertyName("otherFeesLocal")]
    public double OtherFeesLocal { get; set; }

    [JsonPropertyName("cancellationIndicator")]
    public string CancellationIndicator { get; set; }

    [JsonPropertyName("transCode")]
    public string TransCode { get; set; }

    [JsonPropertyName("sedol")]
    public string Sedol { get; set; }

    [JsonPropertyName("isin")]
    public string Isin { get; set; }

    [JsonPropertyName("client")]
    public string Client { get; set; }

    [JsonPropertyName("portfolioId")]
    public string PortfolioId { get; set; }

    [JsonPropertyName("tradeReference")]
    public string TradeReference { get; set; }

    [JsonPropertyName("altTradeReference")]
    public string AltTradeReference { get; set; }

    [JsonPropertyName("accruedInterestBase")]
    public double AccruedInterestBase { get; set; }

    [JsonPropertyName("accrIntLocalCurrency")]
    public double AccrIntLocalCurrency { get; set; }

    [JsonPropertyName("countryOfRisk")]
    public string CountryOfRisk { get; set; }

    [JsonPropertyName("cusip")]
    public object Cusip { get; set; }
}