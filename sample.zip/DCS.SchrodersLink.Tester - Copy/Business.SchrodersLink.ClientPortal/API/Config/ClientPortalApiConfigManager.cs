public static class ClientPortalApiConfigManager
{
    public static ClientPortalApiConfig GetPublicSettings()
    {
        var fileName = $"API/ClientPortalPublicApi.Config.json";
        return new ConfigurationManager<ClientPortalApiConfig>()
            .WithConfigFiles(fileName)
            .Get();
    }
    public static ClientPortalApiConfig GetInternalSettings()
    {
        var fileName = $"API/ClientPortalInternalApi.Config.json";
        return new ConfigurationManager<ClientPortalApiConfig>()
            .WithConfigFiles(fileName)
            .Get();
    }
}
