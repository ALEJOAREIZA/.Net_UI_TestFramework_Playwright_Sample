public class ClientPortalApiConfig
{
    public APIEnvConfig DIT { get; set; }
    public APIEnvConfig UAT { get; set; }
}