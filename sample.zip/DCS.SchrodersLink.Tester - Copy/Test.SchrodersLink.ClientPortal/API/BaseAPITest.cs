public class BaseAPITest
{
    private readonly APITracingManager trace = APITracingManager.GetInstance();
    private string testName;
    private APIEnvConfig clientPortalPublicApiEnvConfig;
    private APIEnvConfig clientPortalInternalApiEnvConfig;
    [SetUp]
    public void SetUp()
    {
        testName = TestContext.CurrentContext.Test.MethodName;
        var testEnv = TestContext.Parameters["testEnvironment"];
        trace.TracingDirPath = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "API", "TraceData", $"{DateTime.Now:yyMMdd-HHmmss}_{TestContext.CurrentContext.Test.MethodName}");
        clientPortalPublicApiEnvConfig = testEnv.ToUpper() switch
        {
            nameof(TestEnvironment.DIT) => ClientPortalApiConfigManager.GetPublicSettings().DIT,
            nameof(TestEnvironment.UAT) => ClientPortalApiConfigManager.GetPublicSettings().UAT,
            _ => throw new InvalidOperationException($"Test Environment does not meet Environment criteria")
        };
        clientPortalInternalApiEnvConfig = testEnv.ToUpper() switch
        {
            nameof(TestEnvironment.DIT) => ClientPortalApiConfigManager.GetInternalSettings().DIT,
            nameof(TestEnvironment.UAT) => ClientPortalApiConfigManager.GetInternalSettings().UAT,
            _ => throw new InvalidOperationException($"Test Environment does not meet Environment criteria")
        };
        trace.Write($"===== {testName} has started =====");
    }
    public ClientPortalAPI ClientPortalPublic => new ClientPortalAPI(clientPortalPublicApiEnvConfig);
    public ClientPortalAPI ClientPortalInternal => new ClientPortalAPI(clientPortalInternalApiEnvConfig);
    [TearDown]
    public void TearDown()
    {
        var testResult = TestContext.CurrentContext.Result.Outcome.Status;
        trace.Write($"===== {testName} has finished =====");
        trace.Write($"Test {testResult} {TestContext.CurrentContext.Result.Message}");
        TestContext.AddTestAttachment(trace.TracingFilePath);
        // ADOTestCaseService.AddTestSteps(QETestContext.CurrentContext.TestCaseId, QETestContext.CurrentContext.TestCaseSteps).Wait();
    }
}