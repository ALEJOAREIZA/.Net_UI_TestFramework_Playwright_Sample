public class GetAUMDetailsByPortfolio : BaseAPITest
{
    [Test, TestCaseId("984682")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetAUMDetailsByPortfolioDataProvider))]
    public async Task GetAUMDetailsByPortfolioTest(GetAUMDetailsByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetAUMDetailsByPortfolio(data.PortfolioCode);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.AUMMarketValue.Should().NotBe(null);
        }
    }
}