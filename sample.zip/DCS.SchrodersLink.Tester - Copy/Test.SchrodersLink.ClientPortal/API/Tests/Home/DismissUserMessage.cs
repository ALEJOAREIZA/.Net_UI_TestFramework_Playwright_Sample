public class DismissUserMessage : BaseAPITest
{
    [Test, TestCaseId("983160")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(DismissUserMessageDataProvider))]
    [Ignore("Ignore until undismiss sql procedure is implemented")]
    public async Task DismissUserMessageTest(DismissUserMessageTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).DismissUserMessage(data.UserMessageId);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}