public class GetUserMessages : BaseAPITest
{
    [Test, TestCaseId("985593")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetUserMessagesDataProvider))]
    public async Task GetUserMessagesTest(GetUserMessagesTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetUserMessages();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(userMessage => userMessage.Should().NotBeNull());
            response.Content.ForEach(userMessage => userMessage.Id.Should().NotBe(null));
            response.Content.ForEach(userMessage => userMessage.Title.Should().NotBeNullOrEmpty());
            response.Content.ForEach(userMessage => userMessage.Message.Should().NotBeNullOrEmpty());
        }
    }
}