public class GetMyClientServiceTeamByPortfolio : BaseAPITest
{
    [Test, TestCaseId("983162")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetMyClientServiceTeamByPortfolioDataProvider))]
    public async Task GetMyClientServiceTeamByPortfolioTest(GetMyClientServiceTeamByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetMyClientServiceTeamByPortfolio(data.PortfolioCodes);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.PortfolioContactInfos.Should().NotBeNullOrEmpty();
        }
    }
}