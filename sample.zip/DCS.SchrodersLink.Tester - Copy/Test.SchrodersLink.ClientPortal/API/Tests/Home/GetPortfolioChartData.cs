public class GetPortfolioChartDataTest : BaseAPITest
{
    [Test, TestCaseId("1180873")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetPortfolioChartDataTestDataProvider))]
    public async Task GetPortfolioChartDataTestTest(GetPortfolioChartDataTestTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetPortfolioChartData(data.PortfolioCode, data.StartDate, data.EndDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Chart.ForEach(portfolio => portfolio.Data.ForEach(portfolioData => portfolioData.Should().NotBeNullOrEmpty()));
            response.Content.Label.Data.ForEach(portfolioData => portfolioData.FundingLevel.Should().NotBe(null));
        }
    }
}