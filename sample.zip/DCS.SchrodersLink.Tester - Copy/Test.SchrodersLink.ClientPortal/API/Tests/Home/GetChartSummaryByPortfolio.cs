public class GetChartSummaryByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1180867")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetChartSummaryByPortfolioDataProvider))]
    public async Task GetChartSummaryByPortfolioTest(GetChartSummaryByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetChartSummaryByPortfolio(data.PortfolioCode);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.FundingLevel.Should().NotBe(null);
        }
    }
}