public class GetLatestNPVReports : BaseAPITest
{
    [Test, TestCaseId("1180868")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetLatestNPVReportsDataProvider))]
    public async Task GetLatestNPVReportsTest(GetLatestNPVReportsTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetLatestNPVReports();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Reports.Should().NotBeNull();
        }
    }
}