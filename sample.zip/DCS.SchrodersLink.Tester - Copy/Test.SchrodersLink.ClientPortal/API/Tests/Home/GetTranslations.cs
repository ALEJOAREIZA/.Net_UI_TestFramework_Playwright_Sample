public class GetTranslations : BaseAPITest
{
    [Test, TestCaseId("1180876")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetTranslationsDataProvider))]
    public async Task GetTranslationsTest(GetTranslationsTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetTranslations(data.Language);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
        }
    }
}