public class GetPortfoliosAssociatedToUser : BaseAPITest
{
    [Test, TestCaseId("1180874")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetPortfoliosAssociatedToUserDataProvider))]
    public async Task GetPortfoliosAssociatedToUserTest(GetPortfoliosAssociatedToUserTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetPortfoliosAssociatedToUser();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(portfolio => portfolio.AumReportingCurrency.Should().NotBeNullOrEmpty());
        }
    }
}