public class GetNewUserTour : BaseAPITest
{
    [Test, TestCaseId("1180872")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetNewUserTourDataProvider))]
    public async Task GetNewUserTourTest(GetNewUserTourTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetNewUserTour();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
            response.Content.ForEach(userTour => userTour.Description.Should().NotBeNullOrEmpty());
        }
    }
}