public class GetWhatsNew : BaseAPITest
{
    [Test, TestCaseId("1180877")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetWhatsNewDataProvider))]
    public async Task GetWhatsNewTest(GetWhatsNewTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetWhatsNew();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
            response.Content.ForEach(news => news.Title.Should().NotBeNullOrEmpty());
        }
    }
}