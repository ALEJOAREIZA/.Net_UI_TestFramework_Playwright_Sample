public class GetRssInsights : BaseAPITest
{
    [Test, TestCaseId("1180875")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetRssInsightsDataProvider))]
    public async Task GetRssInsightsTest(GetRssInsightsTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetRssInsights();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.FeedList.ForEach(insight => insight.ImageUrl.Should().NotBeNullOrEmpty());
        }
    }
}