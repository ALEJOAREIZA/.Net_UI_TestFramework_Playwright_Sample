public class SendEvent : BaseAPITest
{
    [Test, TestCaseId("1180912")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendEventDataProvider))]
    public async Task SendEventTest(SendEventTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).SendEvent(data.LogEvent);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}