public class CRUDdataView : BaseAPITest
{
    [Test, TestCaseId("1181248")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(CRUDdataViewDataProvider))]
    public async Task CRUDdataViewTest(CRUDdataViewTestData data)
    {
        var createDataViewResponse = await ClientPortalPublic.Authenticate(data.Credentials).CreateDataView(data.CreateDataView);
        createDataViewResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        var getDataViewsResponse = await ClientPortalPublic.Authenticate(data.Credentials).GetAllDataViews();
        using (new AssertionScope())
        {
            getDataViewsResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            getDataViewsResponse.Content.Should().NotBeNullOrEmpty();
            getDataViewsResponse.Content.Should().HaveCountGreaterThan(0);
        }
        var dataViewId = data.UpdateDataView.Id = getDataViewsResponse.Content.Last().Id;

        var deleteDataViewResponse = await ClientPortalPublic.Authenticate(data.Credentials).DeleteDataView(dataViewId.ToString());
        deleteDataViewResponse.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}