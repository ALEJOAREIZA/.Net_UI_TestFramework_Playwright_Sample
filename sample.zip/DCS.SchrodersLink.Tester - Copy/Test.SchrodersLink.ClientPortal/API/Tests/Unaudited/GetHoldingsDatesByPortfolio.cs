public class GetHoldingsDatesByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1181253")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetHoldingsDatesByPortfolioDataProvider))]
    public async Task GetHoldingsDatesByPortfolioTest(GetHoldingsDatesByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetHoldingsDatesByPortfolio(data.PortfolioCode);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
        }
    }
}