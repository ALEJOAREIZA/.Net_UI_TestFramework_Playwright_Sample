public class GetHoldingsByOffbookPortfolio : BaseAPITest
{
    [Test, TestCaseId("1181252")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetHoldingsByOffbookPortfolioDataProvider))]
    public async Task GetHoldingsByOffbookPortfolioTest(GetHoldingsByOffbookPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetHoldingsByOffbookPortfolio(data.PortfolioCode, data.HoldingDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Type.Should().Be("off-book");
        }
    }
}