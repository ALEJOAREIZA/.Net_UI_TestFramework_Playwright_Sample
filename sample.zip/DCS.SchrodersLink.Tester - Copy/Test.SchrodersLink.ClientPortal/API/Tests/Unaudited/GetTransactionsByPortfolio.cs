public class GetTransactionsByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1181257")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetTransactionsByPortfolioDataProvider))]
    public async Task GetTransactionsByPortfolioTest(GetTransactionsByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetTransactionsByPortfolio(data.PortfolioCode, data.DateType, data.TransactionsDate.FromDate, data.TransactionsDate.ToDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Type.Should().Be("on-book");
        }
    }
}