public class GetUnauditedTutorial : BaseAPITest
{
    [Test, TestCaseId("1181258")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetUnauditedTutorialDataProvider))]
    public async Task GetUnauditedTutorialTest(GetUnauditedTutorialTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetUnauditedTutorial();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
            response.Content.ForEach(tutorial => tutorial.ImageUrl.Should().NotBeNullOrEmpty());
            response.Content.ForEach(tutorial => tutorial.Description.Should().NotBeNullOrEmpty());
        }
    }
}