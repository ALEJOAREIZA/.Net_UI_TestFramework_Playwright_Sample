public class GetTransactionsByOffbookPortfolio : BaseAPITest
{
    [Test, TestCaseId("1181255")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetTransactionsByOffbookPortfolioDataProvider))]
    public async Task GetTransactionsByOffbookPortfolioTest(GetTransactionsByOffbookPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetTransactionsByOffbookPortfolio(data.PortfolioCode, data.DateType, data.TransactionsDate.FromDate, data.TransactionsDate.ToDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Type.Should().Be("off-book");
            response.Content.Transactions.Should().NotBeNull();
        }
    }
}