public class GetIncomeByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1181254")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetIncomeByPortfolioDataProvider))]
    public async Task GetIncomeByPortfolioTest(GetIncomeByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetIncomeByPortfolio(data.PortfolioCode, data.DateType, data.TransactionsDate.FromDate, data.TransactionsDate.ToDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(item => item.Should().NotBeNull());
        }
    }
}