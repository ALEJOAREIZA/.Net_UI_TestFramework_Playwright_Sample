public class GetHoldingsByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1180847")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetHoldingsByPortfolioDataProvider))]
    public async Task GetHoldingsByPortfolioTest(GetHoldingsByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetHoldingsByPortfolio(data.PortfolioCode, data.HoldingDate);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Type.Should().Be("on-book");
            response.Content.Holdings.Should().BeInAscendingOrder(x => x.ClientName);
        }
    }
}