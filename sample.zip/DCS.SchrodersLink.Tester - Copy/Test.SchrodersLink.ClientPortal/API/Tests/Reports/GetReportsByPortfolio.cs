public class GetReportsByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1181223")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetReportsByPortfolioDataProvider))]
    public async Task GetReportsByPortfolioTest(GetReportsByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetReportsByPortfolio(data.ReportQuery);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Reports.ForEach(item => item.Should().NotBeNull());
        }
    }
}