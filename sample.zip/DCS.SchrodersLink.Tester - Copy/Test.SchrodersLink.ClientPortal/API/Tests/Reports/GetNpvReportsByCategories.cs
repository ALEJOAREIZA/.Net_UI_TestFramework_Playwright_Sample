public class GetNpvReportsByCategories : BaseAPITest
{
    [Test, TestCaseId("1017827")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetNpvReportsByCategoriesDataProvider))]
    public async Task GetNpvReportsByCategoriesTest(GetNpvReportsByCategoriesTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetNpvReportsByCategories(data.NpvReportSearch);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(item => item.Reports.Should().NotBeNullOrEmpty());
        }
    }
}