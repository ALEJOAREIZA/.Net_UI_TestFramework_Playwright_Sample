public class GetNpvReportCategories : BaseAPITest
{
    [Test, TestCaseId("1181222")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetNpvReportCategoriesDataProvider))]
    public async Task GetNpvReportCategoriesTest(GetNpvReportCategoriesTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetNpvReportCategories();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(item => item.Category.Should().NotBeNullOrEmpty());
        }
    }
}