public class GetLatestReportsByPortfolio : BaseAPITest
{
    [Test, TestCaseId("955326")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetLatestReportsByPortfolioDataProvider))]
    public async Task GetLatestReportsByPortfolioTest(GetLatestReportsByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetLatestReportsByPortfolio(data.PortfolioCode);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.PortfolioReports.Reports.ForEach(item => item.Should().NotBeNull());
            response.Content.ScheduledReports.Reports.ForEach(item => item.Should().NotBeNull());
        }
    }
}