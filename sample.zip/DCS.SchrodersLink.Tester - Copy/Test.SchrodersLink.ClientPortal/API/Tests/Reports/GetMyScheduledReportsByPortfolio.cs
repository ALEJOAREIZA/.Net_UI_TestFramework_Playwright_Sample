public class GetMyScheduledReportsByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1181220")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetMyScheduledReportsByPortfolioDataProvider))]
    public async Task GetMyScheduledReportsByPortfolioTest(GetMyScheduledReportsByPortfolioTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetReportsByPortfolio(data.ReportQuery);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Reports.ForEach(item => item.Should().NotBeNull());
        }
    }
}