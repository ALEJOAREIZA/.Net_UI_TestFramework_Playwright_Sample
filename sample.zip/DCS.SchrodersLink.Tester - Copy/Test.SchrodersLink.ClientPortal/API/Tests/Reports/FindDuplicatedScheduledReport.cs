public class FindDuplicatedScheduledReport : BaseAPITest
{
    [Test, TestCaseId("911488")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(FindDuplicatedScheduledReportDataProvider))]
    public async Task FindDuplicatedScheduledReportTest(FindDuplicatedScheduledReportTestData data)
    {
        var createScheduledReportResponse = await ClientPortalPublic.Authenticate(data.Credentials).FindDuplicatedScheduledReport(data.ScheduledReport);
        createScheduledReportResponse.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }
}