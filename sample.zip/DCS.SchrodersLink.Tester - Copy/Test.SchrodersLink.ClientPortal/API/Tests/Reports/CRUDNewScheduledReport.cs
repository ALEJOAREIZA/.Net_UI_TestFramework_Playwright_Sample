public class CRUDNewScheduledReport : BaseAPITest
{
    [Test, TestCaseId("1181214")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(CRUDNewScheduledReportDataProvider))]
    public async Task CRUDNewScheduledReportTest(CRUDNewScheduledReportTestData data)
    {
        var createScheduledReportResponse = await ClientPortalPublic.Authenticate(data.Credentials).CreateScheduledReport(data.ScheduledReport);
        using (new AssertionScope())
        {
            createScheduledReportResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            createScheduledReportResponse.Content.Should().NotBeNullOrEmpty();
        }

        var getScheduledReportResponse = await ClientPortalPublic.Authenticate(data.Credentials).GetScheduledReport(createScheduledReportResponse.Content);
        using (new AssertionScope())
        {
            getScheduledReportResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            getScheduledReportResponse.Content.Should().NotBeNull();
            getScheduledReportResponse.Content.Id.Should().BePositive();
            getScheduledReportResponse.Content.Should().BeOfType<ScheduledReport>();
        }

        var updateScheduledReportResponse = await ClientPortalPublic.Authenticate(data.Credentials).UpdateScheduledReport(createScheduledReportResponse.Content, data.UpdateScheduledReport);
        updateScheduledReportResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        var deleteScheduledReportResponse = await ClientPortalPublic.Authenticate(data.Credentials).DeleteScheduledReport(createScheduledReportResponse.Content);
        deleteScheduledReportResponse.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}