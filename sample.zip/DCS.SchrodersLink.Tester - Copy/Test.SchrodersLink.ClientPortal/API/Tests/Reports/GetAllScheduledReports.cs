public class GetAllScheduledReports : BaseAPITest
{
    [Test, TestCaseId("1240874")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetAllScheduledReportsDataProvider))]
    public async Task GetAllScheduledReportsTest(GetAllScheduledReportsTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetAllScheduledReports();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
        }
    }
}