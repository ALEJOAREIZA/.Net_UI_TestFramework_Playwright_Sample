public class SendResetPasswordNotification : BaseAPITest
{
    [Test, TestCaseId("1058744")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendResetPasswordNotificationDataProvider))]
    public async Task SendResetPasswordNotificationTest(SendResetPasswordNotificationTestData data)
    {
        var response = await ClientPortalPublic.Authenticate().SendResetPasswordNotification(data.User);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}