public class CheckAPIStatus : BaseAPITest
{
    [Test, TestCaseId("1058743")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    public async Task CheckAPIStatusTest()
    {
        var response = await ClientPortalPublic.Authenticate().CheckAPIStatus();
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}