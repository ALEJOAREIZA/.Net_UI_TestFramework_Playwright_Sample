public class SendRequestAccessMessage : BaseAPITest
{
    [Test, TestCaseId("1180913")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendRequestAccessMessageDataProvider))]
    public async Task SendRequestAccessMessageTest(SendRequestAccessMessageTestData data)
    {
        var response = await ClientPortalPublic.Authenticate().SendRequestAccessMessage(data.RequestAccessMessage);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}