public class SendHelpMessage : BaseAPITest
{
    [Test, TestCaseId("1178564")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendHelpMessageDataProvider))]
    public async Task SendHelpMessageTest(SendHelpMessageTestData data)
    {
        var response = await ClientPortalPublic.Authenticate().SendHelpMessage(data.HelpMessage);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}