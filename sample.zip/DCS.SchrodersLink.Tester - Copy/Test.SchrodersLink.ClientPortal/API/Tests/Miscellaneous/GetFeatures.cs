public class GetFeatures : BaseAPITest
{
    [Test, TestCaseId("1180915")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetFeatureDataProvider))]
    public async Task GetFeaturesTest(GetFeatureTestData data)
    {
        var response = await ClientPortalInternal.Authenticate(data.Credentials).GetFeatures();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
        }
    }
}
