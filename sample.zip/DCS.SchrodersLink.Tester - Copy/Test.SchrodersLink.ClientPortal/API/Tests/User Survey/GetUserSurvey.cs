public class GetUserSurvey : BaseAPITest
{
    [Test, TestCaseId("1181243")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetUserSurveyDataProvider))]
    public async Task GetUserSurveyTest(GetUserSurveyTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetUserSurvey();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Email.ToLower().Should().Be(data.Credentials.Username.ToLowerInvariant());
        }
    }
}