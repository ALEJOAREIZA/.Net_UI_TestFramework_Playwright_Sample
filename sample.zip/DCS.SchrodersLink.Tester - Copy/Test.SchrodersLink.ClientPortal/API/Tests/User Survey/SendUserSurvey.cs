public class SendUserSurvey : BaseAPITest
{
    [Test, TestCaseId("1181245")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendUserSurveyDataProvider))]
    public async Task SendUserSurveyTest(SendUserSurveyTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).SendUserSurvey(data.UserSurvey);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}