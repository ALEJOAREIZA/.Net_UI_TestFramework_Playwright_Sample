public class ChangePassword : BaseAPITest
{
    [Test, TestCaseId("1180916")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(ChangePasswordDataProvider))]
    public async Task ChangePasswordTest(ChangePasswordTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).ChangePassword(data.Password);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}