public class GetNotificationSettings : BaseAPITest
{
    [Test, TestCaseId("1180917")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetNotificationSettingsDataProvider))]
    public async Task GetNotificationSettingsTest(GetNotificationSettingsTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetNotificationSettings();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Reports.ForEach(item => item.Description.Should().NotBeNullOrEmpty());
        }
    }
}