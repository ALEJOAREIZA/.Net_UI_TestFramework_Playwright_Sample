public class UpdateNotificationSettings : BaseAPITest
{
    [Test, TestCaseId("1180919")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(UpdateNotificationSettingsDataProvider))]
    public async Task UpdateNotificationSettingsTest(UpdateNotificationSettingsTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).UpdateNotificationSettings(data.NotificationSettings);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}