public class GetAuditorReportsByPortfolio : BaseAPITest
{
    [Test, TestCaseId("1180858")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetAuditorReportsByPortfolioDataProvider))]
    public async Task GetAuditorReportsByPortfolioTest(GetAuditorReportsByPortfolioTestData data)
    {
        var response = await ClientPortalInternal.Authenticate(data.Credentials).GetAuditorReportsByPortfolio(data.PortfolioCode);
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(report => report.Portfolios.First().GroupCode.Should().Be(data.PortfolioCode));
        }
    }
}