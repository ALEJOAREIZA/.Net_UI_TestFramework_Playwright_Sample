public class GetAuditorPortfolios : BaseAPITest
{
    [Test, TestCaseId("1180855")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetAuditorPortfoliosDataProvider))]
    public async Task GetAuditorPortfoliosTest(GetAuditorPortfoliosTestData data)
    {
        var response = await ClientPortalInternal.Authenticate(data.Credentials).GetAuditorPortfolios();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.Should().HaveCountGreaterThan(0);
        }
    }
}
