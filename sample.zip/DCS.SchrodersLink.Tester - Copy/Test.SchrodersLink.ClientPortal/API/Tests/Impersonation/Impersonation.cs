public class Impersonation : BaseAPITest
{
    [Test, TestCaseId("1180908")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(ImpersonationDataProvider))]
    public async Task ImpersonationTest(ImpersonationTestData data)
    {
        var allImpersonateUsers = await ClientPortalPublic.Authenticate(data.Credentials).GetAllImpersonateUsers();
        var impersonateUser = allImpersonateUsers.Content.Find(user => user.Email == data.User.Email);
        var impersonationResponse = await ClientPortalPublic.Authenticate(data.Credentials).ImpersonateUser(impersonateUser.Id);
        using (new AssertionScope())
        {
            impersonationResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            impersonationResponse.Content.Should().NotBeNull();
            impersonationResponse.Content.AccessToken.Should().NotBeNullOrEmpty();
        }
        var impersonateAccessToken = impersonationResponse.Content.AccessToken;

        var stopimpersonationResponse = await ClientPortalPublic.Authenticate().StopImpersonation($"Bearer {impersonateAccessToken}");
        using (new AssertionScope())
        {
            stopimpersonationResponse.StatusCode.Should().Be(HttpStatusCode.OK);
            stopimpersonationResponse.Content.Should().NotBeNull();
        }
    }
}