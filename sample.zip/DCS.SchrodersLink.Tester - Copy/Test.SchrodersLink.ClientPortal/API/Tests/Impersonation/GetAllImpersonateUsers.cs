public class GetAllImpersonateUsers : BaseAPITest
{
    [Test, TestCaseId("1124371")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetAllImpersonateUsersDataProvider))]
    public async Task GetAllImpersonateUsersTest(GetAllImpersonateUsersTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetAllImpersonateUsers();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNullOrEmpty();
            response.Content.Should().HaveCountGreaterThan(0);
        }
    }
}