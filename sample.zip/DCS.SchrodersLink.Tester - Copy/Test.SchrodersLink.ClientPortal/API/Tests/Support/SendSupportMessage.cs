public class SendSupportMessage : BaseAPITest
{
    [Test, TestCaseId("1181238")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendSupportMessageDataProvider))]
    public async Task SendSupportMessageTest(SendSupportMessageTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).SendSupportMessage(data.SupportMessage);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}
