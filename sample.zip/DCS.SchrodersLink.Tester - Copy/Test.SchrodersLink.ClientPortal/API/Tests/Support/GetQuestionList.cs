public class GetQuestionList : BaseAPITest
{
    [Test, TestCaseId("1181231")]
    [TestType(TestCaseType.Regression), TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(GetQuestionListDataProvider))]
    public async Task GetQuestionListTest(GetQuestionListTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).GetQuestionList();
        using (new AssertionScope())
        {
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            response.Content.Should().NotBeNull();
            response.Content.ForEach(item => item.Questions.ForEach(question => question.Answer.Should().NotBeNullOrEmpty()));
        }
    }
}