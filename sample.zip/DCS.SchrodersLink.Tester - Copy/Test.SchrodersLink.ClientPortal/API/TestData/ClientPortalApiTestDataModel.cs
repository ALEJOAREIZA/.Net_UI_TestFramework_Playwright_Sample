public class GetAccessTokenTestData
{
    public Credentials Credentials { get; set; }
}
public class GetAllPortfoliosFromCurrentUserTestData
{
    public Credentials Credentials { get; set; }
}
public class GetMyClientServiceTeamByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public List<string> PortfolioCodes { get; set; }
}
public class GetLatestReportsByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public PortfolioCode PortfolioCode { get; set; }
}
public class GetAUMDetailsByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
}
public class GetPortfoliosAssociatedToUserTestData
{
    public Credentials Credentials { get; set; }
}
public class SendResetPasswordNotificationTestData
{
    public User User { get; set; }
}
public class GetMyClientServiceTeamTestData
{
    public Credentials Credentials { get; set; }
}
public class GetLatestNPVReportsTestData
{
    public Credentials Credentials { get; set; }
}
public class GetChartSummaryByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
}
public class GetPortfolioChartDataTestTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
    public string StartDate { get; set; }
    public string EndDate { get; set; }
}
public class GetRssInsightsTestData
{
    public Credentials Credentials { get; set; }
}
public class GetWhatsNewTestData
{
    public Credentials Credentials { get; set; }
}
public class GetNewUserTourTestData
{
    public Credentials Credentials { get; set; }
}
public class GetUnauditedTutorialTestData
{
    public Credentials Credentials { get; set; }
}
public class GetAuditorPortfoliosTestData
{
    public Credentials Credentials { get; set; }
}
public class GetAuditorReportsByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
}
public class GetTranslationsTestData
{
    public Credentials Credentials { get; set; }
    public string Language { get; set; }
}
public class GetQuestionListTestData
{
    public Credentials Credentials { get; set; }
}
public class SendSupportMessageTestData
{
    public Credentials Credentials { get; set; }
    public SupportMessage SupportMessage { get; set; }
}
public class GetNotificationSettingsTestData
{
    public Credentials Credentials { get; set; }
}
public class UpdateNotificationSettingsTestData
{
    public Credentials Credentials { get; set; }
    public NotificationSettings NotificationSettings { get; set; }
}
public class ChangePasswordTestData
{
    public Credentials Credentials { get; set; }
    public Password Password { get; set; }
}
public class SendEventTestData
{
    public Credentials Credentials { get; set; }
    public LogEvent LogEvent { get; set; }
}
public class SendUserSurveyTestData
{
    public Credentials Credentials { get; set; }
    public UserSurveyItem UserSurvey { get; set; }
}
public class GetUserSurveyTestData
{
    public Credentials Credentials { get; set; }
    public UserSurvey UserSurvey { get; set; }
}
public class ImpersonationTestData
{
    public Credentials Credentials { get; set; }
    public User User { get; set; }
}
public class GetAllImpersonateUsersTestData
{
    public Credentials Credentials { get; set; }
}
public class GetHoldingsDatesByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
}
public class GetHoldingsByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
    public string HoldingDate { get; set; }
}
public class GetHoldingsByOffbookPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
    public string HoldingDate { get; set; }
}
public class GetTransactionsByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
    public string DateType { get; set; }
    public PortfolioDate TransactionsDate { get; set; }
}
public class GetIncomeByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
    public string DateType { get; set; }
    public PortfolioDate TransactionsDate { get; set; }
}
public class GetTransactionsByOffbookPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public string PortfolioCode { get; set; }
    public string DateType { get; set; }
    public PortfolioDate TransactionsDate { get; set; }
}
public class CRUDdataViewTestData
{
    public Credentials Credentials { get; set; }
    public DataView CreateDataView { get; set; }
    public DataView UpdateDataView { get; set; }
}
public class GetFeatureTestData
{
    public Credentials Credentials { get; set; }
}
public class GetReportsByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public ReportQuery ReportQuery { get; set; }
}
public class GetMyScheduledReportsByPortfolioTestData
{
    public Credentials Credentials { get; set; }
    public ReportQuery ReportQuery { get; set; }
}
public class CRUDNewScheduledReportTestData
{
    public Credentials Credentials { get; set; }
    public ScheduledReport ScheduledReport { get; set; }
    public ScheduledReport UpdateScheduledReport { get; set; }
}
public class GetNpvReportCategoriesTestData
{
    public Credentials Credentials { get; set; }
}
public class GetNpvReportsByCategoriesTestData
{
    public Credentials Credentials { get; set; }
    public NpvReportSearch NpvReportSearch { get; set; }
}
public class SendHelpMessageTestData
{
    public Credentials Credentials { get; set; }
    public HelpMessage HelpMessage { get; set; }
}
public class SendRequestAccessMessageTestData
{
    public Credentials Credentials { get; set; }
    public RequestAccessMessage RequestAccessMessage { get; set; }
}
public class GetAllScheduledReportsTestData
{
    public Credentials Credentials { get; set; }
}
public class FindDuplicatedScheduledReportTestData
{
    public Credentials Credentials { get; set; }
    public ScheduledReport ScheduledReport { get; set; }
}
public class GetUserMessagesTestData
{
    public Credentials Credentials { get; set; }
}
public class DismissUserMessageTestData
{
    public Credentials Credentials { get; set; }
    public string UserMessageId { get; set; }
}

public class ClientPortalApiTestData
{
    public List<GetAccessTokenTestData> GetAccessTokenTestData { get; set; }
    public List<GetMyClientServiceTeamByPortfolioTestData> GetMyClientServiceTeamByPortfolioTestData { get; set; }
    public List<GetLatestReportsByPortfolioTestData> GetLatestReportsByPortfolioTestData { get; set; }
    public List<GetAUMDetailsByPortfolioTestData> GetAUMDetailsByPortfolioTestData { get; set; }
    public List<GetPortfoliosAssociatedToUserTestData> GetPortfoliosAssociatedToUserTestData { get; set; }
    public List<SendResetPasswordNotificationTestData> SendResetPasswordNotificationTestData { get; set; }
    public List<GetLatestNPVReportsTestData> GetLatestNPVReportsTestData { get; set; }
    public List<GetChartSummaryByPortfolioTestData> GetChartSummaryByPortfolioTestData { get; set; }
    public List<GetPortfolioChartDataTestTestData> GetPortfolioChartDataTestTestData { get; set; }
    public List<GetRssInsightsTestData> GetRssInsightsTestData { get; set; }
    public List<GetWhatsNewTestData> GetWhatsNewTestData { get; set; }
    public List<GetNewUserTourTestData> GetNewUserTourTestData { get; set; }
    public List<GetUnauditedTutorialTestData> GetUnauditedTutorialTestData { get; set; }
    public List<GetAuditorPortfoliosTestData> GetAuditorPortfoliosTestData { get; set; }
    public List<GetAuditorReportsByPortfolioTestData> GetAuditorReportsByPortfolioTestData { get; set; }
    public List<GetTranslationsTestData> GetTranslationsTestData { get; set; }
    public List<GetQuestionListTestData> GetQuestionListTestData { get; set; }
    public List<SendSupportMessageTestData> SendSupportMessageTestData { get; set; }
    public List<GetNotificationSettingsTestData> GetNotificationSettingsTestData { get; set; }
    public List<UpdateNotificationSettingsTestData> UpdateNotificationSettingsTestData { get; set; }
    public List<ChangePasswordTestData> ChangePasswordTestData { get; set; }
    public List<SendEventTestData> SendEventTestData { get; set; }
    public List<SendUserSurveyTestData> SendUserSurveyTestData { get; set; }
    public List<GetUserSurveyTestData> GetUserSurveyTestData { get; set; }
    public List<ImpersonationTestData> ImpersonationTestData { get; set; }
    public List<GetAllImpersonateUsersTestData> GetAllImpersonateUsersTestData { get; set; }
    public List<GetHoldingsDatesByPortfolioTestData> GetHoldingsDatesByPortfolioTestData { get; set; }
    public List<GetHoldingsByPortfolioTestData> GetHoldingsByPortfolioTestData { get; set; }
    public List<GetHoldingsByOffbookPortfolioTestData> GetHoldingsByOffbookPortfolioTestData { get; set; }
    public List<GetTransactionsByPortfolioTestData> GetTransactionsByPortfolioTestData { get; set; }
    public List<GetIncomeByPortfolioTestData> GetIncomeByPortfolioTestData { get; set; }
    public List<GetTransactionsByOffbookPortfolioTestData> GetTransactionsByOffbookPortfolioTestData { get; set; }
    public List<CRUDdataViewTestData> CRUDdataViewTestData { get; set; }
    public List<GetFeatureTestData> GetFeatureTestData { get; set; }
    public List<GetReportsByPortfolioTestData> GetReportsByPortfolioTestData { get; set; }
    public List<GetMyScheduledReportsByPortfolioTestData> GetMyScheduledReportsByPortfolioTestData { get; set; }
    public List<CRUDNewScheduledReportTestData> CRUDNewScheduledReportTestData { get; set; }
    public List<GetNpvReportCategoriesTestData> GetNpvReportCategoriesTestData { get; set; }
    public List<GetNpvReportsByCategoriesTestData> GetNpvReportsByCategoriesTestData { get; set; }
    public List<SendHelpMessageTestData> SendHelpMessageTestData { get; set; }
    public List<SendRequestAccessMessageTestData> SendRequestAccessMessageTestData { get; set; }
    public List<GetAllScheduledReportsTestData> GetAllScheduledReportsTestData { get; set; }
    public List<FindDuplicatedScheduledReportTestData> FindDuplicatedScheduledReportTestData { get; set; }
    public List<GetUserMessagesTestData> GetUserMessagesTestData { get; set; }
    public List<DismissUserMessageTestData> DismissUserMessageTestData { get; set; }
}