public class GetAccessTokenDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAccessTokenTestData)
        {
            var encoded_credentials = new FormUrlEncodedContent(new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("username",data.Credentials.Username),
                new KeyValuePair<string, string>("password",data.Credentials.Password),
                new KeyValuePair<string, string>("grant_type","password")
            });
            yield return new TestCaseData(encoded_credentials);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetMyClientServiceTeamByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetMyClientServiceTeamByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

public class GetLatestReportsByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetLatestReportsByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

public class GetAUMDetailsByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAUMDetailsByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

public class GetPortfoliosAssociatedToUserDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetPortfoliosAssociatedToUserTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

public class SendResetPasswordNotificationDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendResetPasswordNotificationTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetLatestNPVReportsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetLatestNPVReportsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetChartSummaryByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetChartSummaryByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetPortfolioChartDataTestDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetPortfolioChartDataTestTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetRssInsightsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetRssInsightsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetWhatsNewDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetWhatsNewTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetNewUserTourDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetNewUserTourTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUnauditedTutorialDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUnauditedTutorialTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetAuditorPortfoliosDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAuditorPortfoliosTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetAuditorReportsByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAuditorReportsByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetTranslationsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetTranslationsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetQuestionListDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetQuestionListTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendSupportMessageDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendSupportMessageTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetNotificationSettingsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetNotificationSettingsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class UpdateNotificationSettingsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.UpdateNotificationSettingsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ChangePasswordDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.ChangePasswordTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendEventDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendEventTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendUserSurveyDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendUserSurveyTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUserSurveyDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUserSurveyTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class ImpersonationDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.ImpersonationTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetAllImpersonateUsersDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAllImpersonateUsersTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetHoldingsDatesByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetHoldingsDatesByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetHoldingsByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetHoldingsByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetTransactionsByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetTransactionsByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetIncomeByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetIncomeByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetHoldingsByOffbookPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetHoldingsByOffbookPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetTransactionsByOffbookPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetTransactionsByOffbookPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class CRUDdataViewDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.CRUDdataViewTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetFeatureDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetFeatureTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetReportsByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetReportsByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetMyScheduledReportsByPortfolioDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetMyScheduledReportsByPortfolioTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class CRUDNewScheduledReportDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.CRUDNewScheduledReportTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetNpvReportCategoriesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetNpvReportCategoriesTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetNpvReportsByCategoriesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetNpvReportsByCategoriesTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendHelpMessageDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendHelpMessageTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class SendRequestAccessMessageDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendRequestAccessMessageTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetAllScheduledReportsDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetAllScheduledReportsTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class FindDuplicatedScheduledReportDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.FindDuplicatedScheduledReportTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class GetUserMessagesDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.GetUserMessagesTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
public class DismissUserMessageDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.DismissUserMessageTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
