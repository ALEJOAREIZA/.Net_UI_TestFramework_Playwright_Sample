public static class ClientPortalApiTestDataManager
{
    public static ClientPortalApiTestData TestData { get; } = new ConfigurationManager<ClientPortalApiTestData>()
        .WithConfigFiles("API/TestData/ClientPortalApi.TestData.json")
        .WithUserSecrets<ClientPortalApiTestData>()
        .Get();
}