param (
    [string]$projectName = $(throw "-projectName is required."),
    [string]$testLevel = $(throw "-testLevel is required."),
    [string]$testEnvironment = $(throw "-testEnvironment is required."),
    [string]$testFilterExpression = $(throw "-testFilterExpression is required."),
    [string]$adoToken = $(throw "-adoToken is required.")
)

$generaltestpipeline = 'https://dev.azure.com/schroders/Domain-Distribution/_apis/pipelines/6148/runs?api-version=7.0'

$buildfarm_token = $adoToken

$uri = $generaltestpipeline
$auth = 'test' + ':' + $buildfarm_token
$Encoded = [System.Text.Encoding]::UTF8.GetBytes($auth)
$authorizationInfo = [System.Convert]::ToBase64String($Encoded)
$headers = @{"Authorization" = "Basic $($authorizationInfo)" }
$body = '{
    "resources": {
        "repositories": {
            "self": {
                "refName": "main"
            }
        }
    },
    "templateParameters": {
        "projectName": "'+$projectName+'",
        "testLevel": "'+$testLevel+'",
        "testEnvironment": "'+$testEnvironment+'",
        "testFilterExpression": "'+$testFilterExpression+'"
    }
}'
$contentType = "application/json"

Invoke-WebRequest -Uri $uri -Method Post -Headers $headers -Body $body -ContentType $contentType