# SchrodersLink Tester Framework

This is a Test Automation Framework for testing SchrodersLink's applications. It is built using .NET as the programming language, NUnit for Unit Test, QE packages for UI and API automation and AzureDevOps for CI/CD. 

The QE packages are a set of .NET libraries created by the Quality Engineering Team that provides a set of functions to interact with the applications under test. The QE packages are built using Playwright for UI Testing and Refit for API Testing. The QE packages are available in the following repositories:

* [QE.CSharp.Core.API.Framework](https://schroders.visualstudio.com/Quality%20Engineering/_git/QE.CSharp.Core.API.Framework) -> API Framework 
* [QE.CSharp.Core.API.Http](https://schroders.visualstudio.com/Quality%20Engineering/_git/QE.CSharp.Core.API.Http) -> API Framework
* [QE.UITesterControlUnit](https://schroders.visualstudio.com/Domain-Distribution/_git/QE.UITesterControlUnit) -> UI framework

# Table of Contents
1. [Main](#main)
2. [Usage](#usage)
3. [How To Write A Test Case](#how-to-write-a-test-case)
4. [Link](#links) 

## Main

* Is a Data Driven Framework which means that separates the test data in external json files and gives flexible test suites configuration and management to test Web and API Applications
* Utilizes POM Pattern to  reduce code duplication and improve test maintenance. Every web page in the application has a corresponding page class
* All classes and methods are implemented in .NET
* Utilize 3 different Layers to separate Business information from Tests and it contains a Core layer that provides helpers and configurations to be reused across the different layers
* Utilizes ADO for CI/CD and regression testing

## Usage

The SLink Tester Framework is made of 3 main layers

**Business Layer** 

* **Business.SchrodersLink.AdminPortal:** It Contains Admin Portal both API and UI Business Information useful for the creation of tests. Here you will find endpoints, DTO's, environment configuration files, Bases address, POM's etc.

* **Business.SchrodersLink.ClientPortal:** It Contains Client Portal both API and UI Business Information useful for the creation of tests. Here you will find endpoints, DTO's, environment configuration files,Bases address, POM's etc.

**Core Layer** 

* **QE.TesterControlUnit:** It Contains all the required packages for API automation, UI Automation, DB Automation, Helpers, Test Configuration models among others capabilities that can be reused across the rest of the layers.

**Test Layer**

* **Test.SchrodersLink.AdminPortal:** It Contains Admin Portal Tests both API and UI. Here you'll find Tests, Test Data input files, Test Configuration files, and Test Traces data for logging and debugging purposes

* **Test.SchrodersLink.ClientPortal:** It Contains Client Portal Tests both API and UI. Here you'll find Tests, Test Data input files, Test Configuration files, and Test Traces data for logging debugging purposes

## How To Write A Test Case

For **UI Testing** 
1. Go to the corresponding Test layer, Go to to the Tests folder and locate the right POM Folder i.e Login
2. Create a test file i.e LoginIntoClientPortal.cs
3. Inherit the BaseUITest class
4. Use the ``` [Test] ``` annotation
5. Use the ```[TestType(TestCaseType.Regression)] ``` annotation and select the adequate TestCaseType
6. Use the ```[TestLevel(TestCaseLevel.UI)]``` annotation 
7. Use the ```[TestCaseSource]``` annotation and create a [Data Provider](#how-to-create-a-test-data-provider)
8. Create a Test Method with the word Test at the end i.e LoginIntoClientPortalTest
9. Use the ClientPortal or the AdminPortal object to access to the different pages
10. Navigate across the pages to access to the different page elements and actions
11. Use fluent assertions to validate the expected outcome

``` csharp
// Test Case
public class LoginIntoClientPortal : BaseUITest
{
    [Test]
    [TestType(TestCaseType.Regression)]
    [TestLevel(TestCaseLevel.UI)]
    [TestCaseSource(typeof(LoginIntoClientPortalDataProvider))]
    public void LoginIntoClientPortalTest(LoginIntoClientPortalTestData data)
    {
        ClientPortal.LoginPage.Authenticate(data.Credentials.Username, data.Credentials.Password);
        ClientPortal.HomePage.NavBar.ProfileIcon.IsVisible().Should().BeTrue();
        ClientPortal.HomePage.LogOut();
        ClientPortal.LoginPage.Username.IsVisible().Should().BeTrue();
    }
}
```
For **API Testing** 
1. Go to the corresponding Test layer, Go to the Tests folder and locate the right POM Folder i.e Support
2. Create a test file i.e SendSupportMessage.cs
3. Inherit the BaseAPITest class
4. Use the ``` [Test] ``` annotation
5. Use the ```[TestType(TestCaseType.Regression)] ``` annotation and select the adequate TestCaseType
6. Use the ```[TestLevel(TestCaseLevel.API)]``` annotation 
7. Use the ```[TestCaseSource]``` annotation and create a [Data Provider](#how-to-create-a-test-data-provider)
8. Create a Test Method with the word Test at the end i.e SendSupportMessageTest
9. Use the ClientPortal or the AdminPortal object to access to the different actions
10. Navigate across the different endpoints
11. Use fluent assertions to validate the expected outcome

``` csharp
// Test Case
public class SendSupportMessage : BaseAPITest
{
    [Test]
    [TestType(TestCaseType.Regression)]
    [TestLevel(TestCaseLevel.API)]
    [TestCaseSource(typeof(SendSupportMessageDataProvider))]
    public async Task SendSupportMessageTest(SendSupportMessageTestData data)
    {
        var response = await ClientPortalPublic.Authenticate(data.Credentials).SendSupportMessage(data.SupportMessage);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}
```

### How To Create A Test Data Provider
1. Go to the corresponding Test Layer
2. Go to XXX.TestData.json file
3. Create a TestData input snippet. example below
4. Go to [from json to c# page](https://json2csharp.com/)
5. Copy and paste the json snippet and generate a c# object
6. Go back to the TestData folder and go to the XXXXTestDataModel.cs file
7. Paste the previous c# object
8. Replace Root for XXXTestData
9. Go back to TestData folder
10. Go To XXXTestDataProvider.cs file
11. Create a DataProvider class for the specific Test i.e SendSupportMessageDataProvider
12. Implement the IEnumerable<ITestCaseData> Interfac exa,ple below

``` json
// Test Data Input
  "SendSupportMessageTestData": [
    {
      "Credentials": {
        "Username": "testschroderslink@schroders.com",
        "Password": ""
      },
      "SupportMessage": {
        "region": "UK",
        "viewType": "UK - Full View",
        "email": "testschroderslink@schroders.com",
        "fullName": "testing schroderslink",
        "subject": "Reporting Query",
        "description": "testing test"
      }
    }
  ],
```

``` csharp

    public class SendSupportMessageTestData
    {
        public Credentials Credentials { get; set; }
        public SupportMessage SupportMessage { get; set; }
    }

    public class Credentials
    {
        [JsonPropertyName("Username")]
        public string Username { get; set; }

        [JsonPropertyName("Password")]
        public string Password { get; set; }
    }

    public class SupportMessage
    {
        [JsonPropertyName("region")]
        public string Region { get; set; }

        [JsonPropertyName("viewType")]
        public string ViewType { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("fullName")]
        public string FullName { get; set; }

        [JsonPropertyName("subject")]
        public string Subject { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }
    }

    public class ClientPortalApiTestData
    { 
        public List<SendSupportMessageTestData> SendSupportMessageTestData { get; set; }
    }

```

``` csharp
// Test DataProvider
public class SendSupportMessageDataProvider : IEnumerable<ITestCaseData>
{
    public IEnumerator<ITestCaseData> GetEnumerator()
    {
        var testData = ClientPortalApiTestDataManager.TestData;
        foreach (var data in testData.SendSupportMessageTestData)
        {
            yield return new TestCaseData(data);
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
```

## Links
* [SLink Tester Framework](#https://confluence.schroders.com/display/DIG/SL-SLink+Tester+Framework)
* [Layers](#https://confluence.schroders.com/display/DIG/SL-SLink+Tester+Framework)
* [Writing Test Cases](#https://confluence.schroders.com/display/DIG/SL-How+To+Automate)