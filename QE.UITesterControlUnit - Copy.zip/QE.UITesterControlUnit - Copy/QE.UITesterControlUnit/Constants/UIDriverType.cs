public enum UIDriverType
{
    Playwright
}