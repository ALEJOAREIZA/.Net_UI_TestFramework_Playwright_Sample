public enum MessageType
{
    Info,
    Warning,
    Error
}