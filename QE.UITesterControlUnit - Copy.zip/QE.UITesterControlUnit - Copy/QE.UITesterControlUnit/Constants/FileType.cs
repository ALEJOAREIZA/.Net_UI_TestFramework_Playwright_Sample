public enum FileType
{
    Log,
    Txt
}