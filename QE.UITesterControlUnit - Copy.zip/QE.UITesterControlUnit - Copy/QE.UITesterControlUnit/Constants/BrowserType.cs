public enum BrowserType
{
    Chrome,
    Chromium,
    Firefox,
    IE
}