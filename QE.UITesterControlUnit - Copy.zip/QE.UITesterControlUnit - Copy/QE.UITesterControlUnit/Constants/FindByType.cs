public enum FindByType
{
    Css,
    Xpath,
    Id,
    Name,
    Text
}